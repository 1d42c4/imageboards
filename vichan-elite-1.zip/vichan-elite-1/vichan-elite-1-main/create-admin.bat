@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "PHP=C:\php\php.exe"
if not exist "%PHP%" (
  echo ERROR: PHP was not found at %PHP%
  pause
  exit /b 1
)

set "VICHAN_ADMIN_USER=%~1"
if not defined VICHAN_ADMIN_USER set /p "VICHAN_ADMIN_USER=Administrator username: "
if not defined VICHAN_ADMIN_USER (
  echo ERROR: An administrator username is required.
  exit /b 1
)

set "VICHAN_DB_HOST=127.0.0.1"
set "VICHAN_DB_PORT=3306"
set "VICHAN_DB_NAME=vichan_native"
set "VICHAN_DB_USER=adelia"
set "VICHAN_DB_PASSWORD=adelia"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$secure = Read-Host 'Administrator password (14-200 characters)' -AsSecureString; $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure); try { $env:VICHAN_ADMIN_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer); & 'C:\php\php.exe' 'bin\create-admin.php' $env:VICHAN_ADMIN_USER; exit $LASTEXITCODE } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer); Remove-Item Env:VICHAN_ADMIN_PASSWORD -ErrorAction SilentlyContinue }"
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
  echo ERROR: Administrator creation failed.
  exit /b %RESULT%
)

echo Administrator account created.
exit /b 0
