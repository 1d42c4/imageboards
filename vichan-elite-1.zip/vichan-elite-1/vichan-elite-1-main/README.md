# vichan-elite

[![PHP build and test](https://github.com/skystars8/vichan-elite-1/actions/workflows/php.yml/badge.svg)](https://github.com/skystars8/vichan-elite-1/actions/workflows/php.yml)
[![MySQL integration and privacy checks](https://github.com/skystars8/vichan-elite-1/actions/workflows/mysql.yml/badge.svg)](https://github.com/skystars8/vichan-elite-1/actions/workflows/mysql.yml)


Ai accomplished in a half hour what vichan maintainers could not accomplish in years. Turns out twig and composer were never really even needed. Imagine that! SERIOUSLY. Stop for a minute and think about how twig and composer were never even needed in vichan. 

This is made for php 8.5.8 and higher! Post moderation is now way more advanced. NO IP collection at all so there will be no leaks! Security hardened. Performance hardened.   THIS IS THE VICHAN YOU ALWAYS DREAMED OF BUT MAINTAINERS REFUSED OR WERE TOO INEPT TO MAKE. But the bad news is that its a little silly to run php web apps when you can have ai make any web app in rust. But hey, to each his/her own i guess lol. One thing is for sure...ai absolutely mastered php. 



Vichan Elite is a privacy-first, security-focused imageboard for PHP 8.5. It keeps the familiar Vichan-style reading and moderation experience while replacing the legacy application core with a small, typed, Composer-free and Twig-free implementation.

Reader-facing home, board, catalog, thread, and media URLs are published as static files. Normal reads therefore avoid PHP sessions and MySQL queries, while posting and moderation remain dynamic and rebuild only the affected output.

This is an independent rewrite, not a patch over the legacy Vichan PHP application. The HTTP layer, domain model, schema, authentication, posting pipeline, upload processing, moderation tools, and templates are new code. Original Vichan-compatible styles, JavaScript, images, and interface conventions are retained where useful.

## Feature overview

### Public boards and posting

- Removable Frameset/Categories-style landing page with persistent sidebar state
- Multiple boards with titles, subtitles, board index pagination, catalogs, threads, and replies
- Reply previews and omitted-reply counts on board pages
- Numeric post links and local `>>123` quote links
- Subject, name, secure trip, comment, file, sage, and noko posting behavior
- Compact secure trips using `Name##a-long-secret`
- Optional Argon2id posting password per board
- Optional moderator approval queue per board
- Optional image requirement for new threads
- Configurable thread-page size, reply previews, comment limit, and upload limit
- Locked threads reject new replies; sage replies do not bump; noko returns to the thread
- Browser-session draft recovery, with only the successfully submitted draft cleared
- Remembered public name and posting preference without retaining an inline trip secret

### Images and media

- PNG, JPEG, GIF, and WebP uploads
- Fileinfo MIME verification instead of trusting filenames or browser-supplied types
- GD decoding, dimension and byte limits, safe re-encoding, and fresh thumbnails
- Metadata removal and independent random server-side source and thumbnail names
- Atomic canonical storage with direct, immutable public media paths
- Public names with 128 bits of randomness
- Inline full-image expansion and collapse with a configurable concurrent-load limit
- Transactional moderator image addition, replacement, and removal
- Canonical and public copies removed together when content is deleted

Animated GIFs may be flattened during safe re-encoding. This is an intentional security and performance tradeoff.

### Reader experience

- Familiar Vichan-compatible board, catalog, thread, and moderator layouts
- Full local stylesheet collection exposed through the Options panel
- Browser-local custom CSS and custom JavaScript options
- Options storage export, import, and erase controls
- Responsive viewport support and a narrow-screen frameset layout
- Keyboard- and modifier-friendly image links that still open normally in a new tab
- Local assets only; the core does not depend on a CDN or remote embed service

Some legacy-compatible assets remain in the repository for visual compatibility even though their corresponding extensions are intentionally not enabled.

### Moderation and administration

- Moderator login, logout, dashboard, and expiring opaque sessions
- Moderator and administrator roles
- Administrator-only board and account configuration
- Board creation plus title, subtitle, approval-mode, and posting-password settings
- Dedicated moderator board and thread views
- Compact inline delete, edit, image, sticky, and lock controls
- Recent-post view with thread flag controls
- Approval queue with publish and reject actions
- Post editing for name, options, subject, comment, and image state
- Reply deletion and cascading thread deletion
- Sticky and locked thread controls
- Moderator account creation and password changes
- Audited login, board, account, approval, edit, delete, image, sticky, and lock actions
- Targeted static rebuild after every published content or moderation change

### Privacy and security

- No application access to `REMOTE_ADDR`, proxy address headers, or similar client-address metadata
- No IP columns, ban tables, mute tables, IP notes, or IP-derived identifiers in the native schema
- Anonymous rate limits based on keyed session and content buckets rather than network addresses
- Argon2id moderator and board-password hashes
- 256-bit moderator session tokens with only SHA-256 token hashes stored in MySQL
- HttpOnly, SameSite=Strict cookies; Secure cookies outside explicit localhost mode
- CSRF protection on every state-changing moderator form
- Signed public form tokens scoped to the exact board and thread
- HMAC-SHA-256 secure trips; trip secrets are removed before storage or browser persistence
- Escaped output and deliberately limited local quote markup
- Comment length and link-count validation
- Strict board, route, upload-name, and moderator-return-path validation
- Restrictive CSP, nosniff, no-referrer, same-origin framing/resource policies, and no-store headers for dynamic/private responses
- No public deletion-password form or public deletion endpoint
- No raw HTML posting, arbitrary embed HTML, remote-file ingestion, or dynamic PHP plugin loader

See [SECURITY.md](SECURITY.md) for the complete trust model and production checklist.

### Architecture and operations

- PHP 8.5-only typed code with readonly objects, enums, clone-with expressions, `#[NoDiscard]`, the URI extension, pipe operator, and PHP 8.5 array helpers
- MySQL 8.4 schema with foreign keys and transactional writes
- No Composer runtime and no template engine dependency
- Small front controller and explicit route matching
- Atomic static generation for the home page, frames, board pages, catalogs, and threads
- Per-board and shared locks for concurrent rebuild safety
- Automatic removal of stale numbered pages and deleted thread output
- Direct static reads for generated HTML and randomly named media
- Preflight, migration, unit-test, rebuild, administrator, and legacy-import commands
- Local Windows setup and launch scripts
- Dry-run-first, idempotent legacy board/post importer

More implementation detail is available in [ARCHITECTURE.md](ARCHITECTURE.md).

## Requirements

- Windows, for the included convenience scripts
- PHP 8.5.8 or a newer PHP 8.5 patch at `C:\php\php.exe`
- MySQL Community Server 8.4 at its standard Program Files location
- PHP extensions: PDO MySQL, GD, fileinfo, intl, mbstring, OpenSSL, and URI
- A local MySQL application account configured in `config.php`

PHP 8.4, PHP 8.6, and older runtimes are intentionally rejected because this project exercises PHP 8.5 language and extension features directly.

## Quick start on Windows

1. Double-click `setup-database.bat` once. If Windows cannot start MySQL, right-click it and choose **Run as administrator**.
2. Enter the MySQL root password when prompted.
3. Choose an administrator username and a password between 14 and 200 characters.
4. Double-click `start-vichan-elite.bat`.
5. Open <http://127.0.0.1:8080/b/>. Moderator login is at <http://127.0.0.1:8080/mod.php>.

The setup script creates a separate `vichan_native` database for compatibility with existing local installations. It does not modify or delete a legacy `vichan` database.

The launcher starts the `MySQL84` service when needed, runs preflight checks, refreshes all static output, and binds PHP only to `127.0.0.1:8080`. Press Ctrl+C in its window to stop the server.

The built-in PHP server is for local development. Use a production web server and HTTPS before exposing Vichan Elite to a network.

## Configuration

Local defaults live in `config.php`. These environment variables override deployment-specific values:

- `VICHAN_APP_NAME`
- `VICHAN_DB_HOST`
- `VICHAN_DB_PORT`
- `VICHAN_DB_NAME`
- `VICHAN_DB_USER`
- `VICHAN_DB_PASSWORD`
- `VICHAN_SITE_KEY`
- `VICHAN_BASE_URL`
- `VICHAN_ALLOW_INSECURE_LOCAL`

Board pagination, reply previews, body length, upload size, and the new-thread image requirement are configured in `config.php`.

Use a unique, random site key and database password in production. The repository defaults are local-development values and must not be reused for an internet-facing deployment.

## Useful commands

```bat
C:\php\php.exe bin\preflight.php
C:\php\php.exe bin\test-unit.php
C:\php\php.exe bin\migrate.php
C:\php\php.exe bin\rebuild-static.php
create-admin.bat
```

Run `bin\rebuild-static.php` after restoring a database/uploads backup or changing templates or the site key. Normal posting and moderation writes rebuild affected pages automatically.

## Automated tests

Every push and pull request runs two GitHub Actions workflows:

- **PHP build and test** checks every PHP file with PHP 8.5 and runs `bin/test-unit.php`.
- **MySQL integration and privacy checks** creates a disposable MySQL 8.4 database, applies the schema, runs `bin/preflight.php`, rebuilds the static site, and verifies the expected output.

Both workflows can also be started manually from the repository's **Actions** tab. Their current results appear in the badges at the top of this README.

## Importing legacy content

Import is optional and runs as a dry run unless `--apply` is present:

```bat
C:\php\php.exe bin\import-legacy.php --source=vichan --legacy-root=C:\path\to\legacy-vichan
```

Review the reported counts, then apply:

```bat
C:\php\php.exe bin\import-legacy.php --source=vichan --legacy-root=C:\path\to\legacy-vichan --apply
```

The importer is idempotent. It reads only board metadata and explicit post-content fields. It never selects legacy IPs, post deletion passwords, bans, flood records, moderator logs, or moderator credentials. Supported legacy images are decoded, re-encoded without metadata, randomly renamed, and thumbnailed again.

Historical tripcode text is retained only as historical display data. New secure trips use the HMAC construction described above; legacy trip algorithms and secrets are not used by Vichan Elite.

## Production deployment

- Put the application behind a maintained web server with HTTPS.
- Leave `VICHAN_ALLOW_INSECURE_LOCAL` unset.
- Deny direct web access to `storage`, `src`, `views`, `database`, `bin`, configuration files, and backups.
- Prefer generated `index.html` files and serve board HTML/media directly.
- Route only `/post.php`, `/post-pending`, `/mod.php`, and missing public paths to PHP.
- Apply the documented security headers to generated static HTML at the web-server layer.
- Use long immutable caching for randomly named media and a deliberate revalidation policy for HTML.
- Enable OPcache, set proxy request/body limits, and maintain tested database/upload backup and rebuild procedures.

## Project hygiene

Generated home, board, catalog, thread, lock, and upload files are excluded by `.gitignore`. The repository contains application source and reusable static assets, not local posts or uploaded content.

## Credits

Vichan Elite was designed and implemented collaboratively with substantial help from ChatGPT and Codex, AI systems by OpenAI. Human project direction, testing, and release decisions remain part of the work.

The familiar interface and retained asset collection build on the Vichan and Tinyboard projects and their contributors. Their copyright notices and license terms are preserved.

## License

See [LICENSE.md](LICENSE.md) and [LICENSE.Tinyboard.md](LICENSE.Tinyboard.md). Both sets of included terms apply to the inherited Vichan/Tinyboard portions of this repository.
