@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "PHP=C:\php\php.exe"
set "MYSQL=C:\Program Files\MySQL\MySQL Server 8.4\bin\mysql.exe"

if not exist "%PHP%" (
  echo ERROR: PHP was not found at %PHP%
  pause
  exit /b 1
)
if not exist "%MYSQL%" (
  echo ERROR: MySQL 8.4 was not found at %MYSQL%
  pause
  exit /b 1
)

sc query MySQL84 2>nul | findstr /C:"RUNNING" >nul
if errorlevel 1 (
  echo Starting the MySQL84 Windows service...
  net start MySQL84 >nul 2>&1
  if errorlevel 1 (
    echo ERROR: MySQL84 could not be started.
    echo Right-click this batch file, choose Run as administrator, and try again.
    pause
    exit /b 1
  )
)

echo.
echo Creating the separate vichan_native database and granting the adelia app user.
echo Enter the MySQL root password when prompted.
"%MYSQL%" --protocol=TCP -h 127.0.0.1 -P 3306 -u root -p -e "CREATE DATABASE IF NOT EXISTS vichan_native CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; CREATE USER IF NOT EXISTS 'adelia'@'127.0.0.1' IDENTIFIED BY 'adelia'; CREATE USER IF NOT EXISTS 'adelia'@'localhost' IDENTIFIED BY 'adelia'; GRANT ALL PRIVILEGES ON vichan_native.* TO 'adelia'@'127.0.0.1'; GRANT ALL PRIVILEGES ON vichan_native.* TO 'adelia'@'localhost'; FLUSH PRIVILEGES;"
if errorlevel 1 (
  echo.
  echo ERROR: Database creation failed. Check the root password and MySQL84 service.
  pause
  exit /b 1
)

set "VICHAN_DB_HOST=127.0.0.1"
set "VICHAN_DB_PORT=3306"
set "VICHAN_DB_NAME=vichan_native"
set "VICHAN_DB_USER=adelia"
set "VICHAN_DB_PASSWORD=adelia"

echo.
echo Applying the native schema...
"%PHP%" bin\migrate.php
if errorlevel 1 (
  echo ERROR: Native schema migration failed.
  pause
  exit /b 1
)

echo.
set "ADMIN_USER="
set /p "ADMIN_USER=Administrator username [admin]: "
if not defined ADMIN_USER set "ADMIN_USER=admin"
call create-admin.bat "%ADMIN_USER%"
if errorlevel 1 (
  echo.
  echo Database setup succeeded, but the administrator was not created.
  echo If it already exists, this is harmless. Otherwise run create-admin.bat.
  pause
  exit /b 1
)

echo.
"%PHP%" bin\preflight.php
if errorlevel 1 (
  echo ERROR: Preflight checks failed.
  pause
  exit /b 1
)

echo.
echo Database setup is complete. Run start-vichan-elite.bat next.
pause
exit /b 0
