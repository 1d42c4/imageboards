@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "PHP=C:\php\php.exe"
if not exist "%PHP%" (
  echo ERROR: PHP was not found at %PHP%
  pause
  exit /b 1
)

"%PHP%" -r "exit(PHP_VERSION_ID >= 80508 && PHP_VERSION_ID < 80600 ? 0 : 1);"
if errorlevel 1 (
  echo ERROR: This rewrite requires PHP 8.5.8 or a newer PHP 8.5 patch.
  "%PHP%" -v
  pause
  exit /b 1
)

sc query MySQL84 2>nul | findstr /C:"RUNNING" >nul
if errorlevel 1 (
  echo Starting the MySQL84 Windows service...
  net start MySQL84 >nul 2>&1
  if errorlevel 1 (
    echo ERROR: MySQL84 could not be started.
    echo Run this batch file as administrator or start the MySQL84 service manually.
    pause
    exit /b 1
  )
)

set "VICHAN_DB_HOST=127.0.0.1"
set "VICHAN_DB_PORT=3306"
set "VICHAN_DB_NAME=vichan_native"
set "VICHAN_DB_USER=adelia"
set "VICHAN_DB_PASSWORD=adelia"
set "VICHAN_BASE_URL=http://127.0.0.1:8080"
set "VICHAN_ALLOW_INSECURE_LOCAL=1"

"%PHP%" bin\preflight.php
if errorlevel 1 (
  echo.
  echo ERROR: Startup preflight failed. Run setup-database.bat once first.
  pause
  exit /b 1
)

"%PHP%" bin\rebuild-static.php
if errorlevel 1 (
  echo.
  echo ERROR: Static public pages could not be rebuilt.
  pause
  exit /b 1
)

echo.
echo Vichan Elite is running at http://127.0.0.1:8080/b/
echo Moderator login:          http://127.0.0.1:8080/mod.php
echo Press Ctrl+C to stop it.
echo.
"%PHP%" -d opcache.enable_cli=1 -S 127.0.0.1:8080 router.php
exit /b %ERRORLEVEL%
