<?php

declare(strict_types=1);

namespace VichanNative\Config;

use RuntimeException;

final readonly class AppConfig
{
    public function __construct(
        public string $root,
        public string $appName,
        public string $dbHost,
        public int $dbPort,
        public string $dbName,
        public string $dbUser,
        #[\SensitiveParameter]
        public string $dbPassword,
        #[\SensitiveParameter]
        public string $siteKey,
        public string $baseUrl,
        public int $threadsPerPage,
        public int $repliesPreview,
        public int $maxBody,
        public int $maxUploadBytes,
        public bool $forceImageForThreads,
        public bool $allowInsecureLocal,
    ) {
        if (PHP_VERSION_ID < 80508 || PHP_VERSION_ID >= 80600) {
            throw new RuntimeException('Vichan Elite requires PHP 8.5.8 or a newer PHP 8.5 patch release.');
        }
        if (trim($this->appName) === '') {
            throw new RuntimeException('The application name cannot be empty.');
        }
        if (strlen($this->siteKey) < 64) {
            throw new RuntimeException('The application site key must contain at least 64 characters.');
        }
        if (!preg_match('/^[A-Za-z0-9_]+$/D', $this->dbName)) {
            throw new RuntimeException('Unsafe database name.');
        }
    }

    public static function load(string $root): self
    {
        $local = require $root . DIRECTORY_SEPARATOR . 'config.php';
        $env = static fn (string $name, mixed $fallback): mixed =>
            (($value = getenv($name)) === false || $value === '') ? $fallback : $value;

        return new self(
            root: $root,
            appName: trim((string) $env('VICHAN_APP_NAME', $local['app_name'])),
            dbHost: (string) $env('VICHAN_DB_HOST', $local['db_host']),
            dbPort: (int) $env('VICHAN_DB_PORT', $local['db_port']),
            dbName: (string) $env('VICHAN_DB_NAME', $local['db_name']),
            dbUser: (string) $env('VICHAN_DB_USER', $local['db_user']),
            dbPassword: (string) $env('VICHAN_DB_PASSWORD', $local['db_password']),
            siteKey: (string) $env('VICHAN_SITE_KEY', $local['site_key']),
            baseUrl: rtrim((string) $env('VICHAN_BASE_URL', $local['base_url']), '/'),
            threadsPerPage: max(1, (int) $local['threads_per_page']),
            repliesPreview: max(0, (int) $local['replies_preview']),
            maxBody: max(100, (int) $local['max_body']),
            maxUploadBytes: max(1024, (int) $local['max_upload_bytes']),
            forceImageForThreads: (bool) $local['force_image_for_threads'],
            allowInsecureLocal: $env('VICHAN_ALLOW_INSECURE_LOCAL', '0') === '1',
        );
    }

    public function dsn(): string
    {
        return sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            $this->dbHost,
            $this->dbPort,
            $this->dbName,
        );
    }
}
