<?php

declare(strict_types=1);

namespace VichanNative;

use PDO;
use Throwable;
use VichanNative\Config\AppConfig;

final class Database
{
    private ?PDO $pdo = null;

    public function __construct(private readonly AppConfig $config)
    {
    }

    public function pdo(): PDO
    {
        return $this->pdo ??= new PDO(
            $this->config->dsn(),
            $this->config->dbUser,
            $this->config->dbPassword,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_STRINGIFY_FETCHES => false,
                PDO::ATTR_PERSISTENT => true,
            ],
        );
    }

    #[\NoDiscard('The transaction result must be used.')]
    public function transaction(callable $operation): mixed
    {
        $pdo = $this->pdo();
        $pdo->beginTransaction();
        try {
            $result = $operation($pdo);
            $pdo->commit();
            return $result;
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $error;
        }
    }
}
