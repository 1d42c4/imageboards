<?php

declare(strict_types=1);

namespace VichanNative\Security;

use PDO;
use VichanNative\Config\AppConfig;
use VichanNative\Database;

final readonly class RateLimiter
{
    public function __construct(
        private Database $database,
        private AppConfig $config,
    ) {
    }

    public function consume(string $bucket, int $limit, int $windowSeconds): void
    {
        $key = hash_hmac('sha256', $bucket, $this->config->siteKey, true);
        (void) $this->database->transaction(function (PDO $pdo) use ($key, $limit, $windowSeconds): bool {
            $now = time();
            $query = $pdo->prepare('SELECT attempts, window_started_at FROM rate_limits WHERE bucket_key = :key FOR UPDATE');
            $query->bindValue('key', $key, PDO::PARAM_LOB);
            $query->execute();
            $row = $query->fetch();
            if ($row === false || ((int) $row['window_started_at'] + $windowSeconds) <= $now) {
                $replace = $pdo->prepare(
                    'INSERT INTO rate_limits (bucket_key, attempts, window_started_at, expires_at)
                     VALUES (:key, 1, :started, :expires)
                     ON DUPLICATE KEY UPDATE attempts = 1, window_started_at = VALUES(window_started_at),
                                             expires_at = VALUES(expires_at)'
                );
                $replace->bindValue('key', $key, PDO::PARAM_LOB);
                $replace->bindValue('started', $now, PDO::PARAM_INT);
                $replace->bindValue('expires', $now + $windowSeconds, PDO::PARAM_INT);
                $replace->execute();
                return true;
            }
            if ((int) $row['attempts'] >= $limit) {
                throw new \DomainException('Please wait before trying that again.');
            }
            $update = $pdo->prepare('UPDATE rate_limits SET attempts = attempts + 1 WHERE bucket_key = :key');
            $update->bindValue('key', $key, PDO::PARAM_LOB);
            $update->execute();
            return true;
        });
        if (random_int(1, 100) === 1) {
            $cleanup = $this->database->pdo()->prepare('DELETE FROM rate_limits WHERE expires_at < :now');
            $cleanup->execute(['now' => time()]);
        }
    }

    public function sessionBucket(string $purpose): string
    {
        $sessionKey = hash_hmac('sha256', session_id(), $this->config->siteKey);
        return "session:{$purpose}:{$sessionKey}";
    }

    public function contentBucket(string $purpose, string $content): string
    {
        return "content:{$purpose}:" . hash_hmac('sha256', $content, $this->config->siteKey);
    }
}
