SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS schema_migrations (
    version varchar(64) CHARACTER SET ascii NOT NULL,
    applied_at int unsigned NOT NULL,
    PRIMARY KEY (version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS boards (
    id int unsigned NOT NULL AUTO_INCREMENT,
    uri varchar(58) CHARACTER SET ascii NOT NULL,
    title varchar(255) NOT NULL,
    subtitle varchar(500) NOT NULL DEFAULT '',
    require_approval tinyint(1) NOT NULL DEFAULT 0,
    post_password_hash varchar(255) CHARACTER SET ascii DEFAULT NULL,
    created_at int unsigned NOT NULL,
    updated_at int unsigned NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY boards_uri (uri)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS moderators (
    id int unsigned NOT NULL AUTO_INCREMENT,
    username varchar(60) NOT NULL,
    password_hash varchar(255) CHARACTER SET ascii NOT NULL,
    role enum('moderator','administrator') NOT NULL DEFAULT 'moderator',
    force_password_change tinyint(1) NOT NULL DEFAULT 0,
    created_at int unsigned NOT NULL,
    updated_at int unsigned NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY moderators_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS moderator_sessions (
    token_hash binary(32) NOT NULL,
    moderator_id int unsigned NOT NULL,
    created_at int unsigned NOT NULL,
    last_seen_at int unsigned NOT NULL,
    expires_at int unsigned NOT NULL,
    PRIMARY KEY (token_hash),
    KEY moderator_sessions_expiry (expires_at),
    CONSTRAINT moderator_sessions_moderator FOREIGN KEY (moderator_id)
        REFERENCES moderators (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS posts (
    id bigint unsigned NOT NULL AUTO_INCREMENT,
    board_id int unsigned NOT NULL,
    thread_id bigint unsigned DEFAULT NULL,
    subject varchar(100) NOT NULL DEFAULT '',
    name varchar(35) NOT NULL,
    trip varchar(32) CHARACTER SET ascii NOT NULL DEFAULT '',
    email varchar(40) NOT NULL DEFAULT '',
    body_source text NOT NULL,
    body_html text NOT NULL,
    status enum('pending','published') NOT NULL DEFAULT 'published',
    created_at int unsigned NOT NULL,
    bumped_at int unsigned NOT NULL,
    sticky tinyint(1) NOT NULL DEFAULT 0,
    locked tinyint(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY posts_board_threads (board_id, status, thread_id, sticky, bumped_at),
    KEY posts_thread (thread_id, status, id),
    KEY posts_pending (status, created_at),
    CONSTRAINT posts_board FOREIGN KEY (board_id)
        REFERENCES boards (id) ON DELETE CASCADE,
    CONSTRAINT posts_thread_parent FOREIGN KEY (thread_id)
        REFERENCES posts (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS post_files (
    id bigint unsigned NOT NULL AUTO_INCREMENT,
    post_id bigint unsigned NOT NULL,
    stored_name varchar(80) CHARACTER SET ascii NOT NULL,
    thumbnail_name varchar(80) CHARACTER SET ascii NOT NULL,
    original_name varchar(255) NOT NULL,
    mime varchar(80) CHARACTER SET ascii NOT NULL,
    size int unsigned NOT NULL,
    width int unsigned NOT NULL,
    height int unsigned NOT NULL,
    thumbnail_width int unsigned NOT NULL,
    thumbnail_height int unsigned NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY post_files_stored_name (stored_name),
    KEY post_files_post (post_id),
    CONSTRAINT post_files_post FOREIGN KEY (post_id)
        REFERENCES posts (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
    bucket_key binary(32) NOT NULL,
    attempts int unsigned NOT NULL,
    window_started_at int unsigned NOT NULL,
    expires_at int unsigned NOT NULL,
    PRIMARY KEY (bucket_key),
    KEY rate_limits_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS moderation_log (
    id bigint unsigned NOT NULL AUTO_INCREMENT,
    moderator_id int unsigned DEFAULT NULL,
    action varchar(80) CHARACTER SET ascii NOT NULL,
    board_uri varchar(58) CHARACTER SET ascii DEFAULT NULL,
    post_id bigint unsigned DEFAULT NULL,
    details varchar(1000) NOT NULL DEFAULT '',
    created_at int unsigned NOT NULL,
    PRIMARY KEY (id),
    KEY moderation_log_time (created_at),
    CONSTRAINT moderation_log_moderator FOREIGN KEY (moderator_id)
        REFERENCES moderators (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS legacy_import_map (
    source_database varchar(64) CHARACTER SET ascii NOT NULL,
    board_uri varchar(58) CHARACTER SET ascii NOT NULL,
    legacy_post_id int unsigned NOT NULL,
    native_post_id bigint unsigned NOT NULL,
    imported_at int unsigned NOT NULL,
    PRIMARY KEY (source_database, board_uri, legacy_post_id),
    UNIQUE KEY legacy_import_native_post (native_post_id),
    CONSTRAINT legacy_import_post FOREIGN KEY (native_post_id)
        REFERENCES posts (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO boards (uri, title, subtitle, require_approval, post_password_hash, created_at, updated_at)
SELECT 'b', 'Random', '', 0, NULL, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()
WHERE NOT EXISTS (SELECT 1 FROM boards WHERE uri = 'b');

INSERT INTO schema_migrations (version, applied_at)
VALUES ('001_native_schema', UNIX_TIMESTAMP())
ON DUPLICATE KEY UPDATE applied_at = applied_at;
