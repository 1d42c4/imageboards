<?php

declare(strict_types=1);

ob_start();
?>
<?php if (is_file($config->root . '/static/banners/defaultbanner.png')): ?>
    <img class="board_image" src="/static/banners/defaultbanner.png" style="width:300px;height:100px" alt="">
<?php endif; ?>
<fieldset>
    <legend>Boards</legend>
    <ul>
        <?php foreach ($boards as $board): ?>
            <li>
                <a href="/mod.php?/<?= $e($board->uri) ?>">/<?= $e($board->uri) ?>/</a> - <?= $e($board->title) ?>
                <a href="/<?= $e($board->uri) ?>/"><small>[public]</small></a>
                <?php if ($board->subtitle !== ''): ?><small>&mdash; <?= $e($board->subtitle) ?></small><?php endif; ?>
                <?php if ($moderator->role->canManageConfiguration()): ?>
                    <a href="/mod.php?/boards/<?= $e($board->uri) ?>"><small>[edit]</small></a>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
        <?php if ($moderator->role->canManageConfiguration()): ?>
            <li style="margin-top:15px"><a href="/mod.php?/boards/new"><strong>Create new board</strong></a></li>
        <?php endif; ?>
    </ul>
</fieldset>
<fieldset>
    <legend>Administration</legend>
    <ul>
        <li>
            <?php if ($pendingCount > 0): ?><strong><?php endif; ?>
            <a href="/mod.php?/pending">Post approval queue (<?= $pendingCount ?>)</a>
            <?php if ($pendingCount > 0): ?></strong><?php endif; ?>
        </li>
        <li><a href="/mod.php?/posts">Recent posts</a></li>
        <li><a href="/mod.php?/log">Moderation log</a></li>
        <?php if ($moderator->role->canManageConfiguration()): ?>
            <li><a href="/mod.php?/boards">Manage boards</a></li>
            <li><a href="/mod.php?/users">Manage users</a></li>
        <?php endif; ?>
    </ul>
</fieldset>
<fieldset>
    <legend>Runtime</legend>
    <ul>
        <li>PHP <?= $e(PHP_VERSION) ?></li>
        <li>Native URI routing, readonly domain objects, enums, clone-with responses, and strict types enabled.</li>
        <li>No request IP addresses are collected or stored.</li>
    </ul>
</fieldset>
<?php
$modContent = (string) ob_get_clean();
$this->partial('mod/layout.php', compact('title', 'modContent', 'moderator', 'csrf'));
?>
