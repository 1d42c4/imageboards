<?php

declare(strict_types=1);

ob_start();
?>
<fieldset>
    <legend>Boards</legend>
    <table>
        <tr><th>URI</th><th>Title</th><th>Approval</th><th>Password</th><th></th></tr>
        <?php foreach ($boards as $board): ?>
            <tr>
                <td>/<?= $e($board->uri) ?>/</td>
                <td><?= $e($board->title) ?></td>
                <td><?= $board->requireApproval ? 'Yes' : 'No' ?></td>
                <td><?= $board->requiresPassword() ? 'Required' : 'None' ?></td>
                <td><a href="/mod.php?/boards/<?= $e($board->uri) ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <p><a href="/mod.php?/boards/new"><strong>Create new board</strong></a></p>
</fieldset>
<?php
$modContent = (string) ob_get_clean();
$this->partial('mod/layout.php', compact('title', 'modContent', 'moderator', 'csrf'));
?>
