<?php

declare(strict_types=1);

ob_start();
?>
<?php if (!empty($moderator)): ?>
    <div class="ban">
        <h2><?= $e($title) ?></h2>
        <p>
            <a href="/mod.php?/">Dashboard</a> ·
            <a href="/mod.php?/pending">Approval queue</a> ·
            <a href="/mod.php?/posts">Recent posts</a>
            <?php if ($moderator->role->canManageConfiguration()): ?>
                · <a href="/mod.php?/boards">Boards</a>
                · <a href="/mod.php?/users">Users</a>
            <?php endif; ?>
            · <a href="/mod.php?/log">Log</a>
        </p>
    </div>
<?php endif; ?>
<?= $modContent ?>
<?php if (!empty($moderator)): ?>
    <form action="/mod.php?/logout" method="post" style="text-align:center;margin-top:20px">
        <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
        <button type="submit">Logout <?= $e($moderator->username) ?></button>
    </form>
<?php endif; ?>
<?php
$content = (string) ob_get_clean();
$this->partial('layout.php', [
    'title' => $title,
    'content' => $content,
    'activePage' => $activePage ?? 'mod',
    'boardName' => $boardName ?? '',
    'moderator' => $moderator ?? null,
]);
?>
