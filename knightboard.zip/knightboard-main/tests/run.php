<?php

declare(strict_types=1);

use Chessboard\Config;
use Chessboard\Database;
use Chessboard\Http\Request;
use Chessboard\Repository\BoardRepository;
use Chessboard\Security;
use Chessboard\Service\AdminService;
use Chessboard\Service\PostingService;
use Chessboard\Service\PublicModerationService;
use Chessboard\Service\UploadService;
use Chessboard\Settings;

require dirname(__DIR__) . '/app/autoload.php';

final class TestSuite
{
    private int $passed = 0;
    private int $failed = 0;
    private int $assertions = 0;

    /** @var list<array{status: string, name: string, detail: string}> */
    private array $results = [];

    public function test(string $name, callable $test): void
    {
        try {
            $test($this);
            $this->passed++;
            $this->results[] = ['status' => 'PASS', 'name' => $name, 'detail' => ''];
        } catch (Throwable $exception) {
            $this->failed++;
            $this->results[] = [
                'status' => 'FAIL',
                'name' => $name,
                'detail' => $exception::class . ': ' . $exception->getMessage(),
            ];
        }
    }

    public function fail(string $name, Throwable $exception): void
    {
        $this->failed++;
        $this->results[] = [
            'status' => 'FAIL',
            'name' => $name,
            'detail' => $exception::class . ': ' . $exception->getMessage(),
        ];
    }

    public function true(bool $condition, string $message = 'Expected condition to be true.'): void
    {
        $this->assertions++;
        if (!$condition) {
            throw new RuntimeException($message);
        }
    }

    public function false(bool $condition, string $message = 'Expected condition to be false.'): void
    {
        $this->true(!$condition, $message);
    }

    public function same(mixed $expected, mixed $actual, string $message = ''): void
    {
        $this->assertions++;
        if ($expected !== $actual) {
            $prefix = $message === '' ? 'Values are not identical.' : $message;
            throw new RuntimeException(
                $prefix . ' Expected ' . var_export($expected, true) . ', got ' . var_export($actual, true) . '.',
            );
        }
    }

    public function contains(string $needle, string $haystack, string $message = ''): void
    {
        $this->assertions++;
        if (!str_contains($haystack, $needle)) {
            throw new RuntimeException($message === '' ? "Expected output to contain {$needle}." : $message);
        }
    }

    public function notContains(string $needle, string $haystack, string $message = ''): void
    {
        $this->assertions++;
        if (str_contains($haystack, $needle)) {
            throw new RuntimeException($message === '' ? "Expected output not to contain {$needle}." : $message);
        }
    }

    public function throws(callable $callback, string $class, string $messageFragment = ''): Throwable
    {
        $this->assertions++;
        try {
            $callback();
        } catch (Throwable $exception) {
            if (!$exception instanceof $class) {
                throw new RuntimeException('Expected ' . $class . ', got ' . $exception::class . '.', previous: $exception);
            }
            if ($messageFragment !== '' && !str_contains($exception->getMessage(), $messageFragment)) {
                throw new RuntimeException(
                    "Expected exception message to contain '{$messageFragment}', got '{$exception->getMessage()}'.",
                    previous: $exception,
                );
            }
            return $exception;
        }
        throw new RuntimeException("Expected {$class} to be thrown.");
    }

    public function report(): int
    {
        foreach ($this->results as $result) {
            echo '[' . $result['status'] . '] ' . $result['name'] . PHP_EOL;
            if ($result['detail'] !== '') {
                echo '       ' . $result['detail'] . PHP_EOL;
            }
        }
        echo PHP_EOL;
        echo "{$this->passed} passed, {$this->failed} failed, {$this->assertions} assertions" . PHP_EOL;
        return $this->failed === 0 ? 0 : 1;
    }
}

/** @param array<string, mixed> $values @param array<string, mixed> $files */
function formRequest(Security $security, Config $config, string $purpose, array $values, array $files = []): Request
{
    $csrf = $security->csrfToken();
    $timestamp = (string) (time() - 2);
    $stamp = $timestamp . '.' . hash_hmac(
        'sha256',
        "form:{$purpose}:{$timestamp}:{$csrf}",
        $config->appKey,
    );

    return new Request(
        'POST',
        '/',
        [],
        ['_token' => $csrf, '_stamp' => $stamp, 'website' => ''] + $values,
        $files,
    );
}

function removeTestTree(string $path): void
{
    if (!is_dir($path)) {
        return;
    }

    $expectedParent = realpath(sys_get_temp_dir());
    $actualParent = realpath(dirname($path));
    if ($expectedParent === false || $actualParent !== $expectedParent || !str_starts_with(basename($path), 'knightboard-tests-')) {
        throw new RuntimeException('Refusing to remove a directory outside the Knightboard test area.');
    }

    $entries = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST,
    );
    foreach ($entries as $entry) {
        if ($entry->isDir() && !$entry->isLink()) {
            if (!rmdir($entry->getPathname())) {
                throw new RuntimeException('Unable to remove test directory: ' . $entry->getPathname());
            }
        } elseif (!unlink($entry->getPathname())) {
            throw new RuntimeException('Unable to remove test file: ' . $entry->getPathname());
        }
    }
    if (!rmdir($path)) {
        throw new RuntimeException('Unable to remove the test root: ' . $path);
    }
}

$suite = new TestSuite();
$root = dirname(__DIR__);
$temporaryPath = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'knightboard-tests-' . bin2hex(random_bytes(8));

$database = null;
$pdo = null;
$security = null;
$settings = null;
$uploads = null;
$posting = null;
$publicModeration = null;
$adminService = null;
$boards = null;

try {
    $suite->test('runtime requirements are available', static function (TestSuite $test): void {
        $test->true(PHP_VERSION_ID >= 80508, 'Knightboard requires PHP 8.5.8 or newer.');
        foreach (['ctype', 'fileinfo', 'gd', 'mbstring', 'pdo', 'pdo_sqlite', 'session'] as $extension) {
            $test->true(extension_loaded($extension), "Required PHP extension '{$extension}' is not loaded.");
        }
    });

    if (!mkdir($temporaryPath, 0770, true) && !is_dir($temporaryPath)) {
        throw new RuntimeException('Unable to create the temporary test directory.');
    }
    foreach (['uploads', 'sessions'] as $directory) {
        $path = $temporaryPath . DIRECTORY_SEPARATOR . $directory;
        if (!mkdir($path, 0770, true) && !is_dir($path)) {
            throw new RuntimeException("Unable to create temporary {$directory} directory.");
        }
    }

    $config = new Config(
        basePath: $root,
        databasePath: $temporaryPath . DIRECTORY_SEPARATOR . 'knightboard.sqlite',
        storagePath: $temporaryPath,
        uploadPath: $temporaryPath . DIRECTORY_SEPARATOR . 'uploads',
        sessionPath: $temporaryPath . DIRECTORY_SEPARATOR . 'sessions',
        appKey: str_repeat('test-key-', 8),
        debug: true,
        maxUploadBytes: 8_388_608,
    );
    $database = new Database($config);
    $pdo = $database->pdo();
    $security = new Security($config);
    $_COOKIE['knightboard_poster'] = str_repeat('a', 64);
    session_id('knightboardtest' . bin2hex(random_bytes(8)));
    $security->startSession();
    $_SESSION = [];

    $suite->test('empty database migrates idempotently with default boards', static function (TestSuite $test) use ($database, $pdo): void {
        $database->migrate();
        $database->migrate();

        $test->same(3, (int) $pdo->query('SELECT COUNT(*) FROM schema_migrations')->fetchColumn());
        $test->same(1, (int) $pdo->query('PRAGMA foreign_keys')->fetchColumn());
        $test->same(0, (int) $pdo->query('SELECT COUNT(*) FROM threads')->fetchColumn());
        $test->same(0, (int) $pdo->query('SELECT COUNT(*) FROM posts')->fetchColumn());

        $slugs = $pdo->query('SELECT slug FROM boards ORDER BY sort_order, id')->fetchAll(PDO::FETCH_COLUMN);
        $test->same(['chess', 'analysis', 'puzzles', 'openings', 'events', 'meta'], $slugs);
        $test->same('Knightboard', (string) $pdo->query("SELECT value FROM settings WHERE key = 'site_name'")->fetchColumn());
        $test->same('8', (string) $pdo->query("SELECT value FROM settings WHERE key = 'post_cooldown_seconds'")->fetchColumn());
    });

    $suite->test('schema and request code contain no IP identifiers', static function (TestSuite $test) use ($pdo, $root): void {
        $identifierPattern = '/(?:^|_)(?:ip|ipv4|ipv6)(?:_|$)|ip_?address|remote_?addr|forwarded_?for/i';
        $objects = $pdo->query(
            "SELECT type, name, tbl_name FROM sqlite_schema WHERE type IN ('table', 'index', 'trigger', 'view') ORDER BY type, name",
        )->fetchAll();
        foreach ($objects as $object) {
            foreach (['name', 'tbl_name'] as $field) {
                $identifier = (string) $object[$field];
                $test->false(
                    preg_match($identifierPattern, $identifier) === 1,
                    "Privacy-sensitive schema identifier found: {$identifier}",
                );
            }
        }

        $tables = $pdo->query("SELECT name FROM sqlite_schema WHERE type = 'table' ORDER BY name")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $table) {
            $quoted = str_replace("'", "''", (string) $table);
            $columns = $pdo->query("PRAGMA table_info('{$quoted}')")->fetchAll();
            foreach ($columns as $column) {
                $identifier = (string) $column['name'];
                $test->false(
                    preg_match($identifierPattern, $identifier) === 1,
                    "Privacy-sensitive column found: {$table}.{$identifier}",
                );
            }
        }

        $sourcePatterns = [
            '/\$_SERVER\s*\[\s*[\'\"](?:REMOTE_ADDR|HTTP_X_FORWARDED_FOR|HTTP_CLIENT_IP|HTTP_FORWARDED)[\'\"]\s*\]/i',
            '/\b(?:client|remote|visitor|requester)_?ip\b/i',
            '/\b(?:inet_pton|inet_ntop)\s*\(/i',
        ];
        $phpFiles = [];
        foreach (['app', 'public'] as $sourceDirectory) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator(
                    $root . DIRECTORY_SEPARATOR . $sourceDirectory,
                    FilesystemIterator::SKIP_DOTS,
                ),
            );
            foreach ($files as $file) {
                if ($file->isFile() && strtolower($file->getExtension()) === 'php') {
                    $phpFiles[] = $file->getPathname();
                }
            }
        }
        $phpFiles[] = $root . DIRECTORY_SEPARATOR . 'router.php';
        foreach ($phpFiles as $file) {
            $source = file_get_contents($file);
            $test->true($source !== false, 'Unable to inspect ' . $file);
            foreach ($sourcePatterns as $pattern) {
                $test->false(
                    preg_match($pattern, (string) $source) === 1,
                    'Possible IP collection found in ' . $file,
                );
            }
        }
    });

    $suite->test('FEN validation accepts valid positions and rejects malformed fields', static function (TestSuite $test): void {
        $valid = [
            '',
            'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
            'r3k2r/ppp2ppp/2npbn2/3Np3/4P3/2N1B3/PPP2PPP/R3K2R b KQkq e3 12 20',
            '8/8/8/8/8/8/8/8 b - - 99 42',
        ];
        foreach ($valid as $fen) {
            $test->true(valid_fen($fen), "Expected valid FEN: {$fen}");
        }

        $invalid = [
            '8/8/8/8/8/8/8/8 w - - 0',
            '8/8/8/8/8/8/8 w - - 0 1',
            '7/8/8/8/8/8/8/8 w - - 0 1',
            '80/8/8/8/8/8/8/8 w - - 0 1',
            '8/8/8/8/8/8/8/7x w - - 0 1',
            '8/8/8/8/8/8/8/8 x - - 0 1',
            '8/8/8/8/8/8/8/8 w KK - 0 1',
            '8/8/8/8/8/8/8/8 w - e4 0 1',
            '8/8/8/8/8/8/8/8 w - - -1 1',
            '8/8/8/8/8/8/8/8 w - - 0 0',
        ];
        foreach ($invalid as $fen) {
            $test->false(valid_fen($fen), "Expected invalid FEN: {$fen}");
        }
    });

    $suite->test('post renderer escapes XSS while preserving quotes, spoilers, and greentext', static function (TestSuite $test): void {
        $body = '<script>alert("x")</script>' . "\n"
            . '>>42 & "quoted"' . "\n"
            . '>green <img src=x onerror=alert(1)>' . "\n"
            . '[spoiler]<b>mate</b> & "win"[/spoiler]';
        $threadUrl = '/chess/thread/99?next=" onclick="alert(1)&x=<tag>';
        $rendered = render_post_body($body, $threadUrl);

        $test->same([42, 7], quoted_post_ids('>>42, >>7, >>42, >>0, >>0001'));
        $test->notContains('<script', $rendered);
        $test->notContains('<img', $rendered);
        $test->notContains('<b>', $rendered);
        $test->contains('&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;', $rendered);
        $test->contains(
            'href="/chess/thread/99?next=&quot; onclick=&quot;alert(1)&amp;x=&lt;tag&gt;#p42"',
            $rendered,
        );
        $test->contains('data-post-ref="42">&gt;&gt;42</a>', $rendered);
        $test->contains('<span class="greentext">&gt;green &lt;img src=x onerror=alert(1)&gt;</span>', $rendered);
        $test->contains(
            '<span class="spoiler" tabindex="0">&lt;b&gt;mate&lt;/b&gt; &amp; &quot;win&quot;</span>',
            $rendered,
        );

        preg_match_all('/<\/?([a-z][a-z0-9]*)\b/i', $rendered, $matches);
        $tags = array_values(array_unique(array_map('strtolower', $matches[1] ?? [])));
        sort($tags);
        $test->same(['a', 'br', 'span'], $tags, 'Renderer emitted an unexpected HTML element.');
    });

    $settings = new Settings($pdo);
    $uploads = new UploadService($config, $pdo);
    $posting = new PostingService($database, $settings, $security, $uploads);
    $publicModeration = new PublicModerationService($database, $security, $uploads);
    $adminService = new AdminService($database, $settings, $security, $uploads);
    $boards = new BoardRepository($pdo);

    $threadId = 0;
    $opPostId = 0;
    $replyPostId = 0;

    $suite->test('thread and reply transactions work with cooldown disabled', static function (TestSuite $test) use (
        $settings,
        $posting,
        $security,
        $config,
        $boards,
        $pdo,
        &$threadId,
        &$opPostId,
        &$replyPostId,
    ): void {
        $settings->update([
            'post_cooldown_seconds' => '0',
            'posts_per_minute' => '120',
            'global_posts_per_minute' => '5000',
        ]);
        $board = $boards->board('chess');
        $test->true(is_array($board), 'Seeded chess board was not found.');

        $created = $posting->createThread(
            $board,
            formRequest($security, $config, 'new:chess', [
                'name' => 'Alice',
                'subject' => 'Candidate move',
                'body' => 'What is the best continuation?',
                'fen' => 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
                'pgn' => '',
                'deletion_password' => 'thread-password',
            ]),
        );
        $threadId = $created['thread_id'];
        $opPostId = $created['post_id'];
        $test->true($threadId > 0 && $opPostId > 0, 'Thread creation did not return positive identifiers.');

        $op = $pdo->query('SELECT * FROM posts WHERE id = ' . $opPostId)->fetch();
        $test->same(1, (int) $op['is_op']);
        $test->same('Alice', (string) $op['name']);
        $test->true(
            password_verify('thread-password', (string) $op['delete_password_hash']),
            'The OP deletion password hash did not verify.',
        );
        $test->same(
            hash_hmac('sha256', 'poster:' . str_repeat('a', 64), $config->appKey),
            (string) $op['poster_token_hash'],
        );

        $pdo->exec("UPDATE threads SET bumped_at = '2000-01-01 00:00:00' WHERE id = {$threadId}");
        $thread = $boards->thread('chess', $threadId);
        $test->true(is_array($thread), 'New thread was not readable through BoardRepository.');
        $replyPostId = $posting->reply(
            $thread,
            formRequest($security, $config, 'reply:' . $threadId, [
                'name' => 'Bob',
                'subject' => '',
                'body' => 'I prefer 1. e4.',
                'fen' => '',
                'pgn' => '1. e4 e5',
                'deletion_password' => 'reply-password',
                'sage' => '0',
            ]),
        );
        $test->true($replyPostId > $opPostId, 'Reply did not receive a post ID after the OP.');

        $storedThread = $pdo->query('SELECT * FROM threads WHERE id = ' . $threadId)->fetch();
        $test->same(1, (int) $storedThread['reply_count']);
        $test->same(0, (int) $storedThread['attachment_count']);
        $test->same(2, (int) $pdo->query('SELECT COUNT(*) FROM posts WHERE thread_id = ' . $threadId)->fetchColumn());

        $postsBefore = (int) $pdo->query('SELECT COUNT(*) FROM posts')->fetchColumn();
        $posterBucketBefore = (int) $pdo->query("SELECT hit_count FROM rate_limits WHERE bucket_key LIKE 'poster:%'")->fetchColumn();
        $pdo->exec(
            "CREATE TEMP TRIGGER test_abort_reply_update " .
            "BEFORE UPDATE OF reply_count ON threads WHEN NEW.id = {$threadId} " .
            "BEGIN SELECT RAISE(ABORT, 'forced transaction rollback'); END",
        );
        $failure = null;
        try {
            $posting->reply(
                $thread,
                formRequest($security, $config, 'reply:' . $threadId, [
                    'body' => 'This insert must roll back.',
                    'deletion_password' => 'rollback-password',
                ]),
            );
        } catch (Throwable $exception) {
            $failure = $exception;
        } finally {
            $pdo->exec('DROP TRIGGER test_abort_reply_update');
        }
        $test->true($failure instanceof PDOException, 'The forced SQLite failure did not propagate.');
        $test->contains('forced transaction rollback', (string) $failure?->getMessage());
        $test->same($postsBefore, (int) $pdo->query('SELECT COUNT(*) FROM posts')->fetchColumn());
        $test->same(1, (int) $pdo->query('SELECT reply_count FROM threads WHERE id = ' . $threadId)->fetchColumn());
        $test->same(
            $posterBucketBefore,
            (int) $pdo->query("SELECT hit_count FROM rate_limits WHERE bucket_key LIKE 'poster:%'")->fetchColumn(),
            'Rate-limit writes must roll back with a failed post transaction.',
        );
    });

    $suite->test('non-sage replies bump their thread', static function (TestSuite $test) use ($pdo, $threadId): void {
        $bumpedAt = (string) $pdo->query('SELECT bumped_at FROM threads WHERE id = ' . $threadId)->fetchColumn();
        $test->true($bumpedAt !== '2000-01-01 00:00:00', 'A non-sage reply did not bump the thread.');
    });

    $suite->test('image uploads are re-encoded, randomized, attached, and safely located', static function (TestSuite $test) use (
        $uploads,
        $config,
        $temporaryPath,
        $opPostId,
        $pdo,
    ): void {
        $sourcePath = $temporaryPath . DIRECTORY_SEPARATOR . 'source-with-misleading-extension.txt';
        $source = imagecreatetruecolor(320, 120);
        $test->true($source instanceof GdImage, 'GD could not create the upload fixture.');
        $background = imagecolorallocate($source, 30, 90, 160);
        $accent = imagecolorallocate($source, 240, 210, 70);
        imagefill($source, 0, 0, $background);
        imagefilledrectangle($source, 90, 25, 230, 95, $accent);
        $written = imagepng($source, $sourcePath, 0);
        unset($source);
        $test->true($written, 'GD could not write the upload fixture.');

        $trailingMarker = 'KNIGHTBOARD_TRAILING_PAYLOAD_MUST_BE_REMOVED';
        $appended = file_put_contents($sourcePath, $trailingMarker, FILE_APPEND);
        $test->same(strlen($trailingMarker), $appended, 'Could not append the re-encoding test marker.');
        clearstatcache(true, $sourcePath);
        $sourceSize = filesize($sourcePath);
        $test->true(is_int($sourceSize) && $sourceSize > 0);

        $upload = $uploads->prepare([
            'name' => '../../avatar.php.exe',
            'type' => 'text/plain',
            'tmp_name' => $sourcePath,
            'error' => UPLOAD_ERR_OK,
            'size' => $sourceSize,
        ], 2_000_000);
        $test->true(is_array($upload), 'A valid PNG fixture was not prepared.');
        $test->same('image/png', (string) $upload['mime_type']);
        $test->same('avatar.php.exe', (string) $upload['original_name']);
        $test->same(320, (int) $upload['width']);
        $test->same(120, (int) $upload['height']);
        $test->true(
            preg_match('#^[0-9]{4}/[0-9]{2}/[a-f0-9]{40}\.png$#', (string) $upload['storage_name']) === 1,
            'Stored media did not receive a safe randomized PNG path.',
        );
        $test->same(
            preg_replace('/\.png$/', '_thumb.png', (string) $upload['storage_name']),
            (string) $upload['thumbnail_name'],
        );
        foreach (['storage_name', 'thumbnail_name'] as $nameKey) {
            $storedName = (string) $upload[$nameKey];
            $test->notContains('..', $storedName);
            $test->notContains('avatar', $storedName);
            $test->notContains('\\', $storedName);
        }

        $destination = $config->uploadPath . DIRECTORY_SEPARATOR
            . str_replace('/', DIRECTORY_SEPARATOR, (string) $upload['storage_name']);
        $thumbnail = $config->uploadPath . DIRECTORY_SEPARATOR
            . str_replace('/', DIRECTORY_SEPARATOR, (string) $upload['thumbnail_name']);
        $test->true(is_file($destination), 'Re-encoded media file was not created.');
        $test->true(is_file($thumbnail), 'Thumbnail file was not created.');
        $uploadRoot = realpath($config->uploadPath);
        $destinationReal = realpath($destination);
        $thumbnailReal = realpath($thumbnail);
        $test->true(
            is_string($uploadRoot)
                && is_string($destinationReal)
                && str_starts_with($destinationReal, $uploadRoot . DIRECTORY_SEPARATOR),
            'Stored media escaped the configured upload directory.',
        );
        $test->true(
            is_string($uploadRoot)
                && is_string($thumbnailReal)
                && str_starts_with($thumbnailReal, $uploadRoot . DIRECTORY_SEPARATOR),
            'Thumbnail escaped the configured upload directory.',
        );

        $encodedBytes = file_get_contents($destination);
        $test->true(is_string($encodedBytes));
        $test->notContains($trailingMarker, (string) $encodedBytes, 'The uploaded image was copied instead of re-encoded.');
        $test->same((int) filesize($destination), (int) $upload['byte_size']);
        $test->same(hash_file('sha256', $destination), (string) $upload['sha256']);
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $test->same('image/png', (string) $finfo->file($destination));
        $storedDimensions = getimagesize($destination);
        $thumbnailDimensions = getimagesize($thumbnail);
        $test->true(is_array($storedDimensions) && is_array($thumbnailDimensions));
        $test->same([320, 120], [(int) $storedDimensions[0], (int) $storedDimensions[1]]);
        $test->same([250, 94], [(int) $thumbnailDimensions[0], (int) $thumbnailDimensions[1]]);

        $uploads->attach($opPostId, $upload);
        $attachment = $pdo->query('SELECT * FROM attachments WHERE post_id = ' . $opPostId)->fetch();
        $test->true(is_array($attachment), 'Prepared media was not attached to the post.');
        $test->same((string) $upload['storage_name'], (string) $attachment['storage_name']);
        $test->same((string) $upload['thumbnail_name'], (string) $attachment['thumbnail_name']);
        $test->same((string) $upload['sha256'], (string) $attachment['sha256']);

        $locatedMedia = $uploads->locate((string) $upload['storage_name']);
        $locatedThumbnail = $uploads->locate((string) $upload['thumbnail_name']);
        $test->same(['path' => $destination, 'mime' => 'image/png'], $locatedMedia);
        $test->same(['path' => $thumbnail, 'mime' => 'image/png'], $locatedThumbnail);
        $test->same(null, $uploads->locate('../' . (string) $upload['storage_name']));
        $test->same(null, $uploads->locate(gmdate('Y/m') . '/' . str_repeat('f', 40) . '.png'));

        $fakePath = $temporaryPath . DIRECTORY_SEPARATOR . 'plain-text-disguised-as.png';
        $fakeBytes = 'This is plain text, not an image.';
        $test->same(strlen($fakeBytes), file_put_contents($fakePath, $fakeBytes));
        $test->throws(
            static fn (): ?array => $uploads->prepare([
                'name' => 'apparently-safe.png',
                'type' => 'image/png',
                'tmp_name' => $fakePath,
                'error' => UPLOAD_ERR_OK,
                'size' => strlen($fakeBytes),
            ], 2_000_000),
            InvalidArgumentException::class,
            'Only JPEG, PNG, GIF, and WebP images are allowed',
        );
        $test->same(1, (int) $pdo->query('SELECT COUNT(*) FROM attachments')->fetchColumn());

        $test->true($uploads->removeForPost($opPostId), 'Attached upload could not be removed.');
        $test->same(null, $uploads->locate((string) $upload['storage_name']));
        $test->false(is_file($destination), 'Stored media remained after removal.');
        $test->false(is_file($thumbnail), 'Thumbnail remained after removal.');
    });

    $reportId = 0;
    $suite->test('public reporting and password deletion preserve privacy', static function (TestSuite $test) use (
        $publicModeration,
        $security,
        $config,
        $pdo,
        $threadId,
        $opPostId,
        $replyPostId,
        &$reportId,
    ): void {
        $destination = $publicModeration->report(
            $opPostId,
            formRequest($security, $config, 'unused', [
                'category' => 'off-topic',
                'details' => 'Please review this post.',
            ]),
        );
        $test->same(['board_slug' => 'chess', 'thread_id' => $threadId], $destination);
        $report = $pdo->query('SELECT * FROM reports WHERE post_id = ' . $opPostId)->fetch();
        $reportId = (int) $report['id'];
        $test->same('open', (string) $report['status']);
        $test->same(64, strlen((string) $report['reporter_token_hash']));

        $test->throws(
            static fn (): array => $publicModeration->report(
                $opPostId,
                formRequest($security, $config, 'unused', ['category' => 'spam', 'details' => 'Duplicate']),
            ),
            InvalidArgumentException::class,
            'already have an open report',
        );

        $test->throws(
            static fn (): array => $publicModeration->deleteOwn(
                $replyPostId,
                formRequest($security, $config, 'unused', ['deletion_password' => 'wrong-password']),
            ),
            InvalidArgumentException::class,
            'not correct',
        );
        $test->same(0, (int) $pdo->query('SELECT is_deleted FROM posts WHERE id = ' . $replyPostId)->fetchColumn());

        $deletedDestination = $publicModeration->deleteOwn(
            $replyPostId,
            formRequest($security, $config, 'unused', ['deletion_password' => 'reply-password']),
        );
        $test->same(['board_slug' => 'chess', 'thread_id' => $threadId], $deletedDestination);
        $deleted = $pdo->query('SELECT * FROM posts WHERE id = ' . $replyPostId)->fetch();
        $test->same(1, (int) $deleted['is_deleted']);
        $test->same('', (string) $deleted['body']);
        $test->same('', (string) $deleted['name']);
        $test->same('!', (string) $deleted['delete_password_hash']);
        $test->same(hash('sha256', 'deleted-post:' . $replyPostId), (string) $deleted['poster_token_hash']);
        $test->same('Deleted by poster', (string) $deleted['deleted_reason']);
    });

    $suite->test('owner setup, logout, login, and report resolution work', static function (TestSuite $test) use (
        $adminService,
        $security,
        $config,
        $pdo,
        $reportId,
    ): void {
        $test->false($adminService->hasAdmins());
        $adminService->setupOwner(
            formRequest($security, $config, 'unused', [
                'username' => 'Knight.Admin',
                'password' => 'a-long-owner-password',
                'password_confirmation' => 'a-long-owner-password',
            ]),
        );
        $test->true($adminService->hasAdmins());
        $owner = $adminService->current();
        $test->true(is_array($owner));
        $test->same('Knight.Admin', (string) $owner['username']);
        $test->same('owner', (string) $owner['role']);
        $test->true(
            password_verify(
                'a-long-owner-password',
                (string) $pdo->query('SELECT password_hash FROM admins WHERE id = ' . (int) $owner['id'])->fetchColumn(),
            ),
        );

        $test->throws(
            static fn (): null => ($adminService->setupOwner(
                formRequest($security, $config, 'unused', [
                    'username' => 'OtherOwner',
                    'password' => 'another-long-password',
                    'password_confirmation' => 'another-long-password',
                ]),
            )) ?? null,
            InvalidArgumentException::class,
            'already complete',
        );

        $adminService->logout(formRequest($security, $config, 'unused', []));
        $test->same(null, $adminService->current());
        $test->throws(
            static fn (): null => ($adminService->login(
                formRequest($security, $config, 'unused', [
                    'username' => 'knight.admin',
                    'password' => 'wrong-password',
                ]),
            )) ?? null,
            InvalidArgumentException::class,
            'not correct',
        );
        $adminService->login(
            formRequest($security, $config, 'unused', [
                'username' => 'KNIGHT.ADMIN',
                'password' => 'a-long-owner-password',
            ]),
        );
        $owner = $adminService->current();
        $test->true(is_array($owner));
        $test->same('owner', (string) $owner['role']);
        $test->true(role_allows('owner', 'staff'));
        $test->false(role_allows('moderator', 'settings'));

        $adminService->resolveReport(
            $owner,
            $reportId,
            formRequest($security, $config, 'unused', ['status' => 'dismissed', 'note' => 'Reviewed in tests.']),
        );
        $report = $pdo->query('SELECT status, resolved_by, resolution_note FROM reports WHERE id = ' . $reportId)->fetch();
        $test->same('dismissed', (string) $report['status']);
        $test->same((int) $owner['id'], (int) $report['resolved_by']);
        $test->same('Reviewed in tests.', (string) $report['resolution_note']);
        $test->true((int) $pdo->query('SELECT COUNT(*) FROM audit_log')->fetchColumn() >= 4);
    });
} catch (Throwable $exception) {
    $suite->fail('test bootstrap and teardown', $exception);
} finally {
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    unset(
        $boards,
        $adminService,
        $publicModeration,
        $posting,
        $uploads,
        $settings,
        $security,
        $pdo,
        $database,
    );
    gc_collect_cycles();
    try {
        removeTestTree($temporaryPath);
    } catch (Throwable $exception) {
        $suite->fail('temporary test storage cleanup', $exception);
    }
}

exit($suite->report());
