CREATE TABLE boards (
    id INTEGER PRIMARY KEY,
    slug TEXT NOT NULL COLLATE NOCASE UNIQUE
        CHECK (slug GLOB '[a-z0-9]*' AND length(slug) BETWEEN 1 AND 12),
    name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 80),
    description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 500),
    rules TEXT NOT NULL DEFAULT '' CHECK (length(rules) <= 5000),
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_locked INTEGER NOT NULL DEFAULT 0 CHECK (is_locked IN (0, 1)),
    created_at TEXT NOT NULL
) STRICT;

CREATE TABLE threads (
    id INTEGER PRIMARY KEY,
    board_id INTEGER NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    bumped_at TEXT NOT NULL,
    is_sticky INTEGER NOT NULL DEFAULT 0 CHECK (is_sticky IN (0, 1)),
    is_locked INTEGER NOT NULL DEFAULT 0 CHECK (is_locked IN (0, 1)),
    is_archived INTEGER NOT NULL DEFAULT 0 CHECK (is_archived IN (0, 1)),
    reply_count INTEGER NOT NULL DEFAULT 0 CHECK (reply_count >= 0),
    attachment_count INTEGER NOT NULL DEFAULT 0 CHECK (attachment_count >= 0)
) STRICT;

CREATE TABLE admins (
    id INTEGER PRIMARY KEY,
    username TEXT NOT NULL COLLATE NOCASE UNIQUE
        CHECK (length(username) BETWEEN 3 AND 40),
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'moderator'
        CHECK (role IN ('owner', 'administrator', 'moderator')),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at TEXT NOT NULL,
    last_login_at TEXT
) STRICT;

CREATE TABLE posts (
    id INTEGER PRIMARY KEY,
    thread_id INTEGER NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    board_id INTEGER NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
    is_op INTEGER NOT NULL DEFAULT 0 CHECK (is_op IN (0, 1)),
    name TEXT NOT NULL DEFAULT '' CHECK (length(name) <= 80),
    is_sage INTEGER NOT NULL DEFAULT 0 CHECK (is_sage IN (0, 1)),
    subject TEXT NOT NULL DEFAULT '' CHECK (length(subject) <= 120),
    body TEXT NOT NULL DEFAULT '' CHECK (length(body) <= 20000),
    fen TEXT NOT NULL DEFAULT '' CHECK (length(fen) <= 120),
    pgn TEXT NOT NULL DEFAULT '' CHECK (length(pgn) <= 20000),
    poster_token_hash TEXT NOT NULL CHECK (length(poster_token_hash) = 64),
    delete_password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    is_deleted INTEGER NOT NULL DEFAULT 0 CHECK (is_deleted IN (0, 1)),
    deleted_at TEXT,
    deleted_reason TEXT NOT NULL DEFAULT '' CHECK (length(deleted_reason) <= 500),
    moderated_by INTEGER REFERENCES admins(id) ON DELETE SET NULL
) STRICT;

CREATE UNIQUE INDEX idx_posts_one_op_per_thread
ON posts(thread_id) WHERE is_op = 1;

CREATE INDEX idx_threads_board_bump
ON threads(board_id, is_archived, is_sticky DESC, bumped_at DESC);

CREATE INDEX idx_posts_thread_created
ON posts(thread_id, created_at, id);

CREATE INDEX idx_posts_board_created
ON posts(board_id, created_at DESC);

CREATE INDEX idx_posts_token_created
ON posts(poster_token_hash, created_at DESC);

CREATE TABLE attachments (
    id INTEGER PRIMARY KEY,
    post_id INTEGER NOT NULL UNIQUE REFERENCES posts(id) ON DELETE CASCADE,
    storage_name TEXT NOT NULL UNIQUE,
    thumbnail_name TEXT NOT NULL UNIQUE,
    original_name TEXT NOT NULL CHECK (length(original_name) <= 160),
    mime_type TEXT NOT NULL CHECK (mime_type IN ('image/jpeg', 'image/png', 'image/gif', 'image/webp')),
    byte_size INTEGER NOT NULL CHECK (byte_size > 0),
    width INTEGER NOT NULL CHECK (width > 0),
    height INTEGER NOT NULL CHECK (height > 0),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64),
    created_at TEXT NOT NULL
) STRICT;

CREATE INDEX idx_attachments_sha256 ON attachments(sha256);
