INSERT INTO boards (slug, name, description, rules, sort_order, created_at) VALUES
('chess', 'Chess', 'General chess discussion, games, players, and ideas.', 'Keep threads about chess. Use the analysis board for long game reviews.', 10, datetime('now')),
('analysis', 'Analysis', 'Positions, game reviews, engine lines, and endgames.', 'Include a FEN or PGN when it helps readers follow the position.', 20, datetime('now')),
('puzzles', 'Puzzles', 'Tactics, studies, compositions, and calculation challenges.', 'Put solutions behind spoiler markup: [spoiler]solution[/spoiler].', 30, datetime('now')),
('openings', 'Openings', 'Opening theory, repertoires, novelties, and traps.', 'Mention the opening or ECO code in the subject when possible.', 40, datetime('now')),
('events', 'Events', 'Tournaments, matches, streams, and club meetups.', 'Do not post private contact details without permission.', 50, datetime('now')),
('meta', 'Meta', 'Site feedback, moderation questions, and board requests.', 'Do not repost removed content or discuss private report details.', 60, datetime('now'));

INSERT INTO settings (key, value, updated_at) VALUES
('site_name', 'Knightboard', datetime('now')),
('tagline', 'Chess, one position at a time.', datetime('now')),
('default_name', 'Anonymous', datetime('now')),
('threads_per_page', '10', datetime('now')),
('preview_replies', '3', datetime('now')),
('reply_limit', '500', datetime('now')),
('bump_limit', '300', datetime('now')),
('post_cooldown_seconds', '8', datetime('now')),
('posts_per_minute', '6', datetime('now')),
('global_posts_per_minute', '120', datetime('now')),
('max_upload_bytes', '8388608', datetime('now')),
('rules_text', 'Post chess. Be constructive. No illegal content, spam, targeted harassment, or personal information. Reports are reviewed by staff.', datetime('now')),
('news_text', 'Welcome to Knightboard. Use FEN and PGN fields to keep analysis readable.', datetime('now')),
('registration_note', 'No accounts are required to post. A random browser token supports cooldowns and owner controls; IP addresses are never read or stored by the application.', datetime('now'));

