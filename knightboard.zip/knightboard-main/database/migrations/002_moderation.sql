CREATE TABLE reports (
    id INTEGER PRIMARY KEY,
    post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    reporter_token_hash TEXT NOT NULL CHECK (length(reporter_token_hash) = 64),
    category TEXT NOT NULL CHECK (category IN ('spam', 'harassment', 'illegal', 'off-topic', 'other')),
    details TEXT NOT NULL DEFAULT '' CHECK (length(details) <= 1000),
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'resolved', 'dismissed')),
    created_at TEXT NOT NULL,
    resolved_at TEXT,
    resolved_by INTEGER REFERENCES admins(id) ON DELETE SET NULL,
    resolution_note TEXT NOT NULL DEFAULT '' CHECK (length(resolution_note) <= 1000)
) STRICT;

CREATE UNIQUE INDEX idx_reports_one_open_per_token_post
ON reports(post_id, reporter_token_hash) WHERE status = 'open';

CREATE INDEX idx_reports_status_created
ON reports(status, created_at DESC);

CREATE TABLE blocked_tokens (
    id INTEGER PRIMARY KEY,
    token_hash TEXT NOT NULL UNIQUE CHECK (length(token_hash) = 64),
    reason TEXT NOT NULL CHECK (length(reason) BETWEEN 1 AND 500),
    expires_at TEXT,
    created_at TEXT NOT NULL,
    created_by INTEGER REFERENCES admins(id) ON DELETE SET NULL
) STRICT;

CREATE INDEX idx_blocked_tokens_expiry ON blocked_tokens(expires_at);

CREATE TABLE word_filters (
    id INTEGER PRIMARY KEY,
    pattern TEXT NOT NULL CHECK (length(pattern) BETWEEN 1 AND 200),
    replacement TEXT NOT NULL DEFAULT '' CHECK (length(replacement) <= 200),
    action TEXT NOT NULL DEFAULT 'reject' CHECK (action IN ('reject', 'replace', 'flag')),
    is_enabled INTEGER NOT NULL DEFAULT 1 CHECK (is_enabled IN (0, 1)),
    created_at TEXT NOT NULL,
    created_by INTEGER REFERENCES admins(id) ON DELETE SET NULL
) STRICT;

CREATE TABLE settings (
    key TEXT PRIMARY KEY CHECK (length(key) BETWEEN 1 AND 80),
    value TEXT NOT NULL CHECK (length(value) <= 20000),
    updated_at TEXT NOT NULL
) STRICT;

CREATE TABLE rate_limits (
    bucket_key TEXT NOT NULL,
    window_started_at INTEGER NOT NULL,
    hit_count INTEGER NOT NULL DEFAULT 0 CHECK (hit_count >= 0),
    updated_at INTEGER NOT NULL,
    PRIMARY KEY (bucket_key, window_started_at)
) WITHOUT ROWID, STRICT;

CREATE INDEX idx_rate_limits_updated ON rate_limits(updated_at);

CREATE TABLE audit_log (
    id INTEGER PRIMARY KEY,
    admin_id INTEGER REFERENCES admins(id) ON DELETE SET NULL,
    action TEXT NOT NULL CHECK (length(action) BETWEEN 1 AND 100),
    target_type TEXT NOT NULL DEFAULT '' CHECK (length(target_type) <= 50),
    target_id INTEGER,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
) STRICT;

CREATE INDEX idx_audit_log_created ON audit_log(created_at DESC);
CREATE INDEX idx_audit_log_admin ON audit_log(admin_id, created_at DESC);

