# Knightboard

I was curious to see what would happen if i asked codex to make a 4chan site but for chess. 

Knightboard is a privacy-first chess imageboard for PHP 8.5.8 and SQLite. Its board, thread, and reply views keep the conversation in front: compact imageboard styling, optional chess images, dedicated FEN and PGN fields, catalog and search views, anonymous posting, and no user accounts required.

The application does **not** read or store source IP addresses or proxy IP headers. Posting controls use a random browser token that is HMAC-hashed before storage. Web servers and hosting platforms have their own logs, so production operators must also apply the [no-IP logging configuration](docs/deployment.md#no-ip-logging-at-every-layer).

## What is included

- Boards, threads, replies, quoting, sage replies, pagination, catalogs, and search
- JPEG, PNG, GIF, and WebP uploads with server-side validation and thumbnails
- FEN position rendering and PGN fields for game analysis
- Password-based self-deletion and per-browser poster controls
- Reports, token-based posting restrictions, word filters, and rate limits
- A role-based admin area for moderation, boards, site settings, staff, reports, and audit history
- Automatic, ordered SQLite migrations on application boot

## Requirements

- PHP **8.5.8** (the supported runtime; older PHP releases are not supported)
- PHP extensions: `fileinfo`, `gd`, `mbstring`, `PDO`, and `pdo_sqlite`
- A web user that can write to `storage/`

There are no third-party Composer packages. The repository includes its own small PSR-4 autoloader, so Composer is optional unless you want to use its convenience scripts.

## Run locally

The first request creates `storage/app.key`, `storage/chessboard.sqlite`, session storage, upload storage, and applies all migrations.

### Windows with `C:\php\php.exe`

From PowerShell in the repository root:

```powershell
& C:\php\php.exe -v
& C:\php\php.exe -m
& C:\php\php.exe -S 127.0.0.1:8080 -t public router.php
```

Confirm the version is `8.5.8` and the required extensions listed above appear in the module output. Then open <http://127.0.0.1:8080/>.

For a one-click check and launch, double-click `knightboard-local.bat`. It verifies PHP and its extensions, runs the complete test suite, starts the server, and opens the site. From Command Prompt or PowerShell you can also use:

```bat
.\knightboard-local.bat test
.\knightboard-local.bat serve
```

`test` exits after testing, while `serve` skips the test suite. Set `KNIGHTBOARD_PHP` to override the PHP executable or `KNIGHTBOARD_PORT` to use a port other than `8080`.

To enable development error pages for that PowerShell session:

```powershell
$env:CHESSBOARD_DEBUG = '1'
& C:\php\php.exe -S 127.0.0.1:8080 -t public router.php
```

Do not enable debug output on a public deployment.

### Generic PHP

From the repository root:

```sh
php -v
php -m
php -S 127.0.0.1:8080 -t public router.php
```

Confirm PHP is `8.5.8`, then open <http://127.0.0.1:8080/>.

## Create the first administrator

The safest production setup is to create the first owner from the CLI before starting a public listener. Supply the password through the transient `CHESSBOARD_ADMIN_PASSWORD` environment variable so the console does not prompt visibly.

PowerShell 7 with `C:\php\php.exe`:

```powershell
$env:CHESSBOARD_ADMIN_PASSWORD = Read-Host 'Owner password' -MaskInput
try {
    & C:\php\php.exe bin\console.php admin:create owner owner
} finally {
    Remove-Item Env:CHESSBOARD_ADMIN_PASSWORD -ErrorAction SilentlyContinue
}
```

Bash or zsh with generic PHP:

```sh
read -r -s -p 'Owner password: ' CHESSBOARD_ADMIN_PASSWORD
printf '\n'
export CHESSBOARD_ADMIN_PASSWORD
php bin/console.php admin:create owner owner
unset CHESSBOARD_ADMIN_PASSWORD
```

Replace the username `owner` as desired. Usernames are 3–40 letters, numbers, dots, underscores, or dashes; passwords are 12–200 characters. The optional role is `owner`, `administrator`, or `moderator`.

For local setup, you can instead keep the server bound to `127.0.0.1`, visit <http://127.0.0.1:8080/admin/setup>, and create the owner in the browser. You are signed in automatically. Once any administrator exists, the web setup route no longer permits another first-owner account.

Additional owners, administrators, and moderators can then be managed under **Admin → Staff**.

## Configuration

Knightboard reads real process environment variables; it does not load `.env` files itself. `compose.yaml` reads a copied `.env` file through Compose interpolation, while native PHP deployments should set the same variables in PowerShell, the service manager, PHP-FPM, or the web-server environment.

| Variable | Default | Purpose |
| --- | --- | --- |
| `CHESSBOARD_STORAGE_PATH` | `<project>/storage` | Writable application data directory |
| `CHESSBOARD_DATABASE_PATH` | `<storage>/chessboard.sqlite` | SQLite database file |
| `CHESSBOARD_APP_KEY` | Generated in `<storage>/app.key` | HMAC key; if supplied, it must contain at least 32 characters |
| `CHESSBOARD_DEBUG` | `0` | Show exception details when set to a true value |
| `CHESSBOARD_MAX_UPLOAD_BYTES` | `8388608` | Hard upload ceiling in bytes, with a minimum of 1 MiB |

Site-level limits and text are managed in the admin settings area. Keep PHP's `upload_max_filesize` and `post_max_size` at least as large as the configured application upload limit.

## Storage permissions

Only `storage/` needs runtime write access. The web/PHP user must be able to create and update:

- `storage/app.key`
- `storage/chessboard.sqlite` and SQLite's `-wal`/`-shm` sidecars
- `storage/uploads/` and its date-based subdirectories
- `storage/sessions/`

For a typical Linux deployment using `www-data`:

```sh
sudo install -d -o www-data -g www-data -m 0770 storage storage/uploads storage/sessions
sudo chown -R www-data:www-data storage
sudo chmod -R u=rwX,g=rwX,o= storage
```

Use the actual PHP-FPM or Apache account on your system. Never put `storage/` under the public document root and never grant it world-write permission.

## Command-line operations

The console boots the same configuration and applies pending migrations before running a command:

```sh
php bin/console.php migrate
php bin/console.php database:stats
php bin/console.php cleanup
php bin/console.php admin:create <username> [owner|administrator|moderator]
```

`cleanup` removes expired transient rate-limit and old expired restriction records, then optimizes SQLite. On Windows, replace `php` with `& C:\php\php.exe` and use `bin\console.php`. Set `CHESSBOARD_ADMIN_PASSWORD` for `admin:create`; without it, the prompt explicitly displays typed input.

## Tests

The dependency-free test runner creates and removes its own temporary SQLite/storage directory:

```sh
php tests/run.php
```

On Windows with the requested PHP installation:

```powershell
& C:\php\php.exe tests\run.php
```

If Composer is installed, the equivalent command is:

```sh
composer test
```

## Docker Compose

Copy the example environment, build the PHP 8.5.8 Apache image, create the owner in a one-off non-public container, and then start the site:

```sh
cp .env.example .env
docker compose build
read -r -s -p 'Owner password: ' CHESSBOARD_ADMIN_PASSWORD
printf '\n'
export CHESSBOARD_ADMIN_PASSWORD
docker compose run --rm --user www-data -e CHESSBOARD_ADMIN_PASSWORD app php bin/console.php admin:create owner owner
unset CHESSBOARD_ADMIN_PASSWORD
docker compose up -d
docker compose logs -f app
```

PowerShell equivalent:

```powershell
Copy-Item .env.example .env
docker compose build
$env:CHESSBOARD_ADMIN_PASSWORD = Read-Host 'Owner password' -MaskInput
try {
    docker compose run --rm --user www-data -e CHESSBOARD_ADMIN_PASSWORD app php bin/console.php admin:create owner owner
} finally {
    Remove-Item Env:CHESSBOARD_ADMIN_PASSWORD -ErrorAction SilentlyContinue
}
docker compose up -d
docker compose logs -f app
```

Sign in at <http://127.0.0.1:8080/admin/login>. Application state is stored in the `knightboard_storage` named volume. The container's Apache access format omits client addresses and query strings, and its Apache error log is disabled to prevent incidental client-address persistence.

## Production and backups

Production web-server roots must point to `public/`, not the repository root. Deployment examples for Apache, nginx/PHP-FPM, HTTPS proxies, durable permissions, no-IP logging, backup, and restore are in [docs/deployment.md](docs/deployment.md).

For a consistent cold backup, stop writers and copy the **entire** `storage/` directory. The database, uploads, and `app.key` belong together. Retaining the key preserves browser-token ownership and restriction continuity.

## License

No license file is included. All rights remain with the repository owner unless a license is added.
