# Deploying Knightboard

Knightboard supports PHP **8.5.8** with SQLite. It has no package-install step. Each application or console boot opens the configured SQLite database and applies unapplied files in `database/migrations/` in filename order; `php bin/console.php migrate` is available for an explicit deployment check.

This guide treats IP privacy as an end-to-end deployment property. The PHP application does not inspect `REMOTE_ADDR`, `Forwarded`, `X-Forwarded-For`, or `X-Real-IP`, and its schema has no IP-address fields. A front proxy, CDN, web server, container platform, load balancer, firewall, or hosting control plane can still retain addresses independently; configure every layer you operate and verify any provider-managed layer separately.

## Production checklist

1. Install PHP 8.5.8 with `fileinfo`, `gd`, `mbstring`, `PDO`, and `pdo_sqlite`.
2. Deploy the code to a release directory such as `/srv/knightboard`.
3. Point the web document root to `/srv/knightboard/public`—never `/srv/knightboard`.
4. Give only the PHP/web account write access to `/srv/knightboard/storage`.
5. Set `CHESSBOARD_DEBUG=0` and a durable application key, or preserve the automatically generated `storage/app.key`.
6. Configure PHP upload limits and the front server's body limit at or above the desired application limit.
7. Disable or sanitize address logging at the public edge, every intermediate proxy, and the application web server.
8. Keep the new site private and create the owner with `php bin/console.php admin:create <username> owner` before opening public traffic.
9. Put the site behind HTTPS and check `/health/live` and `/health/ready`.
10. Back up the database, uploads, and application key together, then test a restore.

## Filesystem and environment

The code can be read-only. The selected PHP worker account must have read, write, create, rename, and delete access throughout the storage directory because SQLite WAL mode creates `chessboard.sqlite-wal` and `chessboard.sqlite-shm` beside the database.

```sh
cd /srv/knightboard
sudo install -d -o www-data -g www-data -m 0770 storage storage/uploads storage/sessions
sudo chown -R www-data:www-data storage
sudo chmod -R u=rwX,g=rwX,o= storage
```

Substitute the actual PHP-FPM/Apache account. Do not use mode `0777` and do not serve `storage/` as static files.

Set environment variables in the PHP-FPM pool, systemd unit, Apache environment, or container configuration:

```text
CHESSBOARD_STORAGE_PATH=/srv/knightboard/storage
CHESSBOARD_DATABASE_PATH=/srv/knightboard/storage/chessboard.sqlite
CHESSBOARD_APP_KEY=<a unique secret containing at least 32 characters>
CHESSBOARD_DEBUG=0
CHESSBOARD_MAX_UPLOAD_BYTES=8388608
```

Generate a 256-bit hexadecimal key with the same PHP runtime:

```sh
php -r 'echo bin2hex(random_bytes(32)), PHP_EOL;'
```

If `CHESSBOARD_APP_KEY` is absent or empty, Knightboard generates `storage/app.key`. Preserve that file across releases and restores. Changing the key invalidates the continuity of HMAC-hashed browser identities used for self-service controls, rate limits, reports, and posting restrictions.

Knightboard does not parse `.env`; `.env.example` is wired to `compose.yaml` through Compose interpolation only.

## First-owner setup

There is intentionally no default account. The safest production path is to create the first owner from the deployment shell before starting or admitting public web traffic. Set the password through the process environment because the fallback interactive console prompt is visible:

```sh
cd /srv/knightboard
read -r -s -p 'Owner password: ' CHESSBOARD_ADMIN_PASSWORD
printf '\n'
export CHESSBOARD_ADMIN_PASSWORD
sudo -u www-data --preserve-env=CHESSBOARD_ADMIN_PASSWORD php bin/console.php admin:create owner owner
unset CHESSBOARD_ADMIN_PASSWORD
```

Use the actual PHP worker account and replace the username `owner`. Usernames allow 3–40 letters, numbers, `.`, `_`, or `-`; passwords must be 12–200 characters. The optional role is `owner`, `administrator`, or `moderator`. Prefer a service-manager credential or secret injection mechanism where available so the password is neither a command argument nor saved in shell history or `.env`.

For a protected local installation, the browser flow remains available: bind to loopback or a temporary allowlist, browse to `/admin/setup`, create the owner, and confirm the dashboard before admitting traffic. The web form refuses setup after any administrator exists. An unattended fresh public instance could therefore be claimed by its first visitor, which is why CLI setup is recommended.

## Apache example

The repository includes `public/.htaccess`, but a production virtual host can route directly without per-request override lookup. This example assumes Apache is executing PHP 8.5.8 through the handler configured by your distribution:

```apache
<VirtualHost *:443>
    ServerName chess.example
    DocumentRoot /srv/knightboard/public

    <Directory /srv/knightboard/public>
        AllowOverride None
        Options -Indexes
        Require all granted
        FallbackResource /index.php
    </Directory>

    # Deliberately excludes %a/%h and does not record the query string.
    LogFormat "%{%Y-%m-%dT%H:%M:%S%z}t %m %U %H %>s %B" knightboard_no_ip
    CustomLog /var/log/apache2/knightboard-access.log knightboard_no_ip

    # Apache error records can contain a client address. Discard them when the
    # policy is that no address may be persisted at all. Send application-only
    # PHP errors to a separate destination configured in php.ini if required.
    ErrorLog /dev/null

    SSLEngine on
    # SSLCertificateFile /path/to/fullchain.pem
    # SSLCertificateKeyFile /path/to/privkey.pem
</VirtualHost>
```

Enable the PHP 8.5 handler and TLS modules appropriate to the operating system. If you choose to use `public/.htaccess` instead, enable `mod_rewrite` and `AllowOverride FileInfo` (or `All`) for that directory.

For Apache acting as a reverse proxy, do not append client addresses to forwarding headers:

```apache
RequestHeader unset Forwarded
RequestHeader unset X-Forwarded-For
RequestHeader unset X-Real-IP
ProxyAddHeaders Off
```

Those directives require `mod_headers`; proxying requires the relevant proxy module. Apply the no-address `LogFormat` to that public-facing virtual host as well.

## nginx with PHP-FPM

This example exposes only files under `public/`, sends all dynamic routes to the front controller, omits addresses and query strings from the access log, and clears address-bearing FastCGI parameters after the standard include:

```nginx
log_format knightboard_no_ip '$time_iso8601 $request_method $uri $server_protocol '
                             '$status $body_bytes_sent';

server {
    listen 443 ssl;
    server_name chess.example;
    root /srv/knightboard/public;
    index index.php;
    client_max_body_size 25m;

    access_log /var/log/nginx/knightboard-access.log knightboard_no_ip;

    # nginx error messages can contain client addresses. /dev/null is the
    # strict option when no such data may be persisted.
    error_log /dev/null crit;

    location / {
        try_files $uri /index.php$is_args$args;
    }

    location = /index.php {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root/index.php;
        fastcgi_param SCRIPT_NAME /index.php;
        fastcgi_param HTTPS $https if_not_empty;

        # These override address-bearing values from common fastcgi_params.
        fastcgi_param REMOTE_ADDR "";
        fastcgi_param HTTP_FORWARDED "";
        fastcgi_param HTTP_X_FORWARDED_FOR "";
        fastcgi_param HTTP_X_REAL_IP "";

        fastcgi_pass unix:/run/php/php8.5-fpm.sock;
    }

    location ~ \.php$ {
        return 404;
    }

    ssl_certificate /path/to/fullchain.pem;
    ssl_certificate_key /path/to/privkey.pem;
}
```

Confirm the PHP-FPM socket path for your system. When TLS terminates at a trusted proxy before this nginx server, have the trusted hop set the scheme and set `fastcgi_param HTTPS on;` here only for the TLS-only virtual host; the application intentionally does not trust arbitrary forwarded headers.

## No-IP logging at every layer

The custom access formats above contain a timestamp, HTTP method, path, protocol, response status, and byte count. They intentionally omit:

- Apache `%a` and `%h`
- nginx `$remote_addr`, `$realip_remote_addr`, and `$proxy_add_x_forwarded_for`
- `Forwarded`, `X-Forwarded-For`, and `X-Real-IP`
- query strings, referrers, and user agents

Merely changing the application server is not sufficient. At each reverse proxy or load balancer:

1. Replace the default access format; do not merely add a second sanitized log while leaving the default enabled.
2. Disable error-log persistence or send errors through a proven redaction stage, because protocol and body-limit errors often include the peer address.
3. Clear incoming address headers and do not generate replacements for the upstream application:

   ```nginx
   proxy_set_header Forwarded "";
   proxy_set_header X-Forwarded-For "";
   proxy_set_header X-Real-IP "";
   ```

4. Disable CDN, WAF, ingress-controller, service-mesh, platform request, and load-balancer logs that retain source addresses. Provider privacy settings and retention policies are outside Knightboard and must be checked with that provider.
5. Check crash reports, APM, traces, metrics labels, packet capture, firewall logs, and database-query logs for copied request metadata.
6. Generate a request, then inspect every configured sink to verify that neither the direct address nor a forwarded address was written.

An internet server must transiently receive network-layer addressing to return a response. The deployable privacy guarantee is that the application never consumes it and controlled infrastructure does not persist or forward it.

## Reverse-proxy HTTPS and cookies

Knightboard marks session and poster cookies `Secure` when PHP's `HTTPS` server variable is on. If TLS terminates upstream, configure the trusted application-facing server to set `HTTPS=on`; forwarding `X-Forwarded-Proto` alone is not interpreted by the application.

Keep the application listener private. The supplied Compose mapping defaults to `127.0.0.1:8080`, which is suitable for a reverse proxy on the same host. At the trusted edge, overwrite (do not pass through) scheme headers, clear address headers as shown above, and redirect plain HTTP to HTTPS.

## Docker Compose

The supplied image is built from `php:8.5.8-apache-bookworm`, installs only the declared PHP extension support, serves `public/`, and stores mutable data in a named volume.

```sh
cp .env.example .env
php -r 'echo bin2hex(random_bytes(32)), PHP_EOL;'
# Put the generated value after CHESSBOARD_APP_KEY= in .env.
docker compose build
read -r -s -p 'Owner password: ' CHESSBOARD_ADMIN_PASSWORD
printf '\n'
export CHESSBOARD_ADMIN_PASSWORD
docker compose run --rm --user www-data -e CHESSBOARD_ADMIN_PASSWORD app php bin/console.php admin:create owner owner
unset CHESSBOARD_ADMIN_PASSWORD
docker compose up -d
docker compose ps
```

The container replaces Apache's default access log with the no-address format and discards Apache's error log because it can attach peer addresses. PHP's own error destination remains container standard error and application exceptions do not add request addresses. Review the container runtime's logging driver and any proxy in front of it as separate layers.

After the health check reports healthy, sign in through the loopback-bound port or protected HTTPS proxy. The one-off `admin:create` container does not publish a port and runs as `www-data`, preserving correct ownership in the storage volume.

## Operations console

The console loads the same configuration and applies pending migrations before each command:

```sh
php bin/console.php migrate
php bin/console.php database:stats
php bin/console.php cleanup
php bin/console.php admin:create <username> [owner|administrator|moderator]
```

`cleanup` prunes expired transient rate limits and old expired token restrictions, then runs SQLite optimization. Run it as the same operating-system user as PHP so database and key ownership stay consistent. Supply `CHESSBOARD_ADMIN_PASSWORD` transiently for `admin:create`; otherwise its prompt warns that input is visible.

## Tests before release

Run the dependency-free suite using the same PHP 8.5.8 build and extensions as production:

```sh
php tests/run.php
```

Or, when Composer is available:

```sh
composer test
```

The runner uses temporary storage and a temporary SQLite database and cleans them up; it does not need or alter production storage.

## Backup

### Consistent cold backup

A cold copy is the simplest way to keep the SQLite database, WAL state, uploads, and key consistent:

```sh
sudo systemctl stop knightboard-php.service
sudo cp -a /srv/knightboard/storage /var/backups/knightboard-storage-YYYYMMDD-HHMMSS
sudo systemctl start knightboard-php.service
```

Replace the service name and timestamp with real values. If Apache or a shared PHP-FPM pool owns the deployment, drain or stop the relevant writer instead. Do not copy only `chessboard.sqlite` while writes continue; WAL transactions may be outside that file.

For Compose, keep the container (and therefore writers) stopped while copying the whole mounted directory:

```sh
docker compose stop app
docker compose cp app:/var/www/html/storage ./knightboard-storage-backup
docker compose start app
```

Archive and encrypt the resulting directory with your normal backup system. Sessions can be omitted only if losing active logins is acceptable; the database, `uploads/`, and `app.key` are essential.

### Online SQLite backup

When downtime is impossible and the SQLite CLI is installed, use SQLite's online backup operation instead of copying the live main file:

```sh
sqlite3 /srv/knightboard/storage/chessboard.sqlite ".timeout 5000" ".backup '/var/backups/knightboard-YYYYMMDD-HHMMSS.sqlite'"
```

Uploads can change immediately before or after an online database snapshot, so coordinate a brief posting pause or use a filesystem snapshot if database-to-file consistency must be exact. Copy `uploads/` and `app.key` with the database backup.

## Restore

1. Stop all application writers.
2. Move the failed storage directory aside; do not overwrite the only remaining copy.
3. Restore the complete backup to the configured `CHESSBOARD_STORAGE_PATH`.
4. Restore ownership and `u=rwX,g=rwX,o=` permissions for the PHP user.
5. Start the application. Boot applies only migrations newer than the restored `schema_migrations` records.
6. Verify `/health/ready`, a board page, an uploaded image, admin login, and a test post/reply.

Keep at least one off-host, encrypted backup and periodically rehearse this restore process.
