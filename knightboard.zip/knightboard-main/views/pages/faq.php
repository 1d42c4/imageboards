<article class="prose-page">
    <header><p class="eyebrow">Site information</p><h1>Frequently asked questions</h1></header>
    <h2>Do I need an account?</h2>
    <p>No. Public posting is anonymous. A display name is optional, and blank names appear as <?= e($settings['default_name'] ?? 'Anonymous') ?>.</p>
    <h2>How do replies and quotes work?</h2>
    <p>Open a thread and post below it. Write <code>&gt;&gt;123</code> to link to post 123, or use the post’s Quote action. Posts show backlinks when another post quotes them.</p>
    <h2>What are FEN and PGN fields for?</h2>
    <p>Paste a complete FEN to show an accessible board diagram beside your comment. Paste PGN to include copyable game notation without making it the visual focus.</p>
    <h2>What does sage mean?</h2>
    <p>A sage reply is added normally but does not move the thread to the top of the board. Threads also stop bumping after the site’s bump limit.</p>
    <h2>How do I delete my post?</h2>
    <p>Use its Actions menu and enter the delete key chosen when posting. The site’s script creates and remembers a random key in this browser, but you can choose your own.</p>
    <h2>Why can’t a restriction permanently stop somebody?</h2>
    <p>The site deliberately does not collect IP addresses or fingerprint visitors. A person can clear a browser token. Slow modes, global rate limits, filters, reports, and active moderation handle abuse without pretending a cookie is a permanent identity.</p>
    <h2>What images are accepted?</h2>
    <p>JPEG, PNG, GIF, and WebP images are decoded and re-encoded before storage. This removes EXIF and other embedded metadata; animated GIFs are stored as a safe static image.</p>
</article>

