<article class="prose-page">
    <header><p class="eyebrow">Site information</p><h1>Rules</h1><p>Keep the board useful enough that the next player wants to join the analysis.</p></header>
    <ol class="rule-list">
        <li><strong>Post chess.</strong> Use the relevant board and keep /meta/ for the site itself.</li>
        <li><strong>Challenge ideas, not people.</strong> No targeted harassment, threats, doxxing, or publishing private information.</li>
        <li><strong>No illegal or exploitative content.</strong> It will be removed and may require action outside this site.</li>
        <li><strong>No spam or manipulation.</strong> Repetitive promotion, flooding, automated posting, and report abuse are not welcome.</li>
        <li><strong>Label spoilers.</strong> Hide puzzle solutions with <code>[spoiler]solution[/spoiler]</code>.</li>
        <li><strong>Respect event participants.</strong> Do not post private contact information, cheat accusations without credible evidence, or instructions for disrupting events.</li>
    </ol>
    <h2>Board-specific rules</h2>
    <p>Each board can add a short rule set beneath its title. Board rules supplement these site-wide rules.</p>
    <h2>Moderation</h2>
    <p><?= nl2br(e($settings['rules_text'] ?? 'Reports are reviewed by staff.')) ?></p>
    <p>Staff may remove posts or images, close, sticky, or archive threads, apply content filters, and temporarily restrict a random anonymous browser token. Moderation never uses an IP address.</p>
</article>

