<article class="prose-page">
    <header><p class="eyebrow">Site information</p><h1>Privacy</h1><p>Anonymous should mean something concrete.</p></header>
    <section class="privacy-promise"><h2>The short version</h2><p><strong>The application never reads, stores, hashes, displays, or uses your IP address.</strong> It does not collect user-agent fingerprints and contains no third-party analytics or CAPTCHA.</p></section>
    <h2>What is stored</h2>
    <ul>
        <li>Your post text, optional name, subject, FEN, PGN, and upload.</li>
        <li>A one-way Argon2id hash of the delete key you choose.</li>
        <li>A keyed hash of a random 256-bit browser token for posting cooldowns, “You” labels, duplicate reports, and temporary moderator restrictions. The raw token stays in an HttpOnly cookie.</li>
        <li>A session cookie for form security and, for staff, administrator sign-in.</li>
        <li>Reports and staff audit actions. Audit records identify the staff account, action, target, reason, and time—never a visitor’s network address.</li>
    </ul>
    <h2>Images</h2>
    <p>Uploads are decoded and re-encoded to remove EXIF, GPS, profiles, comments, and other original metadata. A cleaned display filename is retained. The upload is stored outside the public document root and served only through a validated media route.</p>
    <h2>Deletion and moderation</h2>
    <p>Deleting a post purges its text, name, chess data, attachment, delete credential, and anonymous token hash. A small numbered tombstone remains so quote links still make sense. Staff removals work the same way. Reports are retained with their resolution for accountability.</p>
    <h2>Infrastructure</h2>
    <p>A web server necessarily receives a network connection while answering it. The included production guidance disables access logs and strips forwarded-address headers so that address is not retained outside the application. Operators must keep that configuration intact; application code alone cannot control a hosting provider’s network logs.</p>
    <h2>Local preferences</h2>
    <p>The theme and auto-generated delete key are stored only in your browser. They are not sent until the delete key is used in a posting or deletion form.</p>
</article>

