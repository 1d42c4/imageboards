<header class="board-header">
    <p class="board-symbol" aria-hidden="true">♟</p>
    <h1>/<?= e($board['slug']) ?>/ — <?= e($board['name']) ?></h1>
    <p><?= e($board['description']) ?></p>
    <nav class="board-actions" aria-label="Board views">[ <a href="/<?= e($board['slug']) ?>/">Index</a> / <a href="/<?= e($board['slug']) ?>/catalog">Catalog</a> / <a href="/<?= e($board['slug']) ?>/archive">Archive</a> / <a href="/<?= e($board['slug']) ?>/search">Search</a> ]</nav>
</header>

<?php if (trim((string) $board['rules']) !== ''): ?><details class="board-rules"><summary>Board rules</summary><p><?= nl2br(e($board['rules'])) ?></p></details><?php endif; ?>

<?php if ((int) $board['is_locked'] === 0): ?>
<?= $view->partial('components/post_form', [
    'action' => '/' . $board['slug'] . '/new', 'isReply' => false, 'openForm' => $threads === [],
    'csrfToken' => $csrfToken, 'formStamp' => $formStamp, 'settings' => $settings,
]) ?>
<?php else: ?><p class="closed-notice">This board is currently read-only.</p><?php endif; ?>

<hr class="board-divider">
<section class="thread-list" aria-label="Threads">
<?php if ($threads === []): ?>
    <p class="empty-state">No threads on /<?= e($board['slug']) ?>/ yet.</p>
<?php endif; ?>
<?php foreach ($threads as $thread): ?>
    <section class="thread" id="t<?= (int) $thread['id'] ?>" aria-label="Thread <?= (int) $thread['id'] ?>">
        <?= $view->partial('components/post', [
            'post' => $thread, 'thread' => $thread, 'board' => $board, 'threadId' => (int) $thread['id'],
            'isOp' => true, 'backlinks' => [], 'posterTokenHash' => $posterTokenHash,
            'settings' => $settings, 'csrfToken' => $csrfToken,
        ]) ?>
        <?php if ((int) $thread['omitted'] > 0): ?><p class="omitted"><a href="/<?= e($board['slug']) ?>/thread/<?= (int) $thread['id'] ?>"><?= (int) $thread['omitted'] ?> replies omitted.</a> Click to view the full thread.</p><?php endif; ?>
        <div class="reply-preview">
        <?php foreach ($thread['replies'] as $reply): ?>
            <?= $view->partial('components/post', [
                'post' => $reply, 'thread' => $thread, 'board' => $board, 'threadId' => (int) $thread['id'],
                'isOp' => false, 'backlinks' => [], 'posterTokenHash' => $posterTokenHash,
                'settings' => $settings, 'csrfToken' => $csrfToken,
            ]) ?>
        <?php endforeach; ?>
        </div>
        <p class="thread-link"><a href="/<?= e($board['slug']) ?>/thread/<?= (int) $thread['id'] ?>">View thread (<?= (int) $thread['reply_count'] ?> replies)</a></p>
    </section>
<?php endforeach; ?>
</section>

<?php if ($pages > 1): ?>
<nav class="pagination" aria-label="Board pages">
    <?php for ($number = 1; $number <= $pages; $number++): ?>
        <?php if ($number === $page): ?><strong aria-current="page"><?= $number ?></strong><?php else: ?><a href="?page=<?= $number ?>"><?= $number ?></a><?php endif; ?>
    <?php endfor; ?>
</nav>
<?php endif; ?>
