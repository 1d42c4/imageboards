<?php if (!role_allows((string) $admin['role'], 'boards')): ?><div class="admin-panel empty-state">Your role can view boards but cannot change them.</div><?php else: ?>
<section class="admin-panel">
    <header><div><p class="eyebrow">Structure</p><h2>Create a board</h2></div></header>
    <form action="/admin/boards" method="post" class="admin-form board-form">
        <input type="hidden" name="_token" value="<?= e($csrfToken) ?>">
        <label>Slug <input name="slug" required maxlength="12" pattern="[a-z0-9]+" placeholder="strategy"></label>
        <label>Name <input name="name" required maxlength="80" placeholder="Strategy"></label>
        <label>Order <input name="sort_order" type="number" value="70"></label>
        <label class="wide-field">Description <input name="description" maxlength="500"></label>
        <label class="wide-field">Rules <textarea name="rules" rows="3" maxlength="5000"></textarea></label>
        <button type="submit" class="primary-button">Create board</button>
    </form>
</section>

<section class="board-admin-grid">
<?php foreach ($navBoards as $item): ?>
<article class="admin-panel">
    <header><div><p class="eyebrow"><?= (int) $item['thread_count'] ?> threads · <?= (int) $item['post_count'] ?> posts</p><h2>/<?= e($item['slug']) ?>/</h2></div><a href="/<?= e($item['slug']) ?>/" target="_blank" rel="noreferrer">View ↗</a></header>
    <form action="/admin/boards" method="post" class="admin-form board-form">
        <input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
        <label>Slug <input name="slug" required maxlength="12" pattern="[a-z0-9]+" value="<?= e($item['slug']) ?>"></label>
        <label>Name <input name="name" required maxlength="80" value="<?= e($item['name']) ?>"></label>
        <label>Order <input name="sort_order" type="number" value="<?= (int) $item['sort_order'] ?>"></label>
        <label class="wide-field">Description <input name="description" maxlength="500" value="<?= e($item['description']) ?>"></label>
        <label class="wide-field">Rules <textarea name="rules" rows="3" maxlength="5000"><?= e($item['rules']) ?></textarea></label>
        <label class="check-label"><input type="checkbox" name="is_locked" value="1"<?= (int) $item['is_locked'] === 1 ? ' checked' : '' ?>> Read-only board</label>
        <button type="submit">Save board</button>
    </form>
    <?php if ((int) $item['thread_count'] === 0): ?><form action="/admin/boards/<?= (int) $item['id'] ?>/delete" method="post" class="delete-board-form"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><button type="submit" class="danger-button" data-confirm="Delete /<?= e($item['slug']) ?>/?">Delete empty board</button></form><?php endif; ?>
</article>
<?php endforeach; ?>
</section>
<?php endif; ?>

