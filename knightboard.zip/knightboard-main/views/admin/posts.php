<section class="admin-panel">
<form class="admin-filter-form" action="/admin/posts" method="get">
    <label>Post, thread, or text <input type="search" name="q" value="<?= e($query) ?>" placeholder="Number or phrase"></label>
    <label>Board <select name="board"><option value="0">All boards</option><?php foreach ($navBoards as $item): ?><option value="<?= (int) $item['id'] ?>"<?= $selectedBoard === (int) $item['id'] ? ' selected' : '' ?>>/<?= e($item['slug']) ?>/</option><?php endforeach; ?></select></label>
    <label>State <select name="state"><option value="visible"<?= $state === 'visible' ? ' selected' : '' ?>>Visible</option><option value="deleted"<?= $state === 'deleted' ? ' selected' : '' ?>>Deleted</option></select></label>
    <button type="submit">Search</button>
</form>
</section>

<section class="moderation-results">
<?php if ($posts === []): ?><div class="admin-panel empty-state">No matching posts.</div><?php endif; ?>
<?php foreach ($posts as $post): ?>
<article class="admin-panel moderation-post">
    <header><div><p class="eyebrow">/<?= e($post['board_slug']) ?>/ · <?= (int) $post['is_op'] === 1 ? 'Original post' : 'Reply' ?></p><h2><a href="/<?= e($post['board_slug']) ?>/thread/<?= (int) $post['thread_id'] ?>#p<?= (int) $post['post_id'] ?>">Post No. <?= (int) $post['post_id'] ?> ↗</a></h2></div><time><?= e(format_post_time((string) $post['created_at'])) ?></time></header>
    <p><strong><?= e(trim((string) $post['subject']) ?: (trim((string) $post['name']) ?: 'Anonymous')) ?></strong></p>
    <p class="moderation-excerpt"><?= (int) $post['is_deleted'] === 1 ? '[deleted]' : nl2br(e(mb_substr((string) $post['body'], 0, 1200))) ?></p>
    <div class="thread-state"><span><?= (int) $post['is_sticky'] ? 'Sticky' : 'Not sticky' ?></span><span><?= (int) $post['is_locked'] ? 'Closed' : 'Open' ?></span><span><?= (int) $post['is_archived'] ? 'Archived' : 'Live' ?></span><?= !empty($post['attachment_id']) ? '<span>Has media</span>' : '' ?></div>
    <div class="admin-action-row wrap-actions">
        <form action="/admin/threads/<?= (int) $post['thread_id'] ?>/toggle" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="field" value="is_sticky"><button type="submit">Toggle sticky</button></form>
        <form action="/admin/threads/<?= (int) $post['thread_id'] ?>/toggle" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="field" value="is_locked"><button type="submit">Toggle closed</button></form>
        <form action="/admin/threads/<?= (int) $post['thread_id'] ?>/toggle" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="field" value="is_archived"><button type="submit">Toggle archive</button></form>
        <?php if ((int) $post['is_deleted'] === 0): ?>
        <?php if (!empty($post['attachment_id'])): ?><form action="/admin/posts/<?= (int) $post['post_id'] ?>/moderate" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="action" value="remove-media"><input type="hidden" name="reason" value="Media removed by staff"><button type="submit">Remove media</button></form><?php endif; ?>
        <form action="/admin/posts/<?= (int) $post['post_id'] ?>/moderate" method="post" class="inline-admin-form"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="action" value="delete"><input name="reason" maxlength="500" value="Rule violation" aria-label="Removal reason"><button type="submit" class="danger-button" data-confirm="Delete this post?">Delete</button></form>
        <form action="/admin/posts/<?= (int) $post['post_id'] ?>/restrict" method="post" class="inline-admin-form"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input name="days" type="number" min="1" max="365" value="7" aria-label="Restriction days"><input name="reason" maxlength="500" value="Repeated rule violations" aria-label="Restriction reason"><button type="submit">Restrict token</button></form>
        <?php endif; ?>
    </div>
</article>
<?php endforeach; ?>
</section>

