<header><p class="eyebrow">Private staff area</p><h1>Sign in</h1><p>Use your staff credentials. Sign-in attempts are limited without recording network addresses.</p></header>
<form class="auth-form" action="/admin/login" method="post">
    <input type="hidden" name="_token" value="<?= e($csrfToken) ?>">
    <label>Username <input name="username" required maxlength="40" autocomplete="username" autofocus></label>
    <label>Password <input name="password" type="password" required maxlength="200" autocomplete="current-password"></label>
    <button type="submit" class="primary-button">Sign in</button>
</form>
<p class="auth-footer"><a href="/">← Return to the boards</a></p>

