<?php if (!role_allows((string) $admin['role'], 'settings')): ?><div class="admin-panel empty-state">Your role cannot change site settings.</div><?php else: ?>
<form action="/admin/settings" method="post" class="settings-sections">
<input type="hidden" name="_token" value="<?= e($csrfToken) ?>">
<section class="admin-panel"><header><div><p class="eyebrow">Identity</p><h2>Site copy</h2></div></header><div class="admin-form">
    <label>Site name <input name="site_name" required maxlength="80" value="<?= e($settings['site_name']) ?>"></label>
    <label>Anonymous name <input name="default_name" required maxlength="80" value="<?= e($settings['default_name']) ?>"></label>
    <label class="wide-field">Tagline <input name="tagline" maxlength="160" value="<?= e($settings['tagline']) ?>"></label>
    <label class="wide-field">News <textarea name="news_text" rows="4" maxlength="5000"><?= e($settings['news_text']) ?></textarea></label>
    <label class="wide-field">Site rules summary <textarea name="rules_text" rows="5" maxlength="10000"><?= e($settings['rules_text']) ?></textarea></label>
    <label class="wide-field">Privacy note <textarea name="registration_note" rows="3" maxlength="2000"><?= e($settings['registration_note']) ?></textarea></label>
</div></section>
<section class="admin-panel"><header><div><p class="eyebrow">Thread lifecycle</p><h2>Posting limits</h2></div></header><div class="admin-form numeric-settings">
    <label>Threads per page <input name="threads_per_page" type="number" min="1" max="50" value="<?= e($settings['threads_per_page']) ?>"></label>
    <label>Preview replies <input name="preview_replies" type="number" min="0" max="10" value="<?= e($settings['preview_replies']) ?>"></label>
    <label>Reply limit <input name="reply_limit" type="number" min="50" max="2000" value="<?= e($settings['reply_limit']) ?>"></label>
    <label>Bump limit <input name="bump_limit" type="number" min="25" max="1000" value="<?= e($settings['bump_limit']) ?>"></label>
</div></section>
<section class="admin-panel"><header><div><p class="eyebrow">No-IP abuse controls</p><h2>Rate &amp; media limits</h2></div></header><div class="admin-form numeric-settings">
    <label>Browser cooldown (seconds) <input name="post_cooldown_seconds" type="number" min="0" max="3600" value="<?= e($settings['post_cooldown_seconds']) ?>"></label>
    <label>Posts/browser/minute <input name="posts_per_minute" type="number" min="1" max="120" value="<?= e($settings['posts_per_minute']) ?>"></label>
    <label>Global posts/minute <input name="global_posts_per_minute" type="number" min="10" max="5000" value="<?= e($settings['global_posts_per_minute']) ?>"></label>
    <label>Max upload bytes <input name="max_upload_bytes" type="number" min="1048576" max="25165824" step="1024" value="<?= e($settings['max_upload_bytes']) ?>"></label>
</div><p class="admin-help">Browser restrictions are intentionally resettable. Global budgets, cooldowns, filters, thread controls, and moderator response provide layered control without network identity.</p></section>
<button type="submit" class="primary-button save-settings">Save all settings</button>
</form>
<?php endif; ?>

