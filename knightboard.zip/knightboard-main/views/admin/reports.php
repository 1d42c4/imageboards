<nav class="admin-tabs" aria-label="Report status">
    <?php foreach (['open' => 'Open', 'resolved' => 'Resolved', 'dismissed' => 'Dismissed'] as $value => $label): ?><a href="?status=<?= $value ?>"<?= $reportStatus === $value ? ' aria-current="page"' : '' ?>><?= $label ?></a><?php endforeach; ?>
</nav>

<section class="report-queue">
<?php if ($reports === []): ?><div class="admin-panel empty-state">No <?= e($reportStatus) ?> reports.</div><?php endif; ?>
<?php foreach ($reports as $report): ?>
<article class="admin-panel report-card">
    <header><div><p class="eyebrow">Report #<?= (int) $report['id'] ?> · <?= e($report['category']) ?></p><h2>Post <a href="/<?= e($report['board_slug']) ?>/thread/<?= (int) $report['thread_id'] ?>#p<?= (int) $report['post_id'] ?>">No. <?= (int) $report['post_id'] ?> ↗</a></h2></div><span class="status-pill status-<?= e($report['status']) ?>"><?= e($report['status']) ?></span></header>
    <p class="report-meta">/<?= e($report['board_slug']) ?>/ · submitted <?= e(format_post_time((string) $report['created_at'])) ?></p>
    <?php if ((string) $report['details'] !== ''): ?><blockquote><?= e($report['details']) ?></blockquote><?php endif; ?>
    <div class="reported-content"><strong><?= e(trim((string) $report['subject']) ?: (trim((string) $report['name']) ?: 'Anonymous')) ?></strong><p><?= e(mb_substr(trim((string) $report['body']), 0, 1000)) ?></p><?= (int) $report['is_deleted'] === 1 ? '<em>[post deleted]</em>' : '' ?></div>
    <?php if ($report['status'] === 'open'): ?>
    <div class="admin-action-row">
        <form action="/admin/reports/<?= (int) $report['id'] ?>/resolve" method="post" class="inline-admin-form">
            <input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="status" value="resolved">
            <input name="note" maxlength="1000" placeholder="Resolution note"><button type="submit" class="primary-button">Resolve</button>
        </form>
        <form action="/admin/reports/<?= (int) $report['id'] ?>/resolve" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="status" value="dismissed"><button type="submit">Dismiss</button></form>
        <?php if ((int) $report['is_deleted'] === 0): ?><form action="/admin/posts/<?= (int) $report['post_id'] ?>/moderate" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="reason" value="Removed after report review"><button type="submit" class="danger-button" data-confirm="Delete this post and its media?">Remove post</button></form><?php endif; ?>
    </div>
    <?php else: ?><p class="resolution-note">Handled by <?= e($report['resolver_name'] ?? 'former staff') ?>: <?= e($report['resolution_note']) ?></p><?php endif; ?>
</article>
<?php endforeach; ?>
</section>

