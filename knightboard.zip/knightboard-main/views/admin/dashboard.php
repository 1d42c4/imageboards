<section class="stat-grid" aria-label="Site totals">
    <?php foreach (['open_reports' => 'Open reports', 'live_threads' => 'Live threads', 'posts' => 'Visible posts', 'media' => 'Images', 'restricted_tokens' => 'Active restrictions', 'boards' => 'Boards'] as $key => $label): ?>
    <article class="stat-card"><span><?= e($label) ?></span><strong><?= number_format((int) $stats[$key]) ?></strong></article>
    <?php endforeach; ?>
</section>

<div class="admin-columns">
<section class="admin-panel"><header><div><p class="eyebrow">Queue</p><h2>Open reports</h2></div><a href="/admin/reports">View all</a></header>
    <?php if ($reports === []): ?><p class="empty-state">The report queue is clear.</p><?php else: ?><div class="admin-list"><?php foreach ($reports as $report): ?><a href="/<?= e($report['board_slug']) ?>/thread/<?= (int) $report['thread_id'] ?>#p<?= (int) $report['post_id'] ?>"><strong>#<?= (int) $report['post_id'] ?> · <?= e($report['category']) ?></strong><span>/<?= e($report['board_slug']) ?>/ · <?= e(human_age((string) $report['created_at'])) ?> ago</span></a><?php endforeach; ?></div><?php endif; ?>
</section>
<section class="admin-panel"><header><div><p class="eyebrow">Accountability</p><h2>Recent staff activity</h2></div><a href="/admin/audit">Full log</a></header>
    <div class="admin-list"><?php foreach ($auditEntries as $entry): ?><div><strong><?= e($entry['action']) ?></strong><span><?= e($entry['admin_name'] ?? 'system') ?> · <?= e(human_age((string) $entry['created_at'])) ?> ago</span></div><?php endforeach; ?></div>
</section>
</div>

<section class="admin-panel privacy-status"><header><div><p class="eyebrow">Privacy posture</p><h2>No network identifiers</h2></div><span class="healthy-badge">Active</span></header><p>The application schema, post controls, reports, and audit log use no IP address or user-agent fields. Anonymous restrictions are explicit, expiring browser-token controls.</p></section>

