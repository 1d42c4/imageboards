<!doctype html>
<html lang="en" data-theme="admin">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= e($pageTitle) ?> · Knightboard</title><link rel="stylesheet" href="/assets/app.css"></head>
<body class="auth-body">
<main class="auth-card">
    <a class="auth-brand" href="/"><span aria-hidden="true">♞</span><strong><?= e($settings['site_name'] ?? 'Knightboard') ?></strong></a>
    <?php if ($flashMessages !== []): ?><div class="flash-stack" role="status"><?php foreach ($flashMessages as $flash): ?><p class="flash flash-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></p><?php endforeach; ?></div><?php endif; ?>
    <?= $content ?>
</main>
</body>
</html>

