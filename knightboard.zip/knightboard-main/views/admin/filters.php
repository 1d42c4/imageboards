<?php if (!role_allows((string) $admin['role'], 'settings')): ?><div class="admin-panel empty-state">Your role cannot change content filters.</div><?php else: ?>
<section class="admin-panel"><header><div><p class="eyebrow">Literal matching</p><h2>Add a content filter</h2></div></header>
<p class="admin-help">Patterns are case-insensitive plain text, not regular expressions. This keeps posting predictable and avoids expensive expressions.</p>
<form action="/admin/filters" method="post" class="admin-form filter-form">
    <input type="hidden" name="_token" value="<?= e($csrfToken) ?>">
    <label>Pattern <input name="pattern" required maxlength="200"></label>
    <label>Action <select name="action"><option value="reject">Reject post</option><option value="replace">Replace phrase</option><option value="flag">Allow and report</option></select></label>
    <label>Replacement <input name="replacement" maxlength="200" placeholder="Only used for Replace"></label>
    <button type="submit" class="primary-button">Add filter</button>
</form></section>

<section class="admin-panel"><header><div><p class="eyebrow">Pipeline</p><h2>Current filters</h2></div><span><?= count($filters) ?> total</span></header>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Pattern</th><th>Action</th><th>Replacement</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($filters as $filter): ?><tr><td><code><?= e($filter['pattern']) ?></code></td><td><?= e($filter['action']) ?></td><td><?= e($filter['replacement']) ?></td><td><?= (int) $filter['is_enabled'] === 1 ? 'Enabled' : 'Disabled' ?></td><td><?= e($filter['creator_name'] ?? 'former staff') ?><br><small><?= e(format_post_time((string) $filter['created_at'])) ?></small></td><td><div class="table-actions"><form action="/admin/filters/<?= (int) $filter['id'] ?>" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="operation" value="toggle"><button type="submit">Toggle</button></form><form action="/admin/filters/<?= (int) $filter['id'] ?>" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><input type="hidden" name="operation" value="delete"><button type="submit" class="danger-button" data-confirm="Delete this filter?">Delete</button></form></div></td></tr><?php endforeach; ?>
<?php if ($filters === []): ?><tr><td colspan="6">No filters configured.</td></tr><?php endif; ?>
</tbody></table></div></section>
<?php endif; ?>

