<!doctype html>
<html lang="en" data-theme="admin">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <title><?= e($pageTitle) ?> · <?= e($settings['site_name'] ?? 'Knightboard') ?> Admin</title>
    <link rel="stylesheet" href="/assets/app.css"><script src="/assets/app.js" defer></script>
</head>
<body class="admin-body">
<a class="skip-link" href="#admin-main">Skip to content</a>
<div class="admin-shell">
    <aside class="admin-sidebar">
        <a class="admin-brand" href="/admin"><span aria-hidden="true">♞</span><strong><?= e($settings['site_name'] ?? 'Knightboard') ?></strong><small>Administration</small></a>
        <nav aria-label="Administration">
            <a href="/admin">Dashboard</a>
            <a href="/admin/reports">Reports</a>
            <a href="/admin/posts">Posts &amp; threads</a>
            <?php if (role_allows((string) $admin['role'], 'boards')): ?><a href="/admin/boards">Boards</a><?php endif; ?>
            <?php if (role_allows((string) $admin['role'], 'settings')): ?><a href="/admin/settings">Site settings</a><a href="/admin/filters">Content filters</a><?php endif; ?>
            <?php if (role_allows((string) $admin['role'], 'staff')): ?><a href="/admin/staff">Staff</a><?php endif; ?>
            <a href="/admin/audit">Audit &amp; restrictions</a>
        </nav>
        <div class="admin-account"><span><?= e($admin['username']) ?></span><small><?= e($admin['role']) ?></small>
            <form action="/admin/logout" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><button type="submit" class="text-button">Sign out</button></form>
        </div>
    </aside>
    <main id="admin-main" class="admin-main">
        <header class="admin-topbar"><div><p class="eyebrow">Knightboard control room</p><h1><?= e($pageTitle) ?></h1></div><a href="/" target="_blank" rel="noreferrer">View site ↗</a></header>
        <?php if ($flashMessages !== []): ?><div class="flash-stack" role="status" aria-live="polite"><?php foreach ($flashMessages as $flash): ?><p class="flash flash-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></p><?php endforeach; ?></div><?php endif; ?>
        <?= $content ?>
    </main>
</div>
</body>
</html>

