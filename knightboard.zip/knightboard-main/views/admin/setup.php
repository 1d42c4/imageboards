<header><p class="eyebrow">One-time setup</p><h1>Create the owner</h1><p>This route closes permanently after the first account is created. Use a unique password of at least 12 characters.</p></header>
<form class="auth-form" action="/admin/setup" method="post">
    <input type="hidden" name="_token" value="<?= e($csrfToken) ?>">
    <label>Owner username <input name="username" required minlength="3" maxlength="40" pattern="[A-Za-z0-9_.-]+" autocomplete="username" autofocus></label>
    <label>Password <input name="password" type="password" required minlength="12" maxlength="200" autocomplete="new-password"></label>
    <label>Confirm password <input name="password_confirmation" type="password" required minlength="12" maxlength="200" autocomplete="new-password"></label>
    <button type="submit" class="primary-button">Create owner</button>
</form>

