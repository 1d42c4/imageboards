<section class="admin-panel"><header><div><p class="eyebrow">Anonymous controls</p><h2>Browser-token restrictions</h2></div><span><?= count($restrictions) ?> records</span></header>
<p class="admin-help">These hashes come from random site cookies, not IP addresses or fingerprints. Visitors can reset them; restrictions are one layer of abuse control.</p>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Token reference</th><th>Reason</th><th>Created by</th><th>Expires</th><th></th></tr></thead><tbody>
<?php foreach ($restrictions as $restriction): ?><tr><td><code><?= e(substr((string) $restriction['token_hash'], 0, 12)) ?>…</code></td><td><?= e($restriction['reason']) ?></td><td><?= e($restriction['creator_name'] ?? 'former staff') ?><br><small><?= e(format_post_time((string) $restriction['created_at'])) ?></small></td><td><?= $restriction['expires_at'] ? e(format_post_time((string) $restriction['expires_at'])) : 'Never' ?></td><td><form action="/admin/restrictions/<?= (int) $restriction['id'] ?>/delete" method="post"><input type="hidden" name="_token" value="<?= e($csrfToken) ?>"><button type="submit">Lift</button></form></td></tr><?php endforeach; ?>
<?php if ($restrictions === []): ?><tr><td colspan="5">No restrictions have been created.</td></tr><?php endif; ?>
</tbody></table></div></section>

<section class="admin-panel"><header><div><p class="eyebrow">Append-only activity</p><h2>Staff audit log</h2></div><span><?= count($auditEntries) ?> shown</span></header>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Time</th><th>Staff</th><th>Action</th><th>Target</th><th>Details</th></tr></thead><tbody>
<?php foreach ($auditEntries as $entry): ?><tr><td><?= e(format_post_time((string) $entry['created_at'])) ?></td><td><?= e($entry['admin_name'] ?? 'system/former staff') ?></td><td><code><?= e($entry['action']) ?></code></td><td><?= e($entry['target_type']) ?><?= $entry['target_id'] !== null ? ' #' . (int) $entry['target_id'] : '' ?></td><td><code class="json-details"><?= e($entry['details_json']) ?></code></td></tr><?php endforeach; ?>
</tbody></table></div></section>

