<header class="site-hero">
    <p class="site-mark" aria-hidden="true">♞</p>
    <h1><?= e($settings['site_name'] ?? 'Knightboard') ?></h1>
    <p><?= e($settings['tagline'] ?? 'Chess, one position at a time.') ?></p>
</header>

<section class="notice-box" aria-labelledby="news-heading">
    <h2 id="news-heading">News</h2>
    <p><?= nl2br(e($settings['news_text'] ?? 'Welcome.')) ?></p>
</section>

<section class="board-directory" aria-labelledby="boards-heading">
    <h2 id="boards-heading">Boards</h2>
    <div class="board-directory-grid">
        <?php foreach ($navBoards as $item): ?>
        <a class="board-directory-item" href="/<?= rawurlencode((string) $item['slug']) ?>/">
            <strong>/<?= e($item['slug']) ?>/ — <?= e($item['name']) ?></strong>
            <span><?= e($item['description']) ?></span>
            <small><?= (int) $item['thread_count'] ?> threads · <?= (int) $item['post_count'] ?> posts</small>
        </a>
        <?php endforeach; ?>
    </div>
</section>

<section class="recent-threads" aria-labelledby="recent-heading">
    <h2 id="recent-heading">Recently bumped threads</h2>
    <?php if ($recentThreads === []): ?>
        <p class="empty-state">No threads yet. Pick a board and make the first move.</p>
    <?php else: ?>
    <div class="recent-list">
        <?php foreach ($recentThreads as $item): ?>
        <article class="recent-thread">
            <?php if (!empty($item['thumbnail_name'])): ?><a href="/<?= e($item['board_slug']) ?>/thread/<?= (int) $item['id'] ?>"><img src="/media/<?= e($item['thumbnail_name']) ?>" loading="lazy" alt=""></a><?php elseif ((string) $item['fen'] !== ''): ?><div class="catalog-fen"><?= render_fen_board((string) $item['fen']) ?></div><?php endif; ?>
            <div>
                <p class="recent-meta"><a href="/<?= e($item['board_slug']) ?>/">/<?= e($item['board_slug']) ?>/</a> · bumped <?= e(human_age((string) $item['bumped_at'])) ?> ago · <?= (int) $item['reply_count'] ?> replies</p>
                <h3><a href="/<?= e($item['board_slug']) ?>/thread/<?= (int) $item['id'] ?>"><?= e(trim((string) $item['subject']) ?: 'Thread No. ' . $item['post_id']) ?></a></h3>
                <p><?= e(mb_substr(trim((string) $item['body']), 0, 280)) ?><?= mb_strlen(trim((string) $item['body'])) > 280 ? '…' : '' ?></p>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</section>

