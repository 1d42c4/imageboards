<header class="board-header compact-board-header">
    <h1>Search /<?= e($board['slug']) ?>/</h1>
    <nav class="board-actions">[ <a href="/<?= e($board['slug']) ?>/">Index</a> / <a href="/<?= e($board['slug']) ?>/catalog">Catalog</a> ]</nav>
</header>

<form class="search-form" action="/<?= e($board['slug']) ?>/search" method="get">
    <label for="board-search">Search subjects and comments</label>
    <input id="board-search" type="search" name="q" value="<?= e($query) ?>" minlength="2" maxlength="100" required autofocus>
    <button type="submit">Search</button>
</form>

<?php if ($query !== ''): ?>
<section class="search-results" aria-labelledby="results-heading">
    <h2 id="results-heading"><?= count($results) ?> result<?= count($results) === 1 ? '' : 's' ?> for “<?= e($query) ?>”</h2>
    <?php foreach ($results as $result): ?>
    <article>
        <h3><a href="/<?= e($board['slug']) ?>/thread/<?= (int) $result['thread_id'] ?>#p<?= (int) $result['post_id'] ?>"><?= e(trim((string) $result['subject']) ?: 'Post No. ' . $result['post_id']) ?></a></h3>
        <p class="recent-meta"><?= e(format_post_time((string) $result['post_created_at'])) ?><?= (int) $result['is_archived'] === 1 ? ' · archived' : '' ?></p>
        <p><?= e(mb_substr(trim((string) $result['body']), 0, 400)) ?><?= mb_strlen(trim((string) $result['body'])) > 400 ? '…' : '' ?></p>
    </article>
    <?php endforeach; ?>
    <?php if ($results === []): ?><p class="empty-state">No matching posts.</p><?php endif; ?>
</section>
<?php endif; ?>

