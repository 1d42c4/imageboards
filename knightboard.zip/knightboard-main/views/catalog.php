<header class="board-header compact-board-header">
    <h1>/<?= e($board['slug']) ?>/ — Catalog</h1>
    <p><?= e($board['description']) ?></p>
    <nav class="board-actions">[ <a href="/<?= e($board['slug']) ?>/">Index</a> / <strong>Catalog</strong> / <a href="/<?= e($board['slug']) ?>/archive">Archive</a> / <a href="/<?= e($board['slug']) ?>/search">Search</a> ]</nav>
</header>

<div class="catalog-tools">
    <label>Filter <input type="search" data-catalog-filter placeholder="Subject or comment"></label>
    <label>Sort <select data-catalog-sort><option value="bump">Bump order</option><option value="newest">Newest</option><option value="replies">Most replies</option></select></label>
</div>

<section class="catalog-grid" data-catalog-grid aria-label="Thread catalog">
<?php foreach ($threads as $item): ?>
    <?php $catalogText = trim((string) $item['subject'] . ' ' . (string) $item['body']); ?>
    <article class="catalog-card" data-search="<?= e(mb_strtolower($catalogText)) ?>" data-bump="<?= e($item['bumped_at']) ?>" data-created="<?= e($item['created_at']) ?>" data-replies="<?= (int) $item['reply_count'] ?>">
        <a class="catalog-image" href="/<?= e($board['slug']) ?>/thread/<?= (int) $item['id'] ?>">
            <?php if (!empty($item['thumbnail_name'])): ?><img src="/media/<?= e($item['thumbnail_name']) ?>" loading="lazy" alt=""><?php elseif ((string) $item['fen'] !== ''): ?><?= render_fen_board((string) $item['fen'], false) ?><?php else: ?><span class="catalog-placeholder" aria-hidden="true">♞</span><?php endif; ?>
        </a>
        <h2><a href="/<?= e($board['slug']) ?>/thread/<?= (int) $item['id'] ?>"><?= e(trim((string) $item['subject']) ?: 'No. ' . $item['post_id']) ?></a></h2>
        <p class="catalog-counts"><strong>R:</strong> <?= (int) $item['reply_count'] ?> <strong>I:</strong> <?= (int) $item['attachment_count'] ?> · <?= e(human_age((string) $item['bumped_at'])) ?></p>
        <p><?= e(mb_substr(trim((string) $item['body']), 0, 180)) ?><?= mb_strlen(trim((string) $item['body'])) > 180 ? '…' : '' ?></p>
    </article>
<?php endforeach; ?>
</section>
<?php if ($threads === []): ?><p class="empty-state">The catalog is empty.</p><?php endif; ?>
