<section class="posting-area" aria-labelledby="post-form-title">
    <details class="posting-details" <?= ($openForm ?? false) ? 'open' : '' ?>>
        <summary id="post-form-title"><?= $isReply ? 'Post a reply' : 'Start a new thread' ?></summary>
        <form id="post-form" class="post-form" action="<?= e($action) ?>" method="post" enctype="multipart/form-data" data-post-form>
            <input type="hidden" name="_token" value="<?= e($csrfToken) ?>">
            <input type="hidden" name="_stamp" value="<?= e($formStamp) ?>">
            <div class="honeypot" aria-hidden="true">
                <label>Website <input name="website" tabindex="-1" autocomplete="off"></label>
            </div>
            <div class="form-row"><label for="post-name">Name</label><input id="post-name" name="name" maxlength="80" autocomplete="nickname" placeholder="<?= e($settings['default_name'] ?? 'Anonymous') ?>"></div>
            <div class="form-row"><label for="post-subject">Subject</label><input id="post-subject" name="subject" maxlength="120"></div>
            <div class="form-row form-row-comment"><label for="post-body">Comment</label><textarea id="post-body" name="body" rows="6" maxlength="20000" data-comment></textarea></div>
            <div class="form-row"><label for="post-image">Image</label><input id="post-image" name="image" type="file" accept="image/jpeg,image/png,image/gif,image/webp"><small>JPEG, PNG, GIF, or WebP; metadata is removed.</small></div>
            <details class="advanced-fields">
                <summary>Chess position, game &amp; options</summary>
                <div class="form-row"><label for="post-fen">FEN</label><input id="post-fen" name="fen" maxlength="120" spellcheck="false" placeholder="Full six-field FEN"></div>
                <div class="form-row form-row-comment"><label for="post-pgn">PGN</label><textarea id="post-pgn" name="pgn" rows="4" maxlength="20000" spellcheck="false"></textarea></div>
                <?php if ($isReply): ?><div class="form-row"><span class="form-label">Bump</span><label class="check-label"><input type="checkbox" name="sage" value="1"> Sage (reply without bumping)</label></div><?php endif; ?>
            </details>
            <div class="form-row"><label for="deletion-password">Delete key</label><input id="deletion-password" name="deletion_password" type="password" minlength="4" maxlength="100" required autocomplete="new-password" data-deletion-password><small>Saved only in this browser; needed to delete your post.</small></div>
            <div class="form-row"><span class="form-label"></span><button class="primary-button" type="submit"><?= $isReply ? 'Reply' : 'Create thread' ?></button></div>
            <p class="form-note">Use <code>&gt;&gt;post-number</code> to quote and <code>[spoiler]text[/spoiler]</code> for hidden solutions.</p>
        </form>
    </details>
</section>

