<?php
$postId = (int) $post['post_id'];
$threadUrl = '/' . rawurlencode((string) $board['slug']) . '/thread/' . $threadId;
$permalink = $threadUrl . '#p' . $postId;
$deleted = (int) ($post['is_deleted'] ?? 0) === 1;
$ownPost = !$deleted && hash_equals((string) $post['poster_token_hash'], $posterTokenHash);
$displayName = trim((string) ($post['name'] ?? '')) ?: ($settings['default_name'] ?? 'Anonymous');
$postBacklinks = $backlinks[$postId] ?? [];
?>
<article id="p<?= $postId ?>" class="post <?= $isOp ? 'thread-op' : 'reply' ?><?= $ownPost ? ' own-post' : '' ?>" data-post-id="<?= $postId ?>" tabindex="-1">
    <header class="post-header">
        <?php if (!$deleted && trim((string) ($post['subject'] ?? '')) !== ''): ?><span class="post-subject"><?= e($post['subject']) ?></span><?php endif; ?>
        <?php if (!$deleted): ?><span class="post-name"><?= e($displayName) ?></span><?php endif; ?>
        <?php if ($ownPost): ?><span class="you-marker">(You)</span><?php endif; ?>
        <?php if ((int) ($post['is_sage'] ?? 0) === 1): ?><span class="status-label" title="This reply did not bump the thread">Sage</span><?php endif; ?>
        <?php if ($isOp && (int) ($thread['is_sticky'] ?? 0) === 1): ?><span class="status-label">Sticky</span><?php endif; ?>
        <?php if ($isOp && (int) ($thread['is_locked'] ?? 0) === 1): ?><span class="status-label">Closed</span><?php endif; ?>
        <?php if ($isOp && (int) ($thread['is_archived'] ?? 0) === 1): ?><span class="status-label">Archived</span><?php endif; ?>
        <time datetime="<?= e(str_replace(' ', 'T', (string) $post['post_created_at']) . 'Z') ?>"><?= e(format_post_time((string) $post['post_created_at'])) ?></time>
        <a class="post-number" href="<?= e($permalink) ?>" data-quote="<?= $postId ?>" aria-label="Quote post <?= $postId ?>">No. <?= $postId ?></a>
        <?php if (!$deleted): ?>
        <details class="post-menu">
            <summary aria-label="Actions for post <?= $postId ?>">Actions</summary>
            <div class="post-menu-panel">
                <button type="button" data-quote="<?= $postId ?>">Quote</button>
                <button type="button" data-copy-link="<?= e($permalink) ?>">Copy link</button>
                <details>
                    <summary>Report</summary>
                    <form action="/post/<?= $postId ?>/report" method="post" class="compact-form">
                        <input type="hidden" name="_token" value="<?= e($csrfToken) ?>">
                        <label>Reason <select name="category" required><option value="spam">Spam</option><option value="harassment">Harassment</option><option value="illegal">Illegal content</option><option value="off-topic">Off-topic</option><option value="other">Other</option></select></label>
                        <label>Details <textarea name="details" rows="2" maxlength="1000"></textarea></label>
                        <button type="submit">Send report</button>
                    </form>
                </details>
                <details>
                    <summary>Delete</summary>
                    <form action="/post/<?= $postId ?>/delete" method="post" class="compact-form">
                        <input type="hidden" name="_token" value="<?= e($csrfToken) ?>">
                        <label>Delete key <input name="deletion_password" type="password" minlength="4" maxlength="100" required autocomplete="current-password" data-deletion-password></label>
                        <button type="submit" class="danger-button">Delete post</button>
                    </form>
                </details>
            </div>
        </details>
        <?php endif; ?>
    </header>

    <?php if ($deleted): ?>
        <p class="tombstone">[Post deleted<?= trim((string) ($post['deleted_reason'] ?? '')) !== '' ? ': ' . e($post['deleted_reason']) : '' ?>]</p>
    <?php else: ?>
        <?php if (!empty($post['attachment_id'])): ?>
        <?php $thumbScale = min(1, 250 / max((int) $post['width'], (int) $post['height'])); $thumbWidth = max(1, (int) round((int) $post['width'] * $thumbScale)); $thumbHeight = max(1, (int) round((int) $post['height'] * $thumbScale)); ?>
        <figure class="attachment">
            <figcaption>File: <a href="/media/<?= e($post['storage_name']) ?>" target="_blank" rel="noreferrer"><?= e($post['original_name']) ?></a> (<?= e(human_filesize((int) $post['byte_size'])) ?>, <?= (int) $post['width'] ?>×<?= (int) $post['height'] ?>)</figcaption>
            <a href="/media/<?= e($post['storage_name']) ?>" target="_blank" rel="noreferrer"><img src="/media/<?= e($post['thumbnail_name']) ?>" width="<?= $thumbWidth ?>" height="<?= $thumbHeight ?>" loading="lazy" alt="Attached image: <?= e($post['original_name']) ?>"></a>
        </figure>
        <?php endif; ?>
        <?php if ((string) ($post['fen'] ?? '') !== ''): ?><div class="fen-attachment"><?= render_fen_board((string) $post['fen']) ?></div><?php endif; ?>
        <div class="post-body" data-post-body><?= render_post_body((string) $post['body'], $threadUrl) ?></div>
        <?php if ((string) ($post['pgn'] ?? '') !== ''): ?>
        <details class="pgn-block"><summary>PGN game notation</summary><pre><?= e($post['pgn']) ?></pre><button type="button" data-copy="<?= e($post['pgn']) ?>">Copy PGN</button></details>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($postBacklinks !== []): ?>
    <nav class="backlinks" aria-label="Replies to post <?= $postId ?>">Replies:
        <?php foreach ($postBacklinks as $sourceId): ?><a href="#p<?= (int) $sourceId ?>" data-post-ref="<?= (int) $sourceId ?>">&gt;&gt;<?= (int) $sourceId ?></a> <?php endforeach; ?>
    </nav>
    <?php endif; ?>
</article>
