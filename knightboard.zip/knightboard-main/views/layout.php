<!doctype html>
<html lang="en" data-theme="parchment">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <meta name="description" content="<?= e($settings['tagline'] ?? 'Chess, one position at a time.') ?>">
    <title><?= e($pageTitle ?? ($settings['site_name'] ?? 'Knightboard')) ?></title>
    <link rel="stylesheet" href="/assets/app.css">
    <script src="/assets/app.js" defer></script>
</head>
<body>
<a class="skip-link" href="#main-content">Skip to posts</a>
<nav class="board-bar" aria-label="Chess boards">
    <span class="board-links">
        [ <a href="/">home</a> /
        <?php foreach ($navBoards as $index => $navBoard): ?>
            <a href="/<?= rawurlencode((string) $navBoard['slug']) ?>/" title="<?= e($navBoard['name']) ?>"><?= e($navBoard['slug']) ?></a><?= $index < count($navBoards) - 1 ? ' /' : '' ?>
        <?php endforeach; ?> ]
    </span>
    <span class="utility-links">[ <a href="/rules">rules</a> / <a href="/faq">faq</a> / <a href="/privacy">privacy</a> / <a href="/admin">staff</a> ]</span>
</nav>
<details class="mobile-board-menu">
    <summary>Boards &amp; site links</summary>
    <nav aria-label="Mobile board navigation">
        <a href="/">Home</a>
        <?php foreach ($navBoards as $navBoard): ?>
            <a href="/<?= rawurlencode((string) $navBoard['slug']) ?>/">/<?= e($navBoard['slug']) ?>/ <?= e($navBoard['name']) ?></a>
        <?php endforeach; ?>
        <a href="/rules">Rules</a><a href="/faq">FAQ</a><a href="/privacy">Privacy</a>
    </nav>
</details>

<?php if ($flashMessages !== []): ?>
<div class="flash-stack" role="status" aria-live="polite">
    <?php foreach ($flashMessages as $flash): ?>
        <p class="flash flash-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></p>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<main id="main-content">
    <?= $content ?>
</main>

<footer class="site-footer">
    <nav aria-label="Footer navigation">
        [ <a href="/">home</a> /
        <?php foreach ($navBoards as $navBoard): ?><a href="/<?= rawurlencode((string) $navBoard['slug']) ?>/"><?= e($navBoard['slug']) ?></a> / <?php endforeach; ?>
        <a href="/privacy">privacy</a> ]
    </nav>
    <p><?= e($settings['site_name'] ?? 'Knightboard') ?> stores no IP addresses. Theme:
        <button type="button" class="text-button" data-theme-value="parchment">Parchment</button> ·
        <button type="button" class="text-button" data-theme-value="blue">Blue</button> ·
        <button type="button" class="text-button" data-theme-value="dark">Dark</button>
    </p>
</footer>
<div id="quote-preview" class="quote-preview" hidden></div>
</body>
</html>

