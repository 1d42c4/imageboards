<header class="board-header compact-board-header">
    <h1>/<?= e($board['slug']) ?>/ — <?= e($board['name']) ?></h1>
    <nav class="board-actions" aria-label="Thread navigation">[ <a href="/<?= e($board['slug']) ?>/">Index</a> / <a href="/<?= e($board['slug']) ?>/catalog">Catalog</a> / <a href="/<?= e($board['slug']) ?>/archive">Archive</a> / <a href="#bottom">Bottom</a> ]</nav>
</header>

<?php $threadClosed = (int) $thread['is_locked'] === 1 || (int) $thread['is_archived'] === 1 || (int) $board['is_locked'] === 1; ?>
<?php if (!$threadClosed): ?>
<?= $view->partial('components/post_form', [
    'action' => '/' . $board['slug'] . '/thread/' . $thread['id'] . '/reply', 'isReply' => true,
    'openForm' => false, 'csrfToken' => $csrfToken, 'formStamp' => $formStamp, 'settings' => $settings,
]) ?>
<?php else: ?><p class="closed-notice">This thread is closed to new replies.</p><?php endif; ?>

<hr class="board-divider">
<section class="thread thread-page" aria-label="Thread <?= (int) $thread['id'] ?>">
<?php foreach ($posts as $index => $post): ?>
    <?= $view->partial('components/post', [
        'post' => $post, 'thread' => $thread, 'board' => $board, 'threadId' => (int) $thread['id'],
        'isOp' => $index === 0 || (int) $post['is_op'] === 1, 'backlinks' => $backlinks,
        'posterTokenHash' => $posterTokenHash, 'settings' => $settings, 'csrfToken' => $csrfToken,
    ]) ?>
<?php endforeach; ?>
</section>

<div id="bottom" class="thread-bottom">
    <?php if (!$threadClosed): ?><button type="button" class="primary-button" data-open-post-form>Reply to this thread</button><?php endif; ?>
    <a href="/<?= e($board['slug']) ?>/">Return to /<?= e($board['slug']) ?>/</a>
</div>
