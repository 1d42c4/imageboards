<article class="error-page">
    <p class="error-code"><?= (int) $status ?></p>
    <h1><?= e($message) ?></h1>
    <p><a href="/">Return to the board directory</a></p>
</article>

