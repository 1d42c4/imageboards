<header class="board-header compact-board-header">
    <h1>/<?= e($board['slug']) ?>/ — Archive</h1>
    <p>Read-only threads preserved by staff.</p>
    <nav class="board-actions">[ <a href="/<?= e($board['slug']) ?>/">Index</a> / <a href="/<?= e($board['slug']) ?>/catalog">Catalog</a> / <strong>Archive</strong> ]</nav>
</header>

<section class="archive-list" aria-label="Archived threads">
<?php foreach ($threads as $item): ?>
    <article>
        <a href="/<?= e($board['slug']) ?>/thread/<?= (int) $item['id'] ?>"><strong><?= e(trim((string) $item['subject']) ?: 'Thread No. ' . $item['post_id']) ?></strong></a>
        <span><?= (int) $item['reply_count'] ?> replies · <?= (int) $item['attachment_count'] ?> images · last active <?= e(format_post_time((string) $item['bumped_at'])) ?></span>
        <p><?= e(mb_substr(trim((string) $item['body']), 0, 240)) ?><?= mb_strlen(trim((string) $item['body'])) > 240 ? '…' : '' ?></p>
    </article>
<?php endforeach; ?>
<?php if ($threads === []): ?><p class="empty-state">No archived threads.</p><?php endif; ?>
</section>

