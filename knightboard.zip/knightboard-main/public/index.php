<?php

declare(strict_types=1);

use Chessboard\Application;
use Chessboard\Http\Request;

require dirname(__DIR__) . '/app/autoload.php';

$request = Request::fromGlobals();
$path = rtrim($request->path, '/') ?: '/';
$needsSession = !in_array($path, ['/health/live', '/health/ready'], true);
Application::boot(dirname(__DIR__), $needsSession)->handle($request)->send();
