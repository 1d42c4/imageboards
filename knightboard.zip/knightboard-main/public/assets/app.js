(() => {
    'use strict';

    const root = document.documentElement;
    const themes = new Set(['parchment', 'blue', 'dark']);
    const storageKeys = Object.freeze({
        theme: 'knightboard.theme',
        deleteKey: 'knightboard.delete-key',
        pendingQuote: 'knightboard.pending-quote',
    });

    root.classList.add('js');

    const storage = {
        get(type, key) {
            try {
                return window[type].getItem(key);
            } catch {
                return null;
            }
        },
        set(type, key, value) {
            try {
                window[type].setItem(key, value);
                return true;
            } catch {
                return false;
            }
        },
        remove(type, key) {
            try {
                window[type].removeItem(key);
            } catch {
                // Storage is an enhancement; the site remains usable without it.
            }
        },
    };

    const savedTheme = storage.get('localStorage', storageKeys.theme);
    if (savedTheme && themes.has(savedTheme) && root.dataset.theme !== 'admin') {
        root.dataset.theme = savedTheme;
    }

    function selectOne(selector, scope = document) {
        try {
            return scope.querySelector(selector);
        } catch {
            return null;
        }
    }

    function reducedMotion() {
        return window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    }

    function digits(value) {
        const candidate = String(value ?? '');
        return /^[1-9][0-9]*$/.test(candidate) ? candidate : null;
    }

    function updateThemeControls() {
        const current = root.dataset.theme || 'parchment';
        document.querySelectorAll('[data-theme-value]').forEach((control) => {
            const active = control.dataset.themeValue === current;
            control.setAttribute('aria-pressed', String(active));
            if (control instanceof HTMLOptionElement) {
                control.selected = active;
            }
        });
        document.querySelectorAll('select[data-theme-switcher]').forEach((control) => {
            if (control instanceof HTMLSelectElement) {
                control.value = current;
            }
        });
    }

    function setTheme(theme, persist = true) {
        if (!themes.has(theme) || root.dataset.theme === 'admin') {
            return;
        }
        root.dataset.theme = theme;
        if (persist) {
            storage.set('localStorage', storageKeys.theme, theme);
        }
        updateThemeControls();
        document.dispatchEvent(new CustomEvent('knightboard:themechange', {
            detail: { theme },
        }));
    }

    async function writeClipboard(text) {
        if (navigator.clipboard?.writeText && window.isSecureContext) {
            try {
                await navigator.clipboard.writeText(text);
                return true;
            } catch {
                // The selection fallback also works when clipboard permission is denied.
            }
        }

        const helper = document.createElement('textarea');
        helper.className = 'clipboard-helper';
        helper.value = text;
        helper.readOnly = true;
        helper.setAttribute('aria-hidden', 'true');
        document.body.append(helper);
        helper.select();
        helper.setSelectionRange(0, helper.value.length);
        let copied = false;
        try {
            copied = document.execCommand('copy');
        } catch {
            copied = false;
        }
        helper.remove();
        return copied;
    }

    const copyTimers = new WeakMap();

    function showCopyState(button, succeeded) {
        const oldTimer = copyTimers.get(button);
        if (oldTimer) {
            window.clearTimeout(oldTimer);
        }
        if (!button.dataset.copyOriginalLabel) {
            button.dataset.copyOriginalLabel = button.textContent?.trim() || 'Copy';
        }
        button.dataset.copyState = succeeded ? 'success' : 'error';
        button.textContent = succeeded ? 'Copied' : 'Copy failed';
        button.setAttribute('aria-live', 'polite');

        const timer = window.setTimeout(() => {
            button.textContent = button.dataset.copyOriginalLabel || 'Copy';
            button.removeAttribute('data-copy-state');
            button.removeAttribute('aria-live');
            copyTimers.delete(button);
        }, 1800);
        copyTimers.set(button, timer);
    }

    function textToCopy(button) {
        if (button.hasAttribute('data-copy-link')) {
            const rawLink = button.dataset.copyLink || window.location.href;
            try {
                return new URL(rawLink, window.location.href).href;
            } catch {
                return rawLink;
            }
        }
        if (button.hasAttribute('data-copy-target')) {
            const target = selectOne(button.dataset.copyTarget || '');
            if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
                return target.value;
            }
            return target?.textContent?.trim() ?? '';
        }
        return button.dataset.copy ?? '';
    }

    const referenceTimers = new WeakMap();

    function postById(postId) {
        const safeId = digits(postId);
        if (!safeId) {
            return null;
        }
        const post = document.getElementById(`p${safeId}`);
        return post instanceof HTMLElement ? post : null;
    }

    function markReferenced(post, duration = 2200) {
        document.querySelectorAll('.post.is-referenced').forEach((item) => {
            if (item !== post) {
                item.classList.remove('is-referenced');
            }
        });
        const oldTimer = referenceTimers.get(post);
        if (oldTimer) {
            window.clearTimeout(oldTimer);
        }
        post.classList.add('is-referenced');
        const timer = window.setTimeout(() => {
            post.classList.remove('is-referenced');
            referenceTimers.delete(post);
        }, duration);
        referenceTimers.set(post, timer);
    }

    function revealPost(post, updateAddress = true) {
        markReferenced(post);
        post.scrollIntoView({
            behavior: reducedMotion() ? 'auto' : 'smooth',
            block: 'center',
        });
        post.focus({ preventScroll: true });
        if (updateAddress && post.id) {
            try {
                window.history.pushState(null, '', `#${post.id}`);
            } catch {
                // Hash navigation has already done the important work.
            }
        }
    }

    function replyForm() {
        const forms = Array.from(document.querySelectorAll('form[data-post-form]'));
        return forms.find((form) => {
            try {
                return /\/reply\/?$/.test(new URL(form.action, window.location.href).pathname);
            } catch {
                return false;
            }
        }) ?? null;
    }

    function openPostingArea(form, focusComment = true) {
        if (!(form instanceof HTMLFormElement)) {
            return false;
        }
        const details = form.closest('details');
        if (details instanceof HTMLDetailsElement) {
            details.open = true;
        }
        const comment = form.querySelector('[data-comment], textarea[name="body"], textarea[name="comment"]');
        if (focusComment && comment instanceof HTMLTextAreaElement) {
            comment.focus({ preventScroll: true });
            comment.scrollIntoView({
                behavior: reducedMotion() ? 'auto' : 'smooth',
                block: 'center',
            });
        }
        return true;
    }

    function insertQuote(postId, form = replyForm()) {
        const safeId = digits(postId);
        if (!safeId || !(form instanceof HTMLFormElement)) {
            return false;
        }
        const comment = form.querySelector('[data-comment], textarea[name="body"], textarea[name="comment"]');
        if (!(comment instanceof HTMLTextAreaElement)) {
            return false;
        }

        const start = comment.selectionStart ?? comment.value.length;
        const end = comment.selectionEnd ?? start;
        const prefix = start > 0 && comment.value.charAt(start - 1) !== '\n' ? '\n' : '';
        const quote = `${prefix}>>${safeId}\n`;
        comment.setRangeText(quote, start, end, 'end');
        openPostingArea(form, true);
        comment.dispatchEvent(new Event('input', { bubbles: true }));
        const post = postById(safeId);
        if (post) {
            markReferenced(post);
        }
        return true;
    }

    function rememberQuoteAndVisit(postId, trigger) {
        const post = trigger.closest('.post');
        const permalink = post?.querySelector('.post-number[href]');
        if (!(permalink instanceof HTMLAnchorElement)) {
            return false;
        }
        let destination;
        try {
            destination = new URL(permalink.href, window.location.href);
        } catch {
            return false;
        }
        storage.set('sessionStorage', storageKeys.pendingQuote, JSON.stringify({
            id: postId,
            path: destination.pathname,
            savedAt: Date.now(),
        }));
        window.location.assign(destination.href);
        return true;
    }

    function restorePendingQuote() {
        const encoded = storage.get('sessionStorage', storageKeys.pendingQuote);
        if (!encoded) {
            return;
        }
        let pending;
        try {
            pending = JSON.parse(encoded);
        } catch {
            storage.remove('sessionStorage', storageKeys.pendingQuote);
            return;
        }
        const currentForm = replyForm();
        const recent = Number.isFinite(pending.savedAt) && Date.now() - pending.savedAt < 5 * 60 * 1000;
        if (!recent || pending.path !== window.location.pathname || !currentForm) {
            if (!recent || pending.path === window.location.pathname) {
                storage.remove('sessionStorage', storageKeys.pendingQuote);
            }
            return;
        }
        storage.remove('sessionStorage', storageKeys.pendingQuote);
        insertQuote(pending.id, currentForm);
    }

    function targetFromControl(control, attributes) {
        let reference = '';
        for (const attribute of attributes) {
            if (control.hasAttribute(attribute)) {
                reference = control.getAttribute(attribute) || '';
                break;
            }
        }
        reference ||= control.getAttribute('aria-controls') || '';
        if (!reference) {
            return null;
        }
        const selector = reference.startsWith('#') ? reference : `#${reference}`;
        return selectOne(selector);
    }

    const modalOpeners = new WeakMap();

    function focusFirst(target) {
        const focusable = target.querySelector(
            'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        );
        if (focusable instanceof HTMLElement) {
            focusable.focus();
        }
    }

    function openModal(target, opener) {
        if (!(target instanceof HTMLElement)) {
            return;
        }
        modalOpeners.set(target, opener);
        if (target instanceof HTMLDialogElement && typeof target.showModal === 'function') {
            if (!target.open) {
                target.showModal();
            }
        } else {
            target.hidden = false;
            target.classList.add('is-open');
            target.setAttribute('role', target.getAttribute('role') || 'dialog');
            target.setAttribute('aria-modal', 'true');
        }
        requestAnimationFrame(() => focusFirst(target));
    }

    function closeModal(target) {
        if (!(target instanceof HTMLElement)) {
            return;
        }
        if (target instanceof HTMLDialogElement && target.open) {
            target.close();
        } else {
            target.classList.remove('is-open');
            target.hidden = true;
        }
        const opener = modalOpeners.get(target);
        if (opener instanceof HTMLElement && opener.isConnected) {
            opener.focus();
        }
        modalOpeners.delete(target);
    }

    function toggleDisclosure(control) {
        const target = targetFromControl(control, [
            'data-disclosure-target',
            'data-quick-reply-target',
            'data-quick-reply-toggle',
        ]);
        if (!(target instanceof HTMLElement)) {
            return false;
        }
        if (target instanceof HTMLDialogElement || target.matches('.modal, [role="dialog"]')) {
            openModal(target, control);
            control.setAttribute('aria-expanded', 'true');
            return true;
        }
        if (target instanceof HTMLDetailsElement) {
            target.open = !target.open;
            control.setAttribute('aria-expanded', String(target.open));
            if (target.open) {
                focusFirst(target);
            }
            return true;
        }
        const willOpen = target.hidden || !target.classList.contains('is-open');
        target.hidden = !willOpen;
        target.classList.toggle('is-open', willOpen);
        control.setAttribute('aria-expanded', String(willOpen));
        if (willOpen) {
            focusFirst(target);
        }
        return true;
    }

    function generateDeleteKey() {
        if (!window.crypto?.getRandomValues) {
            return '';
        }
        const bytes = new Uint8Array(24);
        window.crypto.getRandomValues(bytes);
        let binary = '';
        bytes.forEach((byte) => {
            binary += String.fromCharCode(byte);
        });
        return window.btoa(binary)
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=+$/g, '');
    }

    function setupDeleteKey() {
        let saved = storage.get('localStorage', storageKeys.deleteKey);
        if (!saved) {
            saved = generateDeleteKey();
            if (saved) {
                storage.set('localStorage', storageKeys.deleteKey, saved);
            }
        }
        if (saved) {
            document.querySelectorAll('[data-deletion-password]').forEach((field) => {
                if (field instanceof HTMLInputElement && !field.value) {
                    field.value = saved;
                }
            });
        }

        document.querySelectorAll('form[data-post-form]').forEach((form) => {
            form.addEventListener('submit', () => {
                const field = form.querySelector('[data-deletion-password]');
                if (field instanceof HTMLInputElement && field.value) {
                    storage.set('localStorage', storageKeys.deleteKey, field.value);
                }
            });
        });
    }

    function setupCatalog() {
        const grid = document.querySelector('[data-catalog-grid]');
        if (!(grid instanceof HTMLElement)) {
            return;
        }
        const filter = document.querySelector('[data-catalog-filter]');
        const sorter = document.querySelector('[data-catalog-sort]');
        const cards = Array.from(grid.querySelectorAll('.catalog-card'));
        cards.forEach((card, index) => {
            card.dataset.originalOrder = String(index);
        });

        const status = document.createElement('p');
        status.className = 'sr-only';
        status.setAttribute('role', 'status');
        status.setAttribute('aria-live', 'polite');
        grid.after(status);

        const applyFilter = () => {
            const term = filter instanceof HTMLInputElement ? filter.value.trim().toLocaleLowerCase() : '';
            let visible = 0;
            cards.forEach((card) => {
                const matches = !term || (card.dataset.search || '').toLocaleLowerCase().includes(term);
                card.hidden = !matches;
                if (matches) {
                    visible += 1;
                }
            });
            status.textContent = `${visible} thread${visible === 1 ? '' : 's'} shown`;
        };

        const applySort = () => {
            const mode = sorter instanceof HTMLSelectElement ? sorter.value : 'bump';
            const sorted = [...cards].sort((left, right) => {
                if (mode === 'replies') {
                    return Number(right.dataset.replies || 0) - Number(left.dataset.replies || 0);
                }
                if (mode === 'newest') {
                    return (right.dataset.created || '').localeCompare(left.dataset.created || '');
                }
                const bumpOrder = (right.dataset.bump || '').localeCompare(left.dataset.bump || '');
                return bumpOrder || Number(left.dataset.originalOrder) - Number(right.dataset.originalOrder);
            });
            const fragment = document.createDocumentFragment();
            sorted.forEach((card) => fragment.append(card));
            grid.append(fragment);
        };

        filter?.addEventListener('input', applyFilter);
        sorter?.addEventListener('change', applySort);
        applyFilter();
    }

    const preview = document.getElementById('quote-preview');
    const canPreview = window.matchMedia?.('(hover: hover) and (pointer: fine)').matches ?? false;

    function showQuotePreview(link) {
        if (!(preview instanceof HTMLElement) || !canPreview) {
            return;
        }
        const post = postById(link.dataset.postRef);
        if (!post) {
            return;
        }
        const clone = post.cloneNode(true);
        if (!(clone instanceof HTMLElement)) {
            return;
        }
        clone.removeAttribute('id');
        clone.removeAttribute('tabindex');
        clone.removeAttribute('data-post-id');
        clone.classList.remove('is-referenced', 'is-reference-hover');
        clone.classList.add('quote-preview-post');
        clone.querySelectorAll('[id]').forEach((item) => item.removeAttribute('id'));
        clone.querySelectorAll('.post-menu, .backlinks, form, button').forEach((item) => item.remove());
        clone.querySelectorAll('a').forEach((item) => item.setAttribute('tabindex', '-1'));
        preview.replaceChildren(clone);
        preview.setAttribute('role', 'tooltip');
        preview.hidden = false;
        post.classList.add('is-reference-hover');
    }

    function hideQuotePreview(link) {
        const post = postById(link?.dataset.postRef);
        post?.classList.remove('is-reference-hover');
        if (preview instanceof HTMLElement) {
            preview.hidden = true;
            preview.replaceChildren();
        }
    }

    document.addEventListener('click', async (event) => {
        const target = event.target;
        if (!(target instanceof Element)) {
            return;
        }

        const themeControl = target.closest('[data-theme-value]');
        if (themeControl instanceof HTMLElement) {
            event.preventDefault();
            setTheme(themeControl.dataset.themeValue || '');
            return;
        }

        const copyButton = target.closest('[data-copy], [data-copy-link], [data-copy-target]');
        if (copyButton instanceof HTMLButtonElement) {
            event.preventDefault();
            const copied = await writeClipboard(textToCopy(copyButton));
            showCopyState(copyButton, copied);
            return;
        }

        const quoteControl = target.closest('[data-quote]');
        if (quoteControl instanceof HTMLElement) {
            const postId = digits(quoteControl.dataset.quote);
            if (postId) {
                event.preventDefault();
                if (!insertQuote(postId)) {
                    rememberQuoteAndVisit(postId, quoteControl);
                }
                quoteControl.closest('.post-menu')?.removeAttribute('open');
            }
            return;
        }

        const reference = target.closest('[data-post-ref]');
        if (reference instanceof HTMLAnchorElement) {
            const post = postById(reference.dataset.postRef);
            let localReference = false;
            try {
                const url = new URL(reference.href, window.location.href);
                localReference = url.origin === window.location.origin
                    && url.pathname === window.location.pathname
                    && url.search === window.location.search;
            } catch {
                localReference = false;
            }
            if (post && localReference) {
                event.preventDefault();
                revealPost(post);
            }
            return;
        }

        const openPostForm = target.closest('[data-open-post-form]');
        if (openPostForm instanceof HTMLElement) {
            event.preventDefault();
            openPostingArea(replyForm(), true);
            return;
        }

        const modalControl = target.closest('[data-modal-open], [data-modal-target]');
        if (modalControl instanceof HTMLElement) {
            const modal = targetFromControl(modalControl, ['data-modal-open', 'data-modal-target']);
            if (modal instanceof HTMLElement) {
                event.preventDefault();
                openModal(modal, modalControl);
            }
            return;
        }

        const closeControl = target.closest('[data-modal-close], [data-close-modal]');
        if (closeControl instanceof HTMLElement) {
            const modal = closeControl.closest('dialog, .modal, [role="dialog"]');
            if (modal instanceof HTMLElement) {
                event.preventDefault();
                closeModal(modal);
            }
            return;
        }

        const disclosure = target.closest('[data-disclosure-target], [data-quick-reply-target], [data-quick-reply-toggle]');
        if (disclosure instanceof HTMLElement && toggleDisclosure(disclosure)) {
            event.preventDefault();
            return;
        }

        const spoiler = target.closest('.spoiler');
        if (spoiler instanceof HTMLElement) {
            spoiler.classList.toggle('is-revealed');
        }

        document.querySelectorAll('.post-menu[open]').forEach((menu) => {
            if (!menu.contains(target)) {
                menu.removeAttribute('open');
            }
        });
    });

    document.addEventListener('change', (event) => {
        const target = event.target;
        if (target instanceof HTMLSelectElement && target.matches('[data-theme-switcher]')) {
            setTheme(target.value);
        }
    });

    document.addEventListener('submit', (event) => {
        const submitter = event.submitter;
        const message = submitter instanceof HTMLElement ? submitter.dataset.confirm : null;
        if (message && !window.confirm(message)) {
            event.preventDefault();
        }
    });

    document.addEventListener('pointerover', (event) => {
        const target = event.target;
        if (!(target instanceof Element)) {
            return;
        }
        const link = target.closest('[data-post-ref]');
        const related = event.relatedTarget;
        if (!(link instanceof HTMLAnchorElement) || (related instanceof Node && link.contains(related))) {
            return;
        }
        showQuotePreview(link);
    });

    document.addEventListener('pointerout', (event) => {
        const target = event.target;
        if (!(target instanceof Element)) {
            return;
        }
        const link = target.closest('[data-post-ref]');
        const related = event.relatedTarget;
        if (!(link instanceof HTMLAnchorElement) || (related instanceof Node && link.contains(related))) {
            return;
        }
        hideQuotePreview(link);
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            hideQuotePreview(null);
            const genericModal = document.querySelector('.modal.is-open, [role="dialog"].is-open');
            if (genericModal instanceof HTMLElement) {
                closeModal(genericModal);
            }
            document.querySelectorAll('.post-menu[open]').forEach((menu) => menu.removeAttribute('open'));
        }
        if ((event.key === 'Enter' || event.key === ' ') && event.target instanceof HTMLElement && event.target.matches('.spoiler')) {
            event.preventDefault();
            event.target.classList.toggle('is-revealed');
        }
    });

    document.querySelectorAll('dialog').forEach((dialog) => {
        dialog.addEventListener('click', (event) => {
            if (event.target === dialog) {
                closeModal(dialog);
            }
        });
    });

    window.addEventListener('hashchange', () => {
        const match = window.location.hash.match(/^#p([1-9][0-9]*)$/);
        const post = match ? postById(match[1]) : null;
        if (post) {
            markReferenced(post);
        }
    });

    updateThemeControls();
    setupDeleteKey();
    setupCatalog();
    restorePendingQuote();

    const initialPost = window.location.hash.match(/^#p([1-9][0-9]*)$/);
    if (initialPost) {
        const post = postById(initialPost[1]);
        if (post) {
            markReferenced(post, 3200);
        }
    }
})();
