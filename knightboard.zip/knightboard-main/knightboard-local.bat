@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Knightboard Local Runner
cd /d "%~dp0"

set "MODE=%~1"
if /I "%MODE%"=="--test-only" set "MODE=test"
if /I "%MODE%"=="--serve-only" set "MODE=serve"
if /I "%MODE%"=="help" goto :usage
if /I "%MODE%"=="--help" goto :usage
if /I "%MODE%"=="-h" goto :usage
if not "%MODE%"=="" if /I not "%MODE%"=="test" if /I not "%MODE%"=="serve" goto :usage_error

if not defined KNIGHTBOARD_PORT set "KNIGHTBOARD_PORT=8080"

if defined KNIGHTBOARD_PHP goto :php_override
if exist "C:\php\php.exe" (
    set "PHP_EXE=C:\php\php.exe"
    goto :php_found
)
where.exe php >nul 2>nul
if errorlevel 1 goto :php_missing
for /f "delims=" %%P in ('where.exe php 2^>nul') do if not defined PHP_EXE set "PHP_EXE=%%P"
goto :php_found

:php_override
set "PHP_EXE=%KNIGHTBOARD_PHP%"
if not exist "%PHP_EXE%" goto :php_override_missing

:php_found
if not exist "public\index.php" goto :project_missing
if not exist "router.php" goto :project_missing
if not exist "tests\run.php" goto :project_missing

echo.
echo ============================================================
echo   Knightboard local runner
echo ============================================================
echo   PHP:  %PHP_EXE%
echo   Port: %KNIGHTBOARD_PORT%
echo.

echo [1/3] Checking PHP 8.5.8 and required extensions...
"%PHP_EXE%" -r "if (PHP_VERSION !== '8.5.8') { fwrite(STDERR, 'Knightboard requires PHP 8.5.8; found '.PHP_VERSION.PHP_EOL); exit(1); } echo 'PHP '.PHP_VERSION.' is ready.'.PHP_EOL;"
if errorlevel 1 goto :runtime_failed
"%PHP_EXE%" -r "$missing = []; foreach (['fileinfo', 'gd', 'mbstring', 'PDO', 'pdo_sqlite'] as $extension) { if (!extension_loaded($extension)) { $missing[] = $extension; } } if ($missing) { fwrite(STDERR, 'Missing PHP extensions: '.implode(', ', $missing).PHP_EOL); exit(1); } echo 'Required PHP extensions are available.'.PHP_EOL;"
if errorlevel 1 goto :runtime_failed
"%PHP_EXE%" -r "$port = filter_var($argv[1], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]); exit($port === false ? 1 : 0);" "%KNIGHTBOARD_PORT%"
if errorlevel 1 goto :port_invalid

if /I "%MODE%"=="serve" goto :serve

echo.
echo [2/3] Running the complete local test suite...
"%PHP_EXE%" tests\run.php
if errorlevel 1 goto :tests_failed

if /I "%MODE%"=="test" goto :tests_complete

:serve
echo.
echo [3/3] Starting Knightboard...
echo.
echo   Site:  http://127.0.0.1:%KNIGHTBOARD_PORT%/
echo   Admin: http://127.0.0.1:%KNIGHTBOARD_PORT%/admin/setup
echo.
echo Press Ctrl+C in this window to stop the server.
echo ============================================================
echo.

start "" powershell.exe -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Milliseconds 900; Start-Process 'http://127.0.0.1:%KNIGHTBOARD_PORT%/'"
"%PHP_EXE%" -S 127.0.0.1:%KNIGHTBOARD_PORT% -t public router.php
set "SERVER_EXIT=%ERRORLEVEL%"
echo.
if not "%SERVER_EXIT%"=="0" echo The local server exited with code %SERVER_EXIT%.
exit /b %SERVER_EXIT%

:tests_complete
echo.
echo ============================================================
echo   All Knightboard tests passed. Test-only run complete.
echo ============================================================
exit /b 0

:php_missing
echo.
echo ERROR: PHP was not found.
echo Install PHP 8.5.8 at C:\php\php.exe, add it to PATH, or set
echo KNIGHTBOARD_PHP to the full path of php.exe.
goto :failure

:php_override_missing
echo.
echo ERROR: KNIGHTBOARD_PHP does not point to an existing file:
echo %KNIGHTBOARD_PHP%
goto :failure

:project_missing
echo.
echo ERROR: Run this batch file from the Knightboard project root.
echo Required application or test files are missing.
goto :failure

:runtime_failed
echo.
echo ERROR: The PHP runtime check failed. The server was not started.
goto :failure

:port_invalid
echo.
echo ERROR: KNIGHTBOARD_PORT must be a number from 1 through 65535.
goto :failure

:tests_failed
echo.
echo ERROR: Tests failed. Fix the reported failure before starting the site.
goto :failure

:usage_error
echo.
echo ERROR: Unknown option "%MODE%".

:usage
echo.
echo Usage: knightboard-local.bat [test^|serve]
echo.
echo   no option  Run tests, start the server, and open the browser.
echo   test       Run environment checks and tests, then exit.
echo   serve      Check the environment and start without running tests.
echo.
echo Optional environment variables:
echo   KNIGHTBOARD_PHP   Full path to PHP 8.5.8 php.exe
echo   KNIGHTBOARD_PORT  Local port, default 8080
exit /b 0

:failure
echo.
pause
exit /b 1

