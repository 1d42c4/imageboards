<?php

declare(strict_types=1);

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
}

function format_post_time(string $value): string
{
    try {
        return (new DateTimeImmutable($value, new DateTimeZone('UTC')))->format('Y-m-d H:i:s') . ' UTC';
    } catch (Throwable) {
        return $value;
    }
}

function human_age(string $value): string
{
    try {
        $seconds = max(0, time() - (new DateTimeImmutable($value, new DateTimeZone('UTC')))->getTimestamp());
    } catch (Throwable) {
        return 'unknown';
    }
    return match (true) {
        $seconds < 60 => $seconds . 's',
        $seconds < 3600 => intdiv($seconds, 60) . 'm',
        $seconds < 86400 => intdiv($seconds, 3600) . 'h',
        default => intdiv($seconds, 86400) . 'd',
    };
}

function human_filesize(int $bytes): string
{
    return match (true) {
        $bytes >= 1_048_576 => number_format($bytes / 1_048_576, 2) . ' MiB',
        $bytes >= 1024 => number_format($bytes / 1024, 1) . ' KiB',
        default => $bytes . ' B',
    };
}

/** @return list<int> */
function quoted_post_ids(string $body): array
{
    preg_match_all('/>>([1-9][0-9]{0,18})/', $body, $matches);
    return array_values(array_unique(array_map('intval', $matches[1] ?? [])));
}

function render_post_body(string $body, string $threadUrl): string
{
    $escaped = e(str_replace(["\r\n", "\r"], "\n", $body));
    $escaped = preg_replace_callback(
        '/&gt;&gt;([1-9][0-9]{0,18})/',
        static fn (array $match): string => '<a class="quote-link" href="' . e($threadUrl) . '#p' . $match[1] . '" data-post-ref="' . $match[1] . '">&gt;&gt;' . $match[1] . '</a>',
        $escaped,
    ) ?? $escaped;
    $escaped = preg_replace('/\[spoiler\](.*?)\[\/spoiler\]/is', '<span class="spoiler" tabindex="0">$1</span>', $escaped) ?? $escaped;

    $lines = explode("\n", $escaped);
    foreach ($lines as &$line) {
        if (str_starts_with($line, '&gt;') && !str_starts_with($line, '<a class="quote-link"')) {
            $line = '<span class="greentext">' . $line . '</span>';
        }
    }
    unset($line);
    return implode("<br>\n", $lines);
}

function valid_fen(string $fen): bool
{
    if ($fen === '') {
        return true;
    }
    $parts = preg_split('/\s+/', trim($fen));
    if ($parts === false || count($parts) !== 6) {
        return false;
    }
    $ranks = explode('/', $parts[0]);
    if (count($ranks) !== 8) {
        return false;
    }
    foreach ($ranks as $rank) {
        $count = 0;
        foreach (str_split($rank) as $symbol) {
            if ($symbol >= '1' && $symbol <= '8') {
                $count += (int) $symbol;
            } elseif (str_contains('prnbqkPRNBQK', $symbol)) {
                $count++;
            } else {
                return false;
            }
        }
        if ($count !== 8) {
            return false;
        }
    }
    if (!in_array($parts[1], ['w', 'b'], true)) {
        return false;
    }
    if (!preg_match('/^(?:-|K?Q?k?q?)$/', $parts[2])) {
        return false;
    }
    if (!preg_match('/^(?:-|[a-h][36])$/', $parts[3])) {
        return false;
    }
    return ctype_digit($parts[4]) && ctype_digit($parts[5]) && (int) $parts[5] >= 1;
}

function render_fen_board(string $fen, bool $includeCopyButton = true): string
{
    if (!valid_fen($fen) || $fen === '') {
        return '';
    }
    $placement = explode(' ', $fen)[0];
    $pieces = [
        'K' => ['♔', 'white king'], 'Q' => ['♕', 'white queen'], 'R' => ['♖', 'white rook'],
        'B' => ['♗', 'white bishop'], 'N' => ['♘', 'white knight'], 'P' => ['♙', 'white pawn'],
        'k' => ['♚', 'black king'], 'q' => ['♛', 'black queen'], 'r' => ['♜', 'black rook'],
        'b' => ['♝', 'black bishop'], 'n' => ['♞', 'black knight'], 'p' => ['♟', 'black pawn'],
    ];
    $html = '<div class="fen-wrap"><div class="chessboard" role="grid" aria-label="Chess position">';
    foreach (explode('/', $placement) as $rankIndex => $rank) {
        $fileIndex = 0;
        foreach (str_split($rank) as $symbol) {
            $symbols = ctype_digit($symbol) ? array_fill(0, (int) $symbol, '') : [$symbol];
            foreach ($symbols as $piece) {
                $square = chr(97 + $fileIndex) . (8 - $rankIndex);
                $label = $piece === '' ? "{$square}, empty" : "{$square}, " . $pieces[$piece][1];
                $glyph = $piece === '' ? '' : $pieces[$piece][0];
                $shade = (($rankIndex + $fileIndex) % 2 === 0) ? 'light' : 'dark';
                $html .= '<span class="square ' . $shade . '" role="gridcell" aria-label="' . e($label) . '" data-square="' . $square . '">' . $glyph . '</span>';
                $fileIndex++;
            }
        }
    }
    $html .= '</div>';
    if ($includeCopyButton) {
        $html .= '<button class="copy-fen" type="button" data-copy="' . e($fen) . '">Copy FEN</button>';
    }
    return $html . '</div>';
}

function role_allows(string $role, string $capability): bool
{
    $rank = ['moderator' => 1, 'administrator' => 2, 'owner' => 3][$role] ?? 0;
    $required = ['moderate' => 1, 'boards' => 2, 'settings' => 2, 'staff' => 3][$capability] ?? 3;
    return $rank >= $required;
}
