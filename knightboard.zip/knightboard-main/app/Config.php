<?php

declare(strict_types=1);

namespace Chessboard;

final readonly class Config
{
    public function __construct(
        public string $basePath,
        public string $databasePath,
        public string $storagePath,
        public string $uploadPath,
        public string $sessionPath,
        public string $appKey,
        public bool $debug,
        public int $maxUploadBytes,
    ) {
    }

    public static function load(string $basePath): self
    {
        $basePath = rtrim($basePath, DIRECTORY_SEPARATOR);
        $storage = self::env('CHESSBOARD_STORAGE_PATH', $basePath . DIRECTORY_SEPARATOR . 'storage');
        self::ensureDirectory($storage);
        self::ensureDirectory($storage . DIRECTORY_SEPARATOR . 'uploads');
        self::ensureDirectory($storage . DIRECTORY_SEPARATOR . 'sessions');

        $key = self::env('CHESSBOARD_APP_KEY', '');
        if ($key === '') {
            $keyFile = $storage . DIRECTORY_SEPARATOR . 'app.key';
            if (!is_file($keyFile)) {
                $generated = bin2hex(random_bytes(32));
                if (file_put_contents($keyFile, $generated, LOCK_EX) === false) {
                    throw new \RuntimeException('Unable to create the application key in storage.');
                }
            }
            $key = trim((string) file_get_contents($keyFile));
        }

        if (strlen($key) < 32) {
            throw new \RuntimeException('CHESSBOARD_APP_KEY must contain at least 32 characters.');
        }

        return new self(
            basePath: $basePath,
            databasePath: self::env('CHESSBOARD_DATABASE_PATH', $storage . DIRECTORY_SEPARATOR . 'chessboard.sqlite'),
            storagePath: $storage,
            uploadPath: $storage . DIRECTORY_SEPARATOR . 'uploads',
            sessionPath: $storage . DIRECTORY_SEPARATOR . 'sessions',
            appKey: $key,
            debug: filter_var(self::env('CHESSBOARD_DEBUG', '0'), FILTER_VALIDATE_BOOL),
            maxUploadBytes: max(1_048_576, (int) self::env('CHESSBOARD_MAX_UPLOAD_BYTES', '8388608')),
        );
    }

    private static function env(string $name, string $default): string
    {
        $value = getenv($name);
        return $value === false || $value === '' ? $default : $value;
    }

    private static function ensureDirectory(string $path): void
    {
        if (!is_dir($path) && !mkdir($path, 0770, true) && !is_dir($path)) {
            throw new \RuntimeException("Unable to create directory: {$path}");
        }
    }
}

