<?php

declare(strict_types=1);

namespace Chessboard\Controller;

use Chessboard\Http\Request;
use Chessboard\Http\Response;
use Chessboard\Repository\AdminRepository;
use Chessboard\Repository\BoardRepository;
use Chessboard\Security;
use Chessboard\Service\AdminService;
use Chessboard\Settings;
use Chessboard\View;

final readonly class AdminController
{
    public function __construct(
        private AdminService $service,
        private AdminRepository $repository,
        private BoardRepository $boards,
        private Settings $settings,
        private Security $security,
        private View $view,
    ) {
    }

    public function loginPage(): Response
    {
        if (!$this->service->hasAdmins()) {
            return Response::redirect('/admin/setup', 302);
        }
        if ($this->service->current() !== null) {
            return Response::redirect('/admin', 302);
        }
        return Response::html($this->view->render('admin/login', $this->authData('Staff sign in'), 'admin/auth_layout'));
    }

    public function setupPage(): Response
    {
        if ($this->service->hasAdmins()) {
            return Response::redirect('/admin/login', 302);
        }
        return Response::html($this->view->render('admin/setup', $this->authData('Create the first owner'), 'admin/auth_layout'));
    }

    public function dashboard(): Response
    {
        $admin = $this->service->current();
        if ($admin === null) {
            return Response::redirect('/admin/login', 302);
        }
        return $this->adminView('admin/dashboard', 'Dashboard', $admin, [
            'stats' => $this->repository->stats(),
            'reports' => array_slice($this->repository->reports('open'), 0, 10),
            'auditEntries' => array_slice($this->repository->audit(), 0, 12),
        ]);
    }

    public function reports(Request $request): Response
    {
        $admin = $this->service->current();
        if ($admin === null) {
            return Response::redirect('/admin/login', 302);
        }
        $status = $request->queryString('status', 'open');
        return $this->adminView('admin/reports', 'Reports', $admin, [
            'reportStatus' => $status,
            'reports' => $this->repository->reports($status),
        ]);
    }

    public function posts(Request $request): Response
    {
        $admin = $this->service->current();
        if ($admin === null) {
            return Response::redirect('/admin/login', 302);
        }
        $query = mb_substr($request->queryString('q'), 0, 100);
        $boardId = max(0, $request->queryInt('board', 0));
        $state = $request->queryString('state', 'visible');
        return $this->adminView('admin/posts', 'Posts & threads', $admin, [
            'query' => $query,
            'selectedBoard' => $boardId,
            'state' => $state,
            'posts' => $this->repository->posts($query, $boardId, $state),
        ]);
    }

    public function boards(): Response
    {
        $admin = $this->service->current();
        if ($admin === null) {
            return Response::redirect('/admin/login', 302);
        }
        return $this->adminView('admin/boards', 'Boards', $admin);
    }

    public function settings(): Response
    {
        $admin = $this->service->current();
        if ($admin === null) {
            return Response::redirect('/admin/login', 302);
        }
        return $this->adminView('admin/settings', 'Site settings', $admin);
    }

    public function filters(): Response
    {
        $admin = $this->service->current();
        if ($admin === null) {
            return Response::redirect('/admin/login', 302);
        }
        return $this->adminView('admin/filters', 'Content filters', $admin, ['filters' => $this->repository->filters()]);
    }

    public function staff(): Response
    {
        $admin = $this->service->current();
        if ($admin === null) {
            return Response::redirect('/admin/login', 302);
        }
        return $this->adminView('admin/staff', 'Staff accounts', $admin, ['staff' => $this->repository->staff()]);
    }

    public function audit(): Response
    {
        $admin = $this->service->current();
        if ($admin === null) {
            return Response::redirect('/admin/login', 302);
        }
        return $this->adminView('admin/audit', 'Audit log', $admin, [
            'auditEntries' => $this->repository->audit(),
            'restrictions' => $this->repository->restrictions(),
        ]);
    }

    public function setup(Request $request): Response
    {
        try {
            $this->service->setupOwner($request);
            $this->security->flash('success', 'Owner account created.');
            return Response::redirect('/admin');
        } catch (\InvalidArgumentException $exception) {
            $this->security->flash('error', $exception->getMessage());
            return Response::redirect('/admin/setup');
        }
    }

    public function login(Request $request): Response
    {
        try {
            $this->service->login($request);
            return Response::redirect('/admin');
        } catch (\InvalidArgumentException $exception) {
            $this->security->flash('error', $exception->getMessage());
            return Response::redirect('/admin/login');
        }
    }

    public function logout(Request $request): Response
    {
        try {
            $this->service->logout($request);
        } catch (\InvalidArgumentException $exception) {
            $this->security->flash('error', $exception->getMessage());
        }
        return Response::redirect('/admin/login');
    }

    public function moderatePost(int $postId, Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->moderatePost($admin, $postId, $request), '/admin/posts');
    }

    public function restrictPoster(int $postId, Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->blockPostAuthor($admin, $postId, $request), '/admin/posts');
    }

    public function toggleThread(int $threadId, Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->toggleThread($admin, $threadId, $request), '/admin/posts');
    }

    public function resolveReport(int $reportId, Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->resolveReport($admin, $reportId, $request), '/admin/reports');
    }

    public function saveBoard(Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->saveBoard($admin, $request), '/admin/boards');
    }

    public function deleteBoard(int $boardId, Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->deleteBoard($admin, $boardId, $request), '/admin/boards');
    }

    public function saveSettings(Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->saveSettings($admin, $request), '/admin/settings');
    }

    public function addFilter(Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->addFilter($admin, $request), '/admin/filters');
    }

    public function changeFilter(int $filterId, Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->changeFilter($admin, $filterId, $request), '/admin/filters');
    }

    public function createStaff(Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->createStaff($admin, $request), '/admin/staff');
    }

    public function changeStaff(int $staffId, Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->changeStaff($admin, $staffId, $request), '/admin/staff');
    }

    public function removeRestriction(int $restrictionId, Request $request): Response
    {
        return $this->perform(fn (array $admin) => $this->service->removeRestriction($admin, $restrictionId, $request), '/admin/audit');
    }

    private function perform(callable $action, string $redirect): Response
    {
        $admin = $this->service->current();
        if ($admin === null) {
            return Response::redirect('/admin/login', 302);
        }
        try {
            $action($admin);
            $this->security->flash('success', 'Change saved.');
        } catch (\InvalidArgumentException $exception) {
            $this->security->flash('error', $exception->getMessage());
        } catch (\PDOException $exception) {
            if (str_contains($exception->getMessage(), 'UNIQUE constraint failed')) {
                $this->security->flash('error', 'That value is already in use.');
            } else {
                throw $exception;
            }
        }
        return Response::redirect($redirect);
    }

    /** @param array<string, mixed> $admin @param array<string, mixed> $data */
    private function adminView(string $template, string $title, array $admin, array $data = []): Response
    {
        return Response::html($this->view->render($template, $data + [
            'pageTitle' => $title,
            'admin' => $admin,
            'settings' => $this->settings->all(),
            'navBoards' => $this->boards->boards(),
            'csrfToken' => $this->security->csrfToken(),
            'flashMessages' => $this->security->consumeFlash(),
        ], 'admin/layout'));
    }

    /** @return array<string, mixed> */
    private function authData(string $title): array
    {
        return [
            'pageTitle' => $title,
            'settings' => $this->settings->all(),
            'csrfToken' => $this->security->csrfToken(),
            'flashMessages' => $this->security->consumeFlash(),
        ];
    }
}
