<?php

declare(strict_types=1);

namespace Chessboard\Controller;

use Chessboard\Http\Request;
use Chessboard\Http\Response;
use Chessboard\Repository\BoardRepository;
use Chessboard\Security;
use Chessboard\Service\PostingService;
use Chessboard\Service\PublicModerationService;
use Chessboard\Service\UploadService;
use Chessboard\Settings;
use Chessboard\View;

final readonly class PublicController
{
    public function __construct(
        private BoardRepository $boards,
        private Settings $settings,
        private Security $security,
        private View $view,
        private PostingService $posting,
        private PublicModerationService $moderation,
        private UploadService $uploads,
    ) {
    }

    public function home(): Response
    {
        return Response::html($this->view->render('home', $this->common([
            'pageTitle' => $this->settings->get('site_name', 'Knightboard'),
            'recentThreads' => $this->boards->recentThreads(),
        ])));
    }

    public function board(string $slug, Request $request): Response
    {
        $board = $this->boards->board($slug);
        if ($board === null) {
            return $this->notFound();
        }
        $page = max(1, $request->queryInt('page', 1));
        $perPage = max(1, min(50, $this->settings->int('threads_per_page', 10)));
        $result = $this->boards->boardThreads(
            (int) $board['id'],
            $page,
            $perPage,
            max(0, min(10, $this->settings->int('preview_replies', 3))),
        );
        $pages = max(1, (int) ceil($result['total'] / $perPage));
        if ($page > $pages && $result['total'] > 0) {
            return Response::redirect('/' . rawurlencode($slug) . '/?page=' . $pages, 302);
        }

        return Response::html($this->view->render('board', $this->common([
            'pageTitle' => '/' . $slug . '/ — ' . $board['name'],
            'board' => $board,
            'threads' => $result['threads'],
            'page' => $page,
            'pages' => $pages,
            'formStamp' => $this->security->formStamp('new:' . $slug),
        ])));
    }

    public function thread(string $slug, int $threadId): Response
    {
        $thread = $this->boards->thread($slug, $threadId);
        if ($thread === null) {
            return $this->notFound();
        }
        $posts = $this->boards->threadPosts($threadId);
        $available = array_fill_keys(array_map(static fn (array $post): int => (int) $post['post_id'], $posts), true);
        $backlinks = [];
        foreach ($posts as $post) {
            if ((int) $post['is_deleted'] === 1) {
                continue;
            }
            foreach (quoted_post_ids((string) $post['body']) as $quotedId) {
                if (isset($available[$quotedId])) {
                    $backlinks[$quotedId][] = (int) $post['post_id'];
                }
            }
        }

        return Response::html($this->view->render('thread', $this->common([
            'pageTitle' => '/' . $slug . '/ thread ' . $threadId,
            'board' => [
                'id' => $thread['board_id'],
                'slug' => $thread['board_slug'],
                'name' => $thread['board_name'],
                'description' => $thread['board_description'],
                'rules' => $thread['board_rules'],
                'is_locked' => $thread['board_locked'],
            ],
            'thread' => $thread,
            'posts' => $posts,
            'backlinks' => $backlinks,
            'formStamp' => $this->security->formStamp('reply:' . $threadId),
        ])));
    }

    public function catalog(string $slug): Response
    {
        $board = $this->boards->board($slug);
        if ($board === null) {
            return $this->notFound();
        }
        return Response::html($this->view->render('catalog', $this->common([
            'pageTitle' => '/' . $slug . '/ catalog',
            'board' => $board,
            'threads' => $this->boards->catalog((int) $board['id']),
        ])));
    }

    public function archive(string $slug): Response
    {
        $board = $this->boards->board($slug);
        if ($board === null) {
            return $this->notFound();
        }
        return Response::html($this->view->render('archive', $this->common([
            'pageTitle' => '/' . $slug . '/ archive',
            'board' => $board,
            'threads' => $this->boards->archive((int) $board['id']),
        ])));
    }

    public function search(string $slug, Request $request): Response
    {
        $board = $this->boards->board($slug);
        if ($board === null) {
            return $this->notFound();
        }
        $query = mb_substr($request->queryString('q'), 0, 100);
        $results = mb_strlen($query) >= 2 ? $this->boards->search((int) $board['id'], $query) : [];
        return Response::html($this->view->render('search', $this->common([
            'pageTitle' => '/' . $slug . '/ search',
            'board' => $board,
            'query' => $query,
            'results' => $results,
        ])));
    }

    public function page(string $page): Response
    {
        $allowed = ['rules', 'privacy', 'faq'];
        if (!in_array($page, $allowed, true)) {
            return $this->notFound();
        }
        return Response::html($this->view->render('pages/' . $page, $this->common([
            'pageTitle' => ucfirst($page) . ' — ' . $this->settings->get('site_name', 'Knightboard'),
        ])));
    }

    public function createThread(string $slug, Request $request): Response
    {
        $board = $this->boards->board($slug);
        if ($board === null) {
            return $this->notFound();
        }
        try {
            $created = $this->posting->createThread($board, $request);
            $this->security->flash('success', 'Thread created.');
            return Response::redirect("/{$slug}/thread/{$created['thread_id']}#p{$created['post_id']}");
        } catch (\InvalidArgumentException $exception) {
            $this->security->flash('error', $exception->getMessage());
            return Response::redirect('/' . rawurlencode($slug) . '/#post-form');
        }
    }

    public function reply(string $slug, int $threadId, Request $request): Response
    {
        $thread = $this->boards->thread($slug, $threadId);
        if ($thread === null) {
            return $this->notFound();
        }
        try {
            $postId = $this->posting->reply($thread, $request);
            return Response::redirect("/{$slug}/thread/{$threadId}#p{$postId}");
        } catch (\InvalidArgumentException $exception) {
            $this->security->flash('error', $exception->getMessage());
            return Response::redirect("/{$slug}/thread/{$threadId}#post-form");
        }
    }

    public function deletePost(int $postId, Request $request): Response
    {
        try {
            $target = $this->moderation->deleteOwn($postId, $request);
            $this->security->flash('success', 'The post was deleted.');
            return Response::redirect("/{$target['board_slug']}/thread/{$target['thread_id']}#p{$postId}");
        } catch (\InvalidArgumentException $exception) {
            $this->security->flash('error', $exception->getMessage());
            return Response::redirect('/');
        }
    }

    public function reportPost(int $postId, Request $request): Response
    {
        try {
            $target = $this->moderation->report($postId, $request);
            $this->security->flash('success', 'Report submitted for moderator review.');
            return Response::redirect("/{$target['board_slug']}/thread/{$target['thread_id']}#p{$postId}");
        } catch (\InvalidArgumentException $exception) {
            $this->security->flash('error', $exception->getMessage());
            return Response::redirect('/');
        }
    }

    public function media(string $name): Response
    {
        $media = $this->uploads->locate($name);
        if ($media === null) {
            return Response::text('Media not found.', 404);
        }
        $body = file_get_contents($media['path']);
        if ($body === false) {
            return Response::text('Media not found.', 404);
        }
        return new Response($body, 200, [
            'Content-Type' => $media['mime'],
            'Content-Length' => (string) strlen($body),
            'Cache-Control' => 'public, max-age=31536000, immutable',
            'Content-Disposition' => 'inline',
        ]);
    }

    public function notFound(): Response
    {
        return Response::html($this->view->render('error', $this->common([
            'pageTitle' => 'Not found',
            'status' => 404,
            'message' => 'That board, thread, or post could not be found.',
        ])), 404);
    }

    /** @param array<string, mixed> $data @return array<string, mixed> */
    private function common(array $data): array
    {
        return $data + [
            'settings' => $this->settings->all(),
            'navBoards' => $this->boards->boards(),
            'csrfToken' => $this->security->csrfToken(),
            'posterTokenHash' => $this->security->posterTokenHash(),
            'flashMessages' => $this->security->consumeFlash(),
        ];
    }
}
