<?php

declare(strict_types=1);

namespace Chessboard;

use Chessboard\Controller\AdminController;
use Chessboard\Controller\PublicController;
use Chessboard\Http\Request;
use Chessboard\Http\Response;
use Chessboard\Repository\AdminRepository;
use Chessboard\Repository\BoardRepository;
use Chessboard\Service\AdminService;
use Chessboard\Service\PostingService;
use Chessboard\Service\PublicModerationService;
use Chessboard\Service\UploadService;
use Throwable;

final readonly class Application
{
    private function __construct(
        private Config $config,
        private PublicController $public,
        private AdminController $admin,
    ) {
    }

    public static function boot(string $basePath, bool $startSession = true): self
    {
        $config = Config::load($basePath);
        $database = new Database($config);
        $database->migrate();
        $security = new Security($config);
        if ($startSession) {
            $security->startSession();
        }
        $settings = new Settings($database->pdo());
        $view = new View($config->basePath . DIRECTORY_SEPARATOR . 'views');
        $boards = new BoardRepository($database->pdo());
        $adminRepository = new AdminRepository($database->pdo());
        $uploads = new UploadService($config, $database->pdo());
        $posting = new PostingService($database, $settings, $security, $uploads);
        $publicModeration = new PublicModerationService($database, $security, $uploads);
        $adminService = new AdminService($database, $settings, $security, $uploads);

        return new self(
            $config,
            new PublicController($boards, $settings, $security, $view, $posting, $publicModeration, $uploads),
            new AdminController($adminService, $adminRepository, $boards, $settings, $security, $view),
        );
    }

    public function handle(Request $request): Response
    {
        try {
            return $this->dispatch($request);
        } catch (Throwable $exception) {
            if ($this->config->debug) {
                return Response::text($exception::class . ': ' . $exception->getMessage() . "\n\n" . $exception->getTraceAsString(), 500);
            }
            error_log($exception::class . ': ' . $exception->getMessage());
            return Response::html('<!doctype html><html lang="en"><meta charset="utf-8"><title>Server error</title><body><h1>Server error</h1><p>The request could not be completed.</p><p><a href="/">Return home</a></p></body></html>', 500);
        }
    }

    private function dispatch(Request $request): Response
    {
        $method = $request->method;
        $path = rtrim($request->path, '/') ?: '/';

        if ($method === 'GET' && $path === '/') return $this->public->home();
        if ($method === 'GET' && in_array($path, ['/rules', '/privacy', '/faq'], true)) return $this->public->page(substr($path, 1));
        if ($method === 'GET' && $path === '/health/live') return Response::text('ok');
        if ($method === 'GET' && $path === '/health/ready') return Response::text('ready');

        if ($method === 'GET' && $path === '/admin') return $this->admin->dashboard();
        if ($method === 'GET' && $path === '/admin/login') return $this->admin->loginPage();
        if ($method === 'POST' && $path === '/admin/login') return $this->admin->login($request);
        if ($method === 'GET' && $path === '/admin/setup') return $this->admin->setupPage();
        if ($method === 'POST' && $path === '/admin/setup') return $this->admin->setup($request);
        if ($method === 'POST' && $path === '/admin/logout') return $this->admin->logout($request);
        if ($method === 'GET' && $path === '/admin/reports') return $this->admin->reports($request);
        if ($method === 'GET' && $path === '/admin/posts') return $this->admin->posts($request);
        if ($method === 'GET' && $path === '/admin/boards') return $this->admin->boards();
        if ($method === 'GET' && $path === '/admin/settings') return $this->admin->settings();
        if ($method === 'GET' && $path === '/admin/filters') return $this->admin->filters();
        if ($method === 'GET' && $path === '/admin/staff') return $this->admin->staff();
        if ($method === 'GET' && $path === '/admin/audit') return $this->admin->audit();
        if ($method === 'POST' && $path === '/admin/boards') return $this->admin->saveBoard($request);
        if ($method === 'POST' && $path === '/admin/settings') return $this->admin->saveSettings($request);
        if ($method === 'POST' && $path === '/admin/filters') return $this->admin->addFilter($request);
        if ($method === 'POST' && $path === '/admin/staff') return $this->admin->createStaff($request);

        if ($method === 'GET' && preg_match('#^/media/(.+)$#', $path, $match)) return $this->public->media($match[1]);
        if ($method === 'POST' && preg_match('#^/post/([1-9][0-9]*)/delete$#', $path, $match)) return $this->public->deletePost((int) $match[1], $request);
        if ($method === 'POST' && preg_match('#^/post/([1-9][0-9]*)/report$#', $path, $match)) return $this->public->reportPost((int) $match[1], $request);

        if ($method === 'POST' && preg_match('#^/admin/posts/([1-9][0-9]*)/moderate$#', $path, $match)) return $this->admin->moderatePost((int) $match[1], $request);
        if ($method === 'POST' && preg_match('#^/admin/posts/([1-9][0-9]*)/restrict$#', $path, $match)) return $this->admin->restrictPoster((int) $match[1], $request);
        if ($method === 'POST' && preg_match('#^/admin/threads/([1-9][0-9]*)/toggle$#', $path, $match)) return $this->admin->toggleThread((int) $match[1], $request);
        if ($method === 'POST' && preg_match('#^/admin/reports/([1-9][0-9]*)/resolve$#', $path, $match)) return $this->admin->resolveReport((int) $match[1], $request);
        if ($method === 'POST' && preg_match('#^/admin/boards/([1-9][0-9]*)/delete$#', $path, $match)) return $this->admin->deleteBoard((int) $match[1], $request);
        if ($method === 'POST' && preg_match('#^/admin/filters/([1-9][0-9]*)$#', $path, $match)) return $this->admin->changeFilter((int) $match[1], $request);
        if ($method === 'POST' && preg_match('#^/admin/staff/([1-9][0-9]*)$#', $path, $match)) return $this->admin->changeStaff((int) $match[1], $request);
        if ($method === 'POST' && preg_match('#^/admin/restrictions/([1-9][0-9]*)/delete$#', $path, $match)) return $this->admin->removeRestriction((int) $match[1], $request);

        if (preg_match('#^/([a-z0-9]{1,12})/thread/([1-9][0-9]*)$#', $path, $match)) {
            if ($method === 'GET') return $this->public->thread($match[1], (int) $match[2]);
        }
        if ($method === 'POST' && preg_match('#^/([a-z0-9]{1,12})/thread/([1-9][0-9]*)/reply$#', $path, $match)) return $this->public->reply($match[1], (int) $match[2], $request);
        if ($method === 'POST' && preg_match('#^/([a-z0-9]{1,12})/new$#', $path, $match)) return $this->public->createThread($match[1], $request);
        if ($method === 'GET' && preg_match('#^/([a-z0-9]{1,12})/catalog$#', $path, $match)) return $this->public->catalog($match[1]);
        if ($method === 'GET' && preg_match('#^/([a-z0-9]{1,12})/archive$#', $path, $match)) return $this->public->archive($match[1]);
        if ($method === 'GET' && preg_match('#^/([a-z0-9]{1,12})/search$#', $path, $match)) return $this->public->search($match[1], $request);
        if ($method === 'GET' && preg_match('#^/([a-z0-9]{1,12})$#', $path, $match)) return $this->public->board($match[1], $request);

        return $this->public->notFound();
    }
}
