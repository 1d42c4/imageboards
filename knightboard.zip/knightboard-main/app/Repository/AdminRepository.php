<?php

declare(strict_types=1);

namespace Chessboard\Repository;

use PDO;

final readonly class AdminRepository
{
    public function __construct(private PDO $pdo)
    {
    }

    /** @return array<string, int> */
    public function stats(): array
    {
        $queries = [
            'boards' => 'SELECT COUNT(*) FROM boards',
            'live_threads' => 'SELECT COUNT(*) FROM threads WHERE is_archived = 0',
            'posts' => 'SELECT COUNT(*) FROM posts WHERE is_deleted = 0',
            'open_reports' => "SELECT COUNT(*) FROM reports WHERE status = 'open'",
            'restricted_tokens' => "SELECT COUNT(*) FROM blocked_tokens WHERE expires_at IS NULL OR expires_at > datetime('now')",
            'media' => 'SELECT COUNT(*) FROM attachments',
        ];
        $stats = [];
        foreach ($queries as $key => $sql) {
            $stats[$key] = (int) $this->pdo->query($sql)->fetchColumn();
        }
        return $stats;
    }

    /** @return list<array<string, mixed>> */
    public function reports(string $status = 'open'): array
    {
        $status = in_array($status, ['open', 'resolved', 'dismissed'], true) ? $status : 'open';
        $statement = $this->pdo->prepare(
            'SELECT r.*, p.thread_id, p.body, p.subject, p.name, p.is_deleted, b.slug AS board_slug, ' .
            'a.username AS resolver_name FROM reports r JOIN posts p ON p.id = r.post_id ' .
            'JOIN boards b ON b.id = p.board_id LEFT JOIN admins a ON a.id = r.resolved_by ' .
            'WHERE r.status = :status ORDER BY r.created_at DESC LIMIT 250'
        );
        $statement->execute(['status' => $status]);
        return $statement->fetchAll();
    }

    /** @return list<array<string, mixed>> */
    public function posts(string $query = '', int $boardId = 0, string $state = 'visible'): array
    {
        $where = [];
        $parameters = [];
        if ($query !== '') {
            if (ctype_digit($query)) {
                $where[] = '(p.id = :post_id OR p.thread_id = :thread_id)';
                $parameters['post_id'] = (int) $query;
                $parameters['thread_id'] = (int) $query;
            } else {
                $where[] = '(p.body LIKE :query OR p.subject LIKE :query)';
                $parameters['query'] = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $query) . '%';
            }
        }
        if ($boardId > 0) {
            $where[] = 'p.board_id = :board';
            $parameters['board'] = $boardId;
        }
        $where[] = $state === 'deleted' ? 'p.is_deleted = 1' : 'p.is_deleted = 0';
        $sql = 'SELECT p.id AS post_id, p.thread_id, p.is_op, p.name, p.subject, p.body, p.created_at, p.is_deleted, ' .
            'p.poster_token_hash, b.slug AS board_slug, t.is_sticky, t.is_locked, t.is_archived, a.id AS attachment_id ' .
            'FROM posts p JOIN boards b ON b.id = p.board_id JOIN threads t ON t.id = p.thread_id ' .
            'LEFT JOIN attachments a ON a.post_id = p.id WHERE ' . implode(' AND ', $where) . ' ORDER BY p.id DESC LIMIT 250';
        $statement = $this->pdo->prepare($sql);
        $statement->execute($parameters);
        return $statement->fetchAll();
    }

    /** @return list<array<string, mixed>> */
    public function filters(): array
    {
        return $this->pdo->query(
            'SELECT f.*, a.username AS creator_name FROM word_filters f LEFT JOIN admins a ON a.id = f.created_by ORDER BY f.id DESC'
        )->fetchAll();
    }

    /** @return list<array<string, mixed>> */
    public function staff(): array
    {
        return $this->pdo->query(
            'SELECT id, username, role, is_active, created_at, last_login_at FROM admins ORDER BY username'
        )->fetchAll();
    }

    /** @return list<array<string, mixed>> */
    public function restrictions(): array
    {
        return $this->pdo->query(
            'SELECT r.*, a.username AS creator_name FROM blocked_tokens r LEFT JOIN admins a ON a.id = r.created_by ' .
            'ORDER BY r.created_at DESC LIMIT 250'
        )->fetchAll();
    }

    /** @return list<array<string, mixed>> */
    public function audit(int $limit = 500): array
    {
        $statement = $this->pdo->prepare(
            'SELECT l.*, a.username AS admin_name FROM audit_log l LEFT JOIN admins a ON a.id = l.admin_id ' .
            'ORDER BY l.id DESC LIMIT :limit'
        );
        $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
        $statement->execute();
        return $statement->fetchAll();
    }
}

