<?php

declare(strict_types=1);

namespace Chessboard\Repository;

use PDO;

final readonly class BoardRepository
{
    public function __construct(private PDO $pdo)
    {
    }

    /** @return list<array<string, mixed>> */
    public function boards(): array
    {
        return $this->pdo->query(
            'SELECT b.*, ' .
            '(SELECT COUNT(*) FROM threads t WHERE t.board_id = b.id AND t.is_archived = 0) AS thread_count, ' .
            '(SELECT COUNT(*) FROM posts p WHERE p.board_id = b.id AND p.is_deleted = 0) AS post_count ' .
            'FROM boards b ORDER BY b.sort_order, b.slug'
        )->fetchAll();
    }

    /** @return array<string, mixed>|null */
    public function board(string $slug): ?array
    {
        $statement = $this->pdo->prepare('SELECT * FROM boards WHERE slug = :slug');
        $statement->execute(['slug' => $slug]);
        return $statement->fetch() ?: null;
    }

    /** @return array{threads: list<array<string, mixed>>, total: int} */
    public function boardThreads(int $boardId, int $page, int $perPage, int $previewReplies): array
    {
        $count = $this->pdo->prepare('SELECT COUNT(*) FROM threads WHERE board_id = :board AND is_archived = 0');
        $count->execute(['board' => $boardId]);
        $total = (int) $count->fetchColumn();

        $statement = $this->pdo->prepare(
            'SELECT t.*, p.id AS post_id, p.name, p.is_sage, p.subject, p.body, p.fen, p.pgn, ' .
            'p.poster_token_hash, p.created_at AS post_created_at, p.is_deleted, ' . $this->attachmentColumns() . ' ' .
            'FROM threads t JOIN posts p ON p.thread_id = t.id AND p.is_op = 1 ' .
            'LEFT JOIN attachments a ON a.post_id = p.id ' .
            'WHERE t.board_id = :board AND t.is_archived = 0 ' .
            'ORDER BY t.is_sticky DESC, t.bumped_at DESC LIMIT :limit OFFSET :offset'
        );
        $statement->bindValue(':board', $boardId, PDO::PARAM_INT);
        $statement->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $statement->bindValue(':offset', ($page - 1) * $perPage, PDO::PARAM_INT);
        $statement->execute();
        $threads = $statement->fetchAll();

        $ids = array_map(static fn (array $thread): int => (int) $thread['id'], $threads);
        $previews = $this->replyPreviews($ids, $previewReplies);
        foreach ($threads as &$thread) {
            $thread['replies'] = $previews[(int) $thread['id']] ?? [];
            $thread['omitted'] = max(0, (int) $thread['reply_count'] - count($thread['replies']));
        }
        unset($thread);

        return ['threads' => $threads, 'total' => $total];
    }

    /** @return list<array<string, mixed>> */
    private function replyPreviews(array $threadIds, int $limit): array
    {
        if ($threadIds === [] || $limit < 1) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($threadIds), '?'));
        $statement = $this->pdo->prepare(
            'SELECT p.id AS post_id, p.thread_id, p.name, p.is_sage, p.subject, p.body, p.fen, p.pgn, ' .
            'p.poster_token_hash, p.created_at AS post_created_at, p.is_deleted, ' . $this->attachmentColumns() . ' ' .
            "FROM posts p LEFT JOIN attachments a ON a.post_id = p.id WHERE p.is_op = 0 AND p.thread_id IN ({$placeholders}) " .
            'ORDER BY p.thread_id, p.id DESC'
        );
        $statement->execute($threadIds);
        $grouped = [];
        foreach ($statement->fetchAll() as $post) {
            $threadId = (int) $post['thread_id'];
            if (count($grouped[$threadId] ?? []) < $limit) {
                $grouped[$threadId][] = $post;
            }
        }
        foreach ($grouped as &$posts) {
            $posts = array_reverse($posts);
        }
        return $grouped;
    }

    /** @return array<string, mixed>|null */
    public function thread(string $boardSlug, int $threadId): ?array
    {
        $statement = $this->pdo->prepare(
            'SELECT t.*, b.slug AS board_slug, b.name AS board_name, b.description AS board_description, ' .
            'b.rules AS board_rules, b.is_locked AS board_locked ' .
            'FROM threads t JOIN boards b ON b.id = t.board_id ' .
            'WHERE t.id = :thread AND b.slug = :slug'
        );
        $statement->execute(['thread' => $threadId, 'slug' => $boardSlug]);
        return $statement->fetch() ?: null;
    }

    /** @return list<array<string, mixed>> */
    public function threadPosts(int $threadId): array
    {
        $statement = $this->pdo->prepare(
            'SELECT p.id AS post_id, p.thread_id, p.is_op, p.name, p.is_sage, p.subject, p.body, p.fen, p.pgn, ' .
            'p.poster_token_hash, p.created_at AS post_created_at, p.is_deleted, p.deleted_reason, ' .
            $this->attachmentColumns() . ' FROM posts p LEFT JOIN attachments a ON a.post_id = p.id ' .
            'WHERE p.thread_id = :thread ORDER BY p.id'
        );
        $statement->execute(['thread' => $threadId]);
        return $statement->fetchAll();
    }

    /** @return list<array<string, mixed>> */
    public function catalog(int $boardId): array
    {
        $statement = $this->pdo->prepare(
            'SELECT t.*, p.id AS post_id, p.subject, p.body, p.fen, p.created_at AS post_created_at, ' .
            $this->attachmentColumns() . ' FROM threads t JOIN posts p ON p.thread_id = t.id AND p.is_op = 1 ' .
            'LEFT JOIN attachments a ON a.post_id = p.id WHERE t.board_id = :board AND t.is_archived = 0 ' .
            'ORDER BY t.is_sticky DESC, t.bumped_at DESC LIMIT 250'
        );
        $statement->execute(['board' => $boardId]);
        return $statement->fetchAll();
    }

    /** @return list<array<string, mixed>> */
    public function archive(int $boardId): array
    {
        $statement = $this->pdo->prepare(
            'SELECT t.*, p.id AS post_id, p.subject, p.body, p.created_at AS post_created_at ' .
            'FROM threads t JOIN posts p ON p.thread_id = t.id AND p.is_op = 1 ' .
            'WHERE t.board_id = :board AND t.is_archived = 1 ORDER BY t.bumped_at DESC LIMIT 500'
        );
        $statement->execute(['board' => $boardId]);
        return $statement->fetchAll();
    }

    /** @return list<array<string, mixed>> */
    public function recentThreads(int $limit = 12): array
    {
        $statement = $this->pdo->prepare(
            'SELECT t.*, b.slug AS board_slug, b.name AS board_name, p.id AS post_id, p.subject, p.body, p.fen, ' .
            'p.created_at AS post_created_at, ' . $this->attachmentColumns() . ' FROM threads t ' .
            'JOIN boards b ON b.id = t.board_id JOIN posts p ON p.thread_id = t.id AND p.is_op = 1 ' .
            'LEFT JOIN attachments a ON a.post_id = p.id WHERE t.is_archived = 0 ' .
            'ORDER BY t.bumped_at DESC LIMIT :limit'
        );
        $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
        $statement->execute();
        return $statement->fetchAll();
    }

    /** @return list<array<string, mixed>> */
    public function search(int $boardId, string $query, int $limit = 100): array
    {
        $statement = $this->pdo->prepare(
            'SELECT p.id AS post_id, p.thread_id, p.is_op, p.subject, p.name, p.body, p.created_at AS post_created_at, ' .
            't.is_archived FROM posts p JOIN threads t ON t.id = p.thread_id ' .
            'WHERE p.board_id = :board AND p.is_deleted = 0 AND (p.subject LIKE :query ESCAPE \'!\' OR p.body LIKE :query ESCAPE \'!\') ' .
            'ORDER BY p.id DESC LIMIT :limit'
        );
        $needle = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $query) . '%';
        $statement->bindValue(':board', $boardId, PDO::PARAM_INT);
        $statement->bindValue(':query', $needle);
        $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
        $statement->execute();
        return $statement->fetchAll();
    }

    /** @return array<string, mixed>|null */
    public function post(int $postId): ?array
    {
        $statement = $this->pdo->prepare(
            'SELECT p.*, b.slug AS board_slug, t.is_locked, t.is_archived FROM posts p ' .
            'JOIN boards b ON b.id = p.board_id JOIN threads t ON t.id = p.thread_id WHERE p.id = :id'
        );
        $statement->execute(['id' => $postId]);
        return $statement->fetch() ?: null;
    }

    private function attachmentColumns(): string
    {
        return 'a.id AS attachment_id, a.storage_name, a.thumbnail_name, a.original_name, ' .
            'a.mime_type, a.byte_size, a.width, a.height';
    }
}
