<?php

declare(strict_types=1);

namespace Chessboard;

use PDO;
use Throwable;

final class Database
{
    private PDO $pdo;

    public function __construct(private readonly Config $config)
    {
        $directory = dirname($config->databasePath);
        if (!is_dir($directory) && !mkdir($directory, 0770, true) && !is_dir($directory)) {
            throw new \RuntimeException('Unable to create the database directory.');
        }

        $this->pdo = new PDO('sqlite:' . $config->databasePath, options: [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
        ]);
        $this->pdo->exec('PRAGMA foreign_keys = ON');
        $this->pdo->exec('PRAGMA journal_mode = WAL');
        $this->pdo->exec('PRAGMA synchronous = NORMAL');
        $this->pdo->exec('PRAGMA busy_timeout = 5000');
        $this->pdo->exec('PRAGMA trusted_schema = OFF');
        $this->pdo->exec('PRAGMA temp_store = MEMORY');
    }

    public function pdo(): PDO
    {
        return $this->pdo;
    }

    public function migrate(): void
    {
        $this->pdo->exec(
            'CREATE TABLE IF NOT EXISTS schema_migrations (' .
            'version TEXT PRIMARY KEY, applied_at TEXT NOT NULL' .
            ')'
        );

        $directory = $this->config->basePath . DIRECTORY_SEPARATOR . 'database' . DIRECTORY_SEPARATOR . 'migrations';
        $files = glob($directory . DIRECTORY_SEPARATOR . '*.sql') ?: [];
        sort($files, SORT_STRING);

        $check = $this->pdo->prepare('SELECT 1 FROM schema_migrations WHERE version = :version');
        $record = $this->pdo->prepare(
            'INSERT INTO schema_migrations (version, applied_at) VALUES (:version, :applied_at)'
        );

        foreach ($files as $file) {
            $version = basename($file);
            $check->execute(['version' => $version]);
            if ($check->fetchColumn() !== false) {
                continue;
            }

            $sql = file_get_contents($file);
            if ($sql === false) {
                throw new \RuntimeException("Unable to read migration: {$version}");
            }

            $this->transaction(function () use ($sql, $record, $version): void {
                $this->pdo->exec($sql);
                $record->execute([
                    'version' => $version,
                    'applied_at' => gmdate('Y-m-d H:i:s'),
                ]);
            });
        }

        $this->pdo->exec('PRAGMA optimize');
    }

    public function transaction(callable $callback): mixed
    {
        $this->pdo->exec('BEGIN IMMEDIATE');
        try {
            $result = $callback();
            $this->pdo->commit();
            return $result;
        } catch (Throwable $exception) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $exception;
        }
    }
}

