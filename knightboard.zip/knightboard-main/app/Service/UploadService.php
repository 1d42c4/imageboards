<?php

declare(strict_types=1);

namespace Chessboard\Service;

use Chessboard\Config;
use PDO;

final readonly class UploadService
{
    private const ALLOWED = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
    ];

    public function __construct(private Config $config, private PDO $pdo)
    {
    }

    /** @param array<string, mixed>|null $file @return array<string, mixed>|null */
    public function prepare(?array $file, int $configuredLimit): ?array
    {
        if ($file === null || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if ((int) ($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            throw new \InvalidArgumentException('The image upload did not complete.');
        }

        $source = (string) ($file['tmp_name'] ?? '');
        if ($source === '' || !is_file($source) || (PHP_SAPI !== 'cli' && !is_uploaded_file($source))) {
            throw new \InvalidArgumentException('The uploaded image could not be verified.');
        }
        $size = (int) ($file['size'] ?? filesize($source));
        $limit = min($this->config->maxUploadBytes, max(1_048_576, $configuredLimit));
        if ($size < 1 || $size > $limit) {
            throw new \InvalidArgumentException('Images must be smaller than ' . number_format($limit / 1_048_576, 1) . ' MiB.');
        }

        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = (string) $finfo->file($source);
        $extension = self::ALLOWED[$mime] ?? null;
        if ($extension === null) {
            throw new \InvalidArgumentException('Only JPEG, PNG, GIF, and WebP images are allowed.');
        }

        $bytes = file_get_contents($source);
        $info = $bytes === false ? false : @getimagesizefromstring($bytes);
        if ($info === false) {
            throw new \InvalidArgumentException('The uploaded file is not a readable image.');
        }
        $width = (int) $info[0];
        $height = (int) $info[1];
        if ($width < 1 || $height < 1 || $width > 12_000 || $height > 12_000 || $width * $height > 40_000_000) {
            throw new \InvalidArgumentException('The image dimensions are too large.');
        }
        $image = @imagecreatefromstring($bytes);
        if ($image === false) {
            throw new \InvalidArgumentException('The uploaded file is not a readable image.');
        }

        $folder = gmdate('Y/m');
        $directory = $this->config->uploadPath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $folder);
        if (!is_dir($directory) && !mkdir($directory, 0770, true) && !is_dir($directory)) {
            throw new \RuntimeException('Unable to create the image storage directory.');
        }
        $key = bin2hex(random_bytes(20));
        $storageName = "{$folder}/{$key}.{$extension}";
        $thumbName = "{$folder}/{$key}_thumb.{$extension}";
        $destination = $this->path($storageName);
        $thumbDestination = $this->path($thumbName);

        try {
            $this->encode($image, $destination, $mime);
            $thumb = $this->thumbnail($image, $width, $height, 250);
            $this->encode($thumb, $thumbDestination, $mime);
        } catch (\Throwable $exception) {
            foreach ([$destination, $thumbDestination] as $partialPath) {
                if (is_file($partialPath)) {
                    unlink($partialPath);
                }
            }
            throw $exception;
        } finally {
            unset($thumb, $image);
        }

        $safeOriginal = preg_replace('/[\x00-\x1F\x7F]+/u', '', basename((string) ($file['name'] ?? 'image.' . $extension))) ?: 'image.' . $extension;
        $safeOriginal = mb_substr($safeOriginal, 0, 160);
        $encodedSize = (int) filesize($destination);

        return [
            'storage_name' => $storageName,
            'thumbnail_name' => $thumbName,
            'original_name' => $safeOriginal,
            'mime_type' => $mime,
            'byte_size' => $encodedSize,
            'width' => $width,
            'height' => $height,
            'sha256' => hash_file('sha256', $destination),
        ];
    }

    /** @param array<string, mixed> $upload */
    public function attach(int $postId, array $upload): void
    {
        $statement = $this->pdo->prepare(
            'INSERT INTO attachments (post_id, storage_name, thumbnail_name, original_name, mime_type, byte_size, width, height, sha256, created_at) ' .
            'VALUES (:post_id, :storage_name, :thumbnail_name, :original_name, :mime_type, :byte_size, :width, :height, :sha256, :created_at)'
        );
        $statement->execute($upload + ['post_id' => $postId, 'created_at' => gmdate('Y-m-d H:i:s')]);
    }

    /** @param array<string, mixed>|null $upload */
    public function discard(?array $upload): void
    {
        if ($upload === null) {
            return;
        }
        foreach (['storage_name', 'thumbnail_name'] as $key) {
            $path = $this->path((string) $upload[$key]);
            if (is_file($path)) {
                unlink($path);
            }
        }
    }

    public function removeForPost(int $postId): bool
    {
        $statement = $this->pdo->prepare(
            'SELECT storage_name, thumbnail_name FROM attachments WHERE post_id = :post'
        );
        $statement->execute(['post' => $postId]);
        $attachment = $statement->fetch();
        if (!$attachment) {
            return false;
        }
        $this->discard($attachment);
        $delete = $this->pdo->prepare('DELETE FROM attachments WHERE post_id = :post');
        $delete->execute(['post' => $postId]);
        return true;
    }

    /** @return array{path: string, mime: string}|null */
    public function locate(string $name): ?array
    {
        if (!preg_match('#^[0-9]{4}/[0-9]{2}/[a-f0-9]{40}(?:_thumb)?\.(?:jpg|png|gif|webp)$#', $name)) {
            return null;
        }
        $statement = $this->pdo->prepare(
            'SELECT mime_type FROM attachments WHERE storage_name = :name OR thumbnail_name = :name LIMIT 1'
        );
        $statement->execute(['name' => $name]);
        $mime = $statement->fetchColumn();
        $path = $this->path($name);
        return $mime !== false && is_file($path) ? ['path' => $path, 'mime' => (string) $mime] : null;
    }

    private function path(string $name): string
    {
        return $this->config->uploadPath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $name);
    }

    private function encode(\GdImage $image, string $path, string $mime): void
    {
        $success = match ($mime) {
            'image/jpeg' => imagejpeg($image, $path, 88),
            'image/png' => imagepng($image, $path, 6),
            'image/gif' => imagegif($image, $path),
            'image/webp' => imagewebp($image, $path, 86),
            default => false,
        };
        if (!$success) {
            throw new \RuntimeException('Unable to store the sanitized image.');
        }
    }

    private function thumbnail(\GdImage $source, int $width, int $height, int $max): \GdImage
    {
        $ratio = min(1, $max / max($width, $height));
        $targetWidth = max(1, (int) round($width * $ratio));
        $targetHeight = max(1, (int) round($height * $ratio));
        $thumb = imagecreatetruecolor($targetWidth, $targetHeight);
        imagealphablending($thumb, false);
        imagesavealpha($thumb, true);
        $transparent = imagecolorallocatealpha($thumb, 0, 0, 0, 127);
        imagefill($thumb, 0, 0, $transparent);
        imagecopyresampled($thumb, $source, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);
        return $thumb;
    }
}
