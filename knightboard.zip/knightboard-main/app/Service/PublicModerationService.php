<?php

declare(strict_types=1);

namespace Chessboard\Service;

use Chessboard\Database;
use Chessboard\Http\Request;
use Chessboard\Security;
use PDOException;

final readonly class PublicModerationService
{
    public function __construct(
        private Database $database,
        private Security $security,
        private UploadService $uploads,
    ) {
    }

    /** @return array{board_slug: string, thread_id: int} */
    public function deleteOwn(int $postId, Request $request): array
    {
        $this->requireCsrf($request);
        $password = $request->input('deletion_password');
        if ($password === '') {
            throw new \InvalidArgumentException('Enter the deletion password used when posting.');
        }

        return $this->database->transaction(function () use ($postId, $password): array {
            $pdo = $this->database->pdo();
            $statement = $pdo->prepare(
                'SELECT p.*, b.slug AS board_slug FROM posts p JOIN boards b ON b.id = p.board_id WHERE p.id = :id'
            );
            $statement->execute(['id' => $postId]);
            $post = $statement->fetch();
            if (!$post || (int) $post['is_deleted'] === 1) {
                throw new \InvalidArgumentException('That post is no longer available.');
            }
            if (!password_verify($password, (string) $post['delete_password_hash'])) {
                throw new \InvalidArgumentException('The deletion password is not correct.');
            }

            $hadAttachment = $this->uploads->removeForPost($postId);
            $delete = $pdo->prepare(
                "UPDATE posts SET name = '', subject = '', body = '', fen = '', pgn = '', " .
                "poster_token_hash = :redacted_token, delete_password_hash = '!', is_deleted = 1, " .
                "deleted_at = :deleted, deleted_reason = 'Deleted by poster' WHERE id = :id"
            );
            $delete->execute([
                'redacted_token' => hash('sha256', 'deleted-post:' . $postId),
                'deleted' => gmdate('Y-m-d H:i:s'),
                'id' => $postId,
            ]);
            if ($hadAttachment) {
                $counter = $pdo->prepare(
                    'UPDATE threads SET attachment_count = max(0, attachment_count - 1) WHERE id = :thread'
                );
                $counter->execute(['thread' => (int) $post['thread_id']]);
            }
            return ['board_slug' => (string) $post['board_slug'], 'thread_id' => (int) $post['thread_id']];
        });
    }

    /** @return array{board_slug: string, thread_id: int} */
    public function report(int $postId, Request $request): array
    {
        $this->requireCsrf($request);
        $category = $request->input('category');
        if (!in_array($category, ['spam', 'harassment', 'illegal', 'off-topic', 'other'], true)) {
            throw new \InvalidArgumentException('Choose a valid report category.');
        }
        $details = $request->input('details');
        if (mb_strlen($details) > 1000) {
            throw new \InvalidArgumentException('Report details must be at most 1000 characters.');
        }

        $pdo = $this->database->pdo();
        $post = $pdo->prepare(
            'SELECT p.thread_id, p.is_deleted, b.slug AS board_slug FROM posts p JOIN boards b ON b.id = p.board_id WHERE p.id = :id'
        );
        $post->execute(['id' => $postId]);
        $row = $post->fetch();
        if (!$row || (int) $row['is_deleted'] === 1) {
            throw new \InvalidArgumentException('That post is no longer available.');
        }

        try {
            $insert = $pdo->prepare(
                'INSERT INTO reports (post_id, reporter_token_hash, category, details, created_at) ' .
                'VALUES (:post, :reporter, :category, :details, :created)'
            );
            $insert->execute([
                'post' => $postId,
                'reporter' => $this->security->posterTokenHash(),
                'category' => $category,
                'details' => $details,
                'created' => gmdate('Y-m-d H:i:s'),
            ]);
        } catch (PDOException $exception) {
            if (str_contains($exception->getMessage(), 'UNIQUE constraint failed')) {
                throw new \InvalidArgumentException('You already have an open report for this post.');
            }
            throw $exception;
        }
        return ['board_slug' => (string) $row['board_slug'], 'thread_id' => (int) $row['thread_id']];
    }

    private function requireCsrf(Request $request): void
    {
        if (!$this->security->verifyCsrf($request->input('_token'))) {
            throw new \InvalidArgumentException('The form expired. Reload the page and try again.');
        }
    }
}

