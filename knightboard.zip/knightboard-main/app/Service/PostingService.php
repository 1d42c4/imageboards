<?php

declare(strict_types=1);

namespace Chessboard\Service;

use Chessboard\Database;
use Chessboard\Http\Request;
use Chessboard\Security;
use Chessboard\Settings;
use PDO;

final readonly class PostingService
{
    public function __construct(
        private Database $database,
        private Settings $settings,
        private Security $security,
        private UploadService $uploads,
    ) {
    }

    /** @param array<string, mixed> $board @return array{thread_id: int, post_id: int} */
    public function createThread(array $board, Request $request): array
    {
        if ((int) $board['is_locked'] === 1) {
            throw new \InvalidArgumentException('This board is read-only.');
        }
        $data = $this->validated($request, 'new:' . $board['slug'], true);
        $upload = $this->uploads->prepare($request->file('image'), $this->settings->int('max_upload_bytes', 8_388_608));
        if ($data['body'] === '' && $data['fen'] === '' && $data['pgn'] === '' && $upload === null) {
            throw new \InvalidArgumentException('A new thread needs a comment, image, FEN, or PGN.');
        }

        try {
            return $this->database->transaction(function () use ($board, $data, $upload): array {
                $pdo = $this->database->pdo();
                $tokenHash = $this->security->posterTokenHash();
                $this->assertPostingAllowed($pdo, $tokenHash);
                $now = gmdate('Y-m-d H:i:s');

                $thread = $pdo->prepare(
                    'INSERT INTO threads (board_id, created_at, bumped_at, attachment_count) VALUES (:board, :created, :bumped, :attachments)'
                );
                $thread->execute([
                    'board' => (int) $board['id'],
                    'created' => $now,
                    'bumped' => $now,
                    'attachments' => $upload === null ? 0 : 1,
                ]);
                $threadId = (int) $pdo->lastInsertId();
                $postId = $this->insertPost($pdo, $threadId, (int) $board['id'], true, $tokenHash, $data, $now);
                if ($upload !== null) {
                    $this->uploads->attach($postId, $upload);
                }
                $this->createFilterReport($pdo, $postId, $data['flagged']);
                return ['thread_id' => $threadId, 'post_id' => $postId];
            });
        } catch (\Throwable $exception) {
            $this->uploads->discard($upload);
            throw $exception;
        }
    }

    /** @param array<string, mixed> $thread @return int */
    public function reply(array $thread, Request $request): int
    {
        if ((int) $thread['board_locked'] === 1 || (int) $thread['is_locked'] === 1 || (int) $thread['is_archived'] === 1) {
            throw new \InvalidArgumentException('This thread is closed.');
        }
        $data = $this->validated($request, 'reply:' . $thread['id'], false);
        $upload = $this->uploads->prepare($request->file('image'), $this->settings->int('max_upload_bytes', 8_388_608));
        if ($data['body'] === '' && $data['fen'] === '' && $data['pgn'] === '' && $upload === null) {
            throw new \InvalidArgumentException('A reply needs a comment, image, FEN, or PGN.');
        }

        try {
            return $this->database->transaction(function () use ($thread, $data, $upload): int {
                $pdo = $this->database->pdo();
                $fresh = $pdo->prepare('SELECT * FROM threads WHERE id = :id');
                $fresh->execute(['id' => (int) $thread['id']]);
                $current = $fresh->fetch();
                if (!$current || (int) $current['is_locked'] === 1 || (int) $current['is_archived'] === 1) {
                    throw new \InvalidArgumentException('This thread is closed.');
                }
                $replyLimit = $this->settings->int('reply_limit', 500);
                if ((int) $current['reply_count'] >= $replyLimit) {
                    throw new \InvalidArgumentException('This thread has reached its reply limit.');
                }

                $tokenHash = $this->security->posterTokenHash();
                $this->assertPostingAllowed($pdo, $tokenHash);
                $now = gmdate('Y-m-d H:i:s');
                $postId = $this->insertPost($pdo, (int) $thread['id'], (int) $thread['board_id'], false, $tokenHash, $data, $now);
                if ($upload !== null) {
                    $this->uploads->attach($postId, $upload);
                }

                $bumpLimit = $this->settings->int('bump_limit', 300);
                $shouldBump = !$data['sage'] && (int) $current['reply_count'] < $bumpLimit;
                $update = $pdo->prepare(
                    'UPDATE threads SET reply_count = reply_count + 1, attachment_count = attachment_count + :attachment, ' .
                    'bumped_at = CASE WHEN :should_bump = 1 THEN :bumped ELSE bumped_at END, ' .
                    'is_locked = CASE WHEN reply_count + 1 >= :reply_limit THEN 1 ELSE is_locked END WHERE id = :id'
                );
                $update->bindValue(':attachment', $upload === null ? 0 : 1, PDO::PARAM_INT);
                $update->bindValue(':should_bump', $shouldBump ? 1 : 0, PDO::PARAM_INT);
                $update->bindValue(':bumped', $now);
                $update->bindValue(':reply_limit', $replyLimit, PDO::PARAM_INT);
                $update->bindValue(':id', (int) $thread['id'], PDO::PARAM_INT);
                $update->execute();
                $this->createFilterReport($pdo, $postId, $data['flagged']);
                return $postId;
            });
        } catch (\Throwable $exception) {
            $this->uploads->discard($upload);
            throw $exception;
        }
    }

    /** @return array{name: string, subject: string, body: string, fen: string, pgn: string, password: string, sage: bool, flagged: bool} */
    private function validated(Request $request, string $purpose, bool $isOp): array
    {
        if (!$this->security->verifyCsrf($request->input('_token'))) {
            throw new \InvalidArgumentException('The form expired. Reload the page and try again.');
        }
        if ($request->input('website') !== '') {
            throw new \InvalidArgumentException('The post could not be accepted.');
        }
        if (!$this->security->verifyFormStamp($request->input('_stamp'), $purpose)) {
            throw new \InvalidArgumentException('Please wait a moment after opening the form, then try again.');
        }

        $data = [
            'name' => $this->bounded($request->input('name'), 80, 'Name'),
            'subject' => $this->bounded($request->input('subject'), 120, 'Subject'),
            'body' => $this->bounded($request->input('body'), 20_000, 'Comment'),
            'fen' => $this->bounded($request->input('fen'), 120, 'FEN'),
            'pgn' => $this->bounded($request->input('pgn'), 20_000, 'PGN'),
            'password' => $request->input('deletion_password'),
            'sage' => !$isOp && $request->input('sage') === '1',
            'flagged' => false,
        ];
        if (!valid_fen($data['fen'])) {
            throw new \InvalidArgumentException('The FEN is not valid. Include all six FEN fields.');
        }
        if (strlen($data['password']) < 4 || strlen($data['password']) > 100) {
            throw new \InvalidArgumentException('The deletion password must be 4–100 characters.');
        }
        $this->applyFilters($data);
        return $data;
    }

    private function bounded(string $value, int $maximum, string $label): string
    {
        if (!mb_check_encoding($value, 'UTF-8')) {
            throw new \InvalidArgumentException("{$label} contains invalid text encoding.");
        }
        if (mb_strlen($value) > $maximum) {
            throw new \InvalidArgumentException("{$label} is longer than {$maximum} characters.");
        }
        return $value;
    }

    /** @param array{name: string, subject: string, body: string, fen: string, pgn: string, password: string, sage: bool, flagged: bool} $data */
    private function applyFilters(array &$data): void
    {
        $filters = $this->database->pdo()->query(
            'SELECT pattern, replacement, action FROM word_filters WHERE is_enabled = 1 ORDER BY id'
        )->fetchAll();
        foreach ($filters as $filter) {
            $pattern = (string) $filter['pattern'];
            $matched = false;
            foreach (['name', 'subject', 'body', 'pgn'] as $field) {
                if (mb_stripos($data[$field], $pattern) === false) {
                    continue;
                }
                $matched = true;
                if ($filter['action'] === 'replace') {
                    $data[$field] = str_ireplace($pattern, (string) $filter['replacement'], $data[$field]);
                }
            }
            if ($matched && $filter['action'] === 'reject') {
                throw new \InvalidArgumentException('The post contains a blocked phrase.');
            }
            if ($matched && $filter['action'] === 'flag') {
                $data['flagged'] = true;
            }
        }
    }

    private function assertPostingAllowed(PDO $pdo, string $tokenHash): void
    {
        $blocked = $pdo->prepare(
            "SELECT 1 FROM blocked_tokens WHERE token_hash = :token AND (expires_at IS NULL OR expires_at > datetime('now'))"
        );
        $blocked->execute(['token' => $tokenHash]);
        if ($blocked->fetchColumn() !== false) {
            throw new \InvalidArgumentException('Posting is temporarily unavailable for this browser.');
        }

        $cooldown = max(0, $this->settings->int('post_cooldown_seconds', 8));
        $recent = $pdo->prepare('SELECT 1 FROM posts WHERE poster_token_hash = :token AND created_at > :cutoff LIMIT 1');
        $recent->execute([
            'token' => $tokenHash,
            'cutoff' => gmdate('Y-m-d H:i:s', time() - $cooldown),
        ]);
        if ($recent->fetchColumn() !== false) {
            throw new \InvalidArgumentException("Please wait {$cooldown} seconds between posts.");
        }

        $window = intdiv(time(), 60) * 60;
        $this->hitBucket($pdo, 'poster:' . $tokenHash, $window, $this->settings->int('posts_per_minute', 6));
        $this->hitBucket($pdo, 'global', $window, $this->settings->int('global_posts_per_minute', 120));
        if (random_int(1, 100) === 1) {
            $cleanup = $pdo->prepare('DELETE FROM rate_limits WHERE updated_at < :cutoff');
            $cleanup->execute(['cutoff' => time() - 86_400]);
        }
    }

    private function hitBucket(PDO $pdo, string $key, int $window, int $limit): void
    {
        $statement = $pdo->prepare(
            'INSERT INTO rate_limits (bucket_key, window_started_at, hit_count, updated_at) VALUES (:key, :window, 1, :updated) ' .
            'ON CONFLICT(bucket_key, window_started_at) DO UPDATE SET hit_count = hit_count + 1, updated_at = excluded.updated_at ' .
            'RETURNING hit_count'
        );
        $statement->execute(['key' => $key, 'window' => $window, 'updated' => time()]);
        if ((int) $statement->fetchColumn() > max(1, $limit)) {
            throw new \InvalidArgumentException('The site is receiving posts too quickly. Please try again in a minute.');
        }
    }

    /** @param array{name: string, subject: string, body: string, fen: string, pgn: string, password: string, sage: bool, flagged: bool} $data */
    private function insertPost(PDO $pdo, int $threadId, int $boardId, bool $isOp, string $tokenHash, array $data, string $now): int
    {
        $statement = $pdo->prepare(
            'INSERT INTO posts (thread_id, board_id, is_op, name, is_sage, subject, body, fen, pgn, poster_token_hash, delete_password_hash, created_at) ' .
            'VALUES (:thread, :board, :is_op, :name, :sage, :subject, :body, :fen, :pgn, :token, :password, :created)'
        );
        $statement->execute([
            'thread' => $threadId,
            'board' => $boardId,
            'is_op' => $isOp ? 1 : 0,
            'name' => $data['name'],
            'sage' => $data['sage'] ? 1 : 0,
            'subject' => $data['subject'],
            'body' => $data['body'],
            'fen' => $data['fen'],
            'pgn' => $data['pgn'],
            'token' => $tokenHash,
            'password' => password_hash($data['password'], PASSWORD_ARGON2ID),
            'created' => $now,
        ]);
        return (int) $pdo->lastInsertId();
    }

    private function createFilterReport(PDO $pdo, int $postId, bool $flagged): void
    {
        if (!$flagged) {
            return;
        }
        $statement = $pdo->prepare(
            "INSERT INTO reports (post_id, reporter_token_hash, category, details, created_at) VALUES (:post, :reporter, 'other', :details, :created)"
        );
        $statement->execute([
            'post' => $postId,
            'reporter' => hash('sha256', 'content-filter'),
            'details' => 'Automatically flagged by a content filter.',
            'created' => gmdate('Y-m-d H:i:s'),
        ]);
    }
}
