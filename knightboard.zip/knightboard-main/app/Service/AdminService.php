<?php

declare(strict_types=1);

namespace Chessboard\Service;

use Chessboard\Database;
use Chessboard\Http\Request;
use Chessboard\Security;
use Chessboard\Settings;
use PDO;

final readonly class AdminService
{
    public function __construct(
        private Database $database,
        private Settings $settings,
        private Security $security,
        private UploadService $uploads,
    ) {
    }

    public function hasAdmins(): bool
    {
        return (int) $this->database->pdo()->query('SELECT COUNT(*) FROM admins')->fetchColumn() > 0;
    }

    /** @return array<string, mixed>|null */
    public function current(): ?array
    {
        $id = $this->security->adminId();
        if ($id === null) {
            return null;
        }
        $statement = $this->database->pdo()->prepare('SELECT id, username, role, is_active, created_at, last_login_at FROM admins WHERE id = :id');
        $statement->execute(['id' => $id]);
        $admin = $statement->fetch();
        if (!$admin || (int) $admin['is_active'] !== 1) {
            $this->security->logoutAdmin();
            return null;
        }
        return $admin;
    }

    public function setupOwner(Request $request): void
    {
        $this->requireCsrf($request);
        $username = $request->input('username');
        $password = $request->input('password');
        $confirmation = $request->input('password_confirmation');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,40}$/', $username)) {
            throw new \InvalidArgumentException('Use 3–40 letters, numbers, dots, underscores, or dashes for the username.');
        }
        if (strlen($password) < 12 || strlen($password) > 200) {
            throw new \InvalidArgumentException('The owner password must be 12–200 characters.');
        }
        if (!hash_equals($password, $confirmation)) {
            throw new \InvalidArgumentException('The password confirmation does not match.');
        }
        $id = $this->database->transaction(function () use ($username, $password): int {
            $pdo = $this->database->pdo();
            if ((int) $pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn() > 0) {
                throw new \InvalidArgumentException('Administrator setup is already complete.');
            }
            $statement = $pdo->prepare(
                "INSERT INTO admins (username, password_hash, role, created_at) VALUES (:username, :password, 'owner', :created)"
            );
            $statement->execute([
                'username' => $username,
                'password' => password_hash($password, PASSWORD_ARGON2ID),
                'created' => gmdate('Y-m-d H:i:s'),
            ]);
            return (int) $pdo->lastInsertId();
        });
        $this->security->loginAdmin($id);
        $this->audit($id, 'owner.created', 'admin', $id, ['username' => $username]);
    }

    public function login(Request $request): void
    {
        $this->requireCsrf($request);
        $username = mb_strtolower($request->input('username'));
        $password = $request->input('password');
        $this->checkLoginRate($username);

        $statement = $this->database->pdo()->prepare('SELECT * FROM admins WHERE username = :username AND is_active = 1');
        $statement->execute(['username' => $username]);
        $admin = $statement->fetch();
        if (!$admin || !password_verify($password, (string) $admin['password_hash'])) {
            password_verify($password, '$argon2id$v=19$m=65536,t=4,p=1$RHVtbXlTYWx0MTIzNDU2Nw$H2hYZXaDgHwpjWVgvJU6wlbOMSAtaHxjQQG9iQj/ArI');
            throw new \InvalidArgumentException('The username or password is not correct.');
        }
        if (password_needs_rehash((string) $admin['password_hash'], PASSWORD_ARGON2ID)) {
            $rehash = $this->database->pdo()->prepare('UPDATE admins SET password_hash = :hash WHERE id = :id');
            $rehash->execute(['hash' => password_hash($password, PASSWORD_ARGON2ID), 'id' => (int) $admin['id']]);
        }
        $update = $this->database->pdo()->prepare('UPDATE admins SET last_login_at = :time WHERE id = :id');
        $update->execute(['time' => gmdate('Y-m-d H:i:s'), 'id' => (int) $admin['id']]);
        $this->security->loginAdmin((int) $admin['id']);
        $this->audit((int) $admin['id'], 'admin.login', 'admin', (int) $admin['id']);
    }

    public function logout(Request $request): void
    {
        $this->requireCsrf($request);
        $admin = $this->current();
        if ($admin !== null) {
            $this->audit((int) $admin['id'], 'admin.logout', 'admin', (int) $admin['id']);
        }
        $this->security->logoutAdmin();
    }

    /** @param array<string, mixed> $admin */
    public function requireCapability(array $admin, string $capability): void
    {
        if (!role_allows((string) $admin['role'], $capability)) {
            throw new \InvalidArgumentException('Your role does not allow that action.');
        }
    }

    private function checkLoginRate(string $username): void
    {
        $pdo = $this->database->pdo();
        $window = intdiv(time(), 900) * 900;
        foreach (['login:global' => 30, 'login:' . hash('sha256', $username) => 8] as $key => $limit) {
            $statement = $pdo->prepare(
                'INSERT INTO rate_limits (bucket_key, window_started_at, hit_count, updated_at) VALUES (:key, :window, 1, :updated) ' .
                'ON CONFLICT(bucket_key, window_started_at) DO UPDATE SET hit_count = hit_count + 1, updated_at = excluded.updated_at RETURNING hit_count'
            );
            $statement->execute(['key' => $key, 'window' => $window, 'updated' => time()]);
            if ((int) $statement->fetchColumn() > $limit) {
                throw new \InvalidArgumentException('Too many sign-in attempts. Wait fifteen minutes and try again.');
            }
        }
    }

    private function requireCsrf(Request $request): void
    {
        if (!$this->security->verifyCsrf($request->input('_token'))) {
            throw new \InvalidArgumentException('The form expired. Reload the page and try again.');
        }
    }

    /** @param array<string, mixed> $details */
    private function audit(?int $adminId, string $action, string $targetType = '', ?int $targetId = null, array $details = []): void
    {
        $statement = $this->database->pdo()->prepare(
            'INSERT INTO audit_log (admin_id, action, target_type, target_id, details_json, created_at) ' .
            'VALUES (:admin, :action, :type, :target, :details, :created)'
        );
        $statement->execute([
            'admin' => $adminId,
            'action' => $action,
            'type' => $targetType,
            'target' => $targetId,
            'details' => json_encode($details, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'created' => gmdate('Y-m-d H:i:s'),
        ]);
    }

    /** @param array<string, mixed> $admin */
    public function moderatePost(array $admin, int $postId, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'moderate');
        $action = $request->input('action', 'delete');
        if (!in_array($action, ['delete', 'remove-media'], true)) {
            throw new \InvalidArgumentException('Unknown moderation action.');
        }
        $reason = mb_substr($request->input('reason', 'Removed by staff'), 0, 500);
        $this->database->transaction(function () use ($admin, $postId, $action, $reason): void {
            $pdo = $this->database->pdo();
            $find = $pdo->prepare('SELECT * FROM posts WHERE id = :id');
            $find->execute(['id' => $postId]);
            $post = $find->fetch();
            if (!$post) {
                throw new \InvalidArgumentException('Post not found.');
            }
            $hadAttachment = $this->uploads->removeForPost($postId);
            if ($hadAttachment) {
                $counter = $pdo->prepare('UPDATE threads SET attachment_count = max(0, attachment_count - 1) WHERE id = :thread');
                $counter->execute(['thread' => (int) $post['thread_id']]);
            }
            if ($action === 'delete') {
                $update = $pdo->prepare(
                    "UPDATE posts SET name = '', subject = '', body = '', fen = '', pgn = '', poster_token_hash = :redacted, " .
                    "delete_password_hash = '!', is_deleted = 1, deleted_at = :deleted, deleted_reason = :reason, moderated_by = :admin WHERE id = :id"
                );
                $update->execute([
                    'redacted' => hash('sha256', 'moderated-post:' . $postId),
                    'deleted' => gmdate('Y-m-d H:i:s'),
                    'reason' => $reason,
                    'admin' => (int) $admin['id'],
                    'id' => $postId,
                ]);
                $reports = $pdo->prepare(
                    "UPDATE reports SET status = 'resolved', resolved_at = :resolved, resolved_by = :admin, resolution_note = :note WHERE post_id = :post AND status = 'open'"
                );
                $reports->execute([
                    'resolved' => gmdate('Y-m-d H:i:s'),
                    'admin' => (int) $admin['id'],
                    'note' => 'Post removed: ' . $reason,
                    'post' => $postId,
                ]);
            }
            $this->audit((int) $admin['id'], 'post.' . $action, 'post', $postId, ['reason' => $reason]);
        });
    }

    /** @param array<string, mixed> $admin */
    public function toggleThread(array $admin, int $threadId, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'moderate');
        $field = $request->input('field');
        if (!in_array($field, ['is_sticky', 'is_locked', 'is_archived'], true)) {
            throw new \InvalidArgumentException('Unknown thread control.');
        }
        $statement = $this->database->pdo()->prepare("UPDATE threads SET {$field} = CASE {$field} WHEN 1 THEN 0 ELSE 1 END WHERE id = :id RETURNING {$field}");
        $statement->execute(['id' => $threadId]);
        $value = $statement->fetchColumn();
        if ($value === false) {
            throw new \InvalidArgumentException('Thread not found.');
        }
        $this->audit((int) $admin['id'], 'thread.toggle', 'thread', $threadId, ['field' => $field, 'value' => (int) $value]);
    }

    /** @param array<string, mixed> $admin */
    public function resolveReport(array $admin, int $reportId, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'moderate');
        $status = $request->input('status');
        if (!in_array($status, ['resolved', 'dismissed'], true)) {
            throw new \InvalidArgumentException('Choose resolved or dismissed.');
        }
        $note = mb_substr($request->input('note'), 0, 1000);
        $statement = $this->database->pdo()->prepare(
            'UPDATE reports SET status = :status, resolved_at = :resolved, resolved_by = :admin, resolution_note = :note ' .
            "WHERE id = :id AND status = 'open'"
        );
        $statement->execute([
            'status' => $status,
            'resolved' => gmdate('Y-m-d H:i:s'),
            'admin' => (int) $admin['id'],
            'note' => $note,
            'id' => $reportId,
        ]);
        if ($statement->rowCount() === 0) {
            throw new \InvalidArgumentException('That report is already closed or missing.');
        }
        $this->audit((int) $admin['id'], 'report.' . $status, 'report', $reportId, ['note' => $note]);
    }

    /** @param array<string, mixed> $admin */
    public function blockPostAuthor(array $admin, int $postId, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'moderate');
        $days = max(1, min(365, (int) $request->input('days', '7')));
        $reason = mb_substr($request->input('reason', 'Repeated rule violations'), 0, 500);
        if ($reason === '') {
            throw new \InvalidArgumentException('A restriction reason is required.');
        }
        $find = $this->database->pdo()->prepare('SELECT poster_token_hash, is_deleted FROM posts WHERE id = :id');
        $find->execute(['id' => $postId]);
        $post = $find->fetch();
        if (!$post || (int) $post['is_deleted'] === 1) {
            throw new \InvalidArgumentException('The anonymous token for that post is no longer retained.');
        }
        $statement = $this->database->pdo()->prepare(
            'INSERT INTO blocked_tokens (token_hash, reason, expires_at, created_at, created_by) ' .
            'VALUES (:token, :reason, :expires, :created, :admin) ' .
            'ON CONFLICT(token_hash) DO UPDATE SET reason = excluded.reason, expires_at = excluded.expires_at, created_by = excluded.created_by'
        );
        $statement->execute([
            'token' => (string) $post['poster_token_hash'],
            'reason' => $reason,
            'expires' => gmdate('Y-m-d H:i:s', time() + ($days * 86_400)),
            'created' => gmdate('Y-m-d H:i:s'),
            'admin' => (int) $admin['id'],
        ]);
        $this->audit((int) $admin['id'], 'poster.restrict', 'post', $postId, ['days' => $days, 'reason' => $reason]);
    }

    /** @param array<string, mixed> $admin */
    public function saveBoard(array $admin, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'boards');
        $id = (int) $request->input('id', '0');
        $slug = mb_strtolower($request->input('slug'));
        $name = $request->input('name');
        $description = $request->input('description');
        $rules = $request->input('rules');
        if (!preg_match('/^[a-z0-9]{1,12}$/', $slug)) {
            throw new \InvalidArgumentException('Board slugs use 1–12 lowercase letters or numbers.');
        }
        if ($name === '' || mb_strlen($name) > 80 || mb_strlen($description) > 500 || mb_strlen($rules) > 5000) {
            throw new \InvalidArgumentException('Check the board name, description, and rules lengths.');
        }
        $values = [
            'slug' => $slug,
            'name' => $name,
            'description' => $description,
            'rules' => $rules,
            'sort_order' => (int) $request->input('sort_order', '0'),
            'is_locked' => $request->input('is_locked') === '1' ? 1 : 0,
        ];
        if ($id > 0) {
            $statement = $this->database->pdo()->prepare(
                'UPDATE boards SET slug = :slug, name = :name, description = :description, rules = :rules, ' .
                'sort_order = :sort_order, is_locked = :is_locked WHERE id = :id'
            );
            $statement->execute($values + ['id' => $id]);
            if ($statement->rowCount() === 0) {
                $exists = $this->database->pdo()->prepare('SELECT 1 FROM boards WHERE id = :id');
                $exists->execute(['id' => $id]);
                if ($exists->fetchColumn() === false) {
                    throw new \InvalidArgumentException('Board not found.');
                }
            }
            $boardId = $id;
            $action = 'board.updated';
        } else {
            $statement = $this->database->pdo()->prepare(
                'INSERT INTO boards (slug, name, description, rules, sort_order, is_locked, created_at) ' .
                'VALUES (:slug, :name, :description, :rules, :sort_order, :is_locked, :created)'
            );
            $statement->execute($values + ['created' => gmdate('Y-m-d H:i:s')]);
            $boardId = (int) $this->database->pdo()->lastInsertId();
            $action = 'board.created';
        }
        $this->audit((int) $admin['id'], $action, 'board', $boardId, ['slug' => $slug]);
    }

    /** @param array<string, mixed> $admin */
    public function deleteBoard(array $admin, int $boardId, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'boards');
        $count = $this->database->pdo()->prepare('SELECT COUNT(*) FROM threads WHERE board_id = :id');
        $count->execute(['id' => $boardId]);
        if ((int) $count->fetchColumn() > 0) {
            throw new \InvalidArgumentException('Archive or remove every thread before deleting a board.');
        }
        $statement = $this->database->pdo()->prepare('DELETE FROM boards WHERE id = :id');
        $statement->execute(['id' => $boardId]);
        if ($statement->rowCount() === 0) {
            throw new \InvalidArgumentException('Board not found.');
        }
        $this->audit((int) $admin['id'], 'board.deleted', 'board', $boardId);
    }

    /** @param array<string, mixed> $admin */
    public function saveSettings(array $admin, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'settings');
        $values = [
            'site_name' => mb_substr($request->input('site_name'), 0, 80),
            'tagline' => mb_substr($request->input('tagline'), 0, 160),
            'default_name' => mb_substr($request->input('default_name', 'Anonymous'), 0, 80),
            'news_text' => mb_substr($request->input('news_text'), 0, 5000),
            'rules_text' => mb_substr($request->input('rules_text'), 0, 10000),
            'registration_note' => mb_substr($request->input('registration_note'), 0, 2000),
            'threads_per_page' => (string) max(1, min(50, (int) $request->input('threads_per_page', '10'))),
            'preview_replies' => (string) max(0, min(10, (int) $request->input('preview_replies', '3'))),
            'reply_limit' => (string) max(50, min(2000, (int) $request->input('reply_limit', '500'))),
            'bump_limit' => (string) max(25, min(1000, (int) $request->input('bump_limit', '300'))),
            'post_cooldown_seconds' => (string) max(0, min(3600, (int) $request->input('post_cooldown_seconds', '8'))),
            'posts_per_minute' => (string) max(1, min(120, (int) $request->input('posts_per_minute', '6'))),
            'global_posts_per_minute' => (string) max(10, min(5000, (int) $request->input('global_posts_per_minute', '120'))),
            'max_upload_bytes' => (string) max(1_048_576, min(25_165_824, (int) $request->input('max_upload_bytes', '8388608'))),
        ];
        if ($values['site_name'] === '' || $values['default_name'] === '') {
            throw new \InvalidArgumentException('Site name and anonymous name are required.');
        }
        $this->settings->update($values);
        $this->audit((int) $admin['id'], 'settings.updated', 'settings');
    }

    /** @param array<string, mixed> $admin */
    public function addFilter(array $admin, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'settings');
        $pattern = $request->input('pattern');
        $replacement = $request->input('replacement');
        $action = $request->input('action');
        if ($pattern === '' || mb_strlen($pattern) > 200 || mb_strlen($replacement) > 200) {
            throw new \InvalidArgumentException('Filter patterns are required and limited to 200 characters.');
        }
        if (!in_array($action, ['reject', 'replace', 'flag'], true)) {
            throw new \InvalidArgumentException('Choose reject, replace, or flag.');
        }
        $statement = $this->database->pdo()->prepare(
            'INSERT INTO word_filters (pattern, replacement, action, created_at, created_by) ' .
            'VALUES (:pattern, :replacement, :action, :created, :admin)'
        );
        $statement->execute([
            'pattern' => $pattern,
            'replacement' => $replacement,
            'action' => $action,
            'created' => gmdate('Y-m-d H:i:s'),
            'admin' => (int) $admin['id'],
        ]);
        $id = (int) $this->database->pdo()->lastInsertId();
        $this->audit((int) $admin['id'], 'filter.created', 'filter', $id, ['action' => $action]);
    }

    /** @param array<string, mixed> $admin */
    public function changeFilter(array $admin, int $filterId, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'settings');
        $action = $request->input('operation');
        if ($action === 'delete') {
            $statement = $this->database->pdo()->prepare('DELETE FROM word_filters WHERE id = :id');
            $auditAction = 'filter.deleted';
        } elseif ($action === 'toggle') {
            $statement = $this->database->pdo()->prepare(
                'UPDATE word_filters SET is_enabled = CASE is_enabled WHEN 1 THEN 0 ELSE 1 END WHERE id = :id'
            );
            $auditAction = 'filter.toggled';
        } else {
            throw new \InvalidArgumentException('Unknown filter action.');
        }
        $statement->execute(['id' => $filterId]);
        if ($statement->rowCount() === 0) {
            throw new \InvalidArgumentException('Filter not found.');
        }
        $this->audit((int) $admin['id'], $auditAction, 'filter', $filterId);
    }

    /** @param array<string, mixed> $admin */
    public function createStaff(array $admin, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'staff');
        $username = $request->input('username');
        $password = $request->input('password');
        $role = $request->input('role');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,40}$/', $username)) {
            throw new \InvalidArgumentException('Use 3–40 letters, numbers, dots, underscores, or dashes for the username.');
        }
        if (strlen($password) < 12 || strlen($password) > 200) {
            throw new \InvalidArgumentException('Staff passwords must be 12–200 characters.');
        }
        if (!in_array($role, ['owner', 'administrator', 'moderator'], true)) {
            throw new \InvalidArgumentException('Choose a valid role.');
        }
        $statement = $this->database->pdo()->prepare(
            'INSERT INTO admins (username, password_hash, role, created_at) VALUES (:username, :password, :role, :created)'
        );
        $statement->execute([
            'username' => $username,
            'password' => password_hash($password, PASSWORD_ARGON2ID),
            'role' => $role,
            'created' => gmdate('Y-m-d H:i:s'),
        ]);
        $id = (int) $this->database->pdo()->lastInsertId();
        $this->audit((int) $admin['id'], 'staff.created', 'admin', $id, ['username' => $username, 'role' => $role]);
    }

    /** @param array<string, mixed> $admin */
    public function changeStaff(array $admin, int $staffId, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'staff');
        if ($staffId === (int) $admin['id'] && $request->input('operation') === 'toggle') {
            throw new \InvalidArgumentException('You cannot disable your own account.');
        }
        $operation = $request->input('operation');
        if ($operation === 'toggle') {
            $statement = $this->database->pdo()->prepare(
                'UPDATE admins SET is_active = CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id = :id'
            );
            $statement->execute(['id' => $staffId]);
            $details = [];
        } elseif ($operation === 'password') {
            $password = $request->input('password');
            if (strlen($password) < 12 || strlen($password) > 200) {
                throw new \InvalidArgumentException('Staff passwords must be 12–200 characters.');
            }
            $statement = $this->database->pdo()->prepare('UPDATE admins SET password_hash = :password WHERE id = :id');
            $statement->execute(['password' => password_hash($password, PASSWORD_ARGON2ID), 'id' => $staffId]);
            $details = ['password_reset' => true];
        } else {
            throw new \InvalidArgumentException('Unknown staff action.');
        }
        if ($statement->rowCount() === 0) {
            throw new \InvalidArgumentException('Staff account not found.');
        }
        $this->audit((int) $admin['id'], 'staff.' . $operation, 'admin', $staffId, $details);
    }

    /** @param array<string, mixed> $admin */
    public function removeRestriction(array $admin, int $restrictionId, Request $request): void
    {
        $this->requireCsrf($request);
        $this->requireCapability($admin, 'moderate');
        $statement = $this->database->pdo()->prepare('DELETE FROM blocked_tokens WHERE id = :id');
        $statement->execute(['id' => $restrictionId]);
        if ($statement->rowCount() === 0) {
            throw new \InvalidArgumentException('Restriction not found.');
        }
        $this->audit((int) $admin['id'], 'poster.restriction_lifted', 'restriction', $restrictionId);
    }
}
