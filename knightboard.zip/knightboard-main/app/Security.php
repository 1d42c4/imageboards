<?php

declare(strict_types=1);

namespace Chessboard;

final class Security
{
    private const POSTER_COOKIE = 'knightboard_poster';

    public function __construct(private readonly Config $config)
    {
    }

    public function startSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', 'Lax');
        session_save_path($this->config->sessionPath);
        session_name('knightboard_session');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $this->isHttps(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    public function posterTokenHash(): string
    {
        $token = $_COOKIE[self::POSTER_COOKIE] ?? '';
        if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/', $token)) {
            $token = bin2hex(random_bytes(32));
            setcookie(self::POSTER_COOKIE, $token, [
                'expires' => time() + 31_536_000,
                'path' => '/',
                'secure' => $this->isHttps(),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            $_COOKIE[self::POSTER_COOKIE] = $token;
        }

        return hash_hmac('sha256', 'poster:' . $token, $this->config->appKey);
    }

    public function csrfToken(): string
    {
        if (!isset($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf'];
    }

    public function verifyCsrf(string $token): bool
    {
        return $token !== '' && hash_equals($this->csrfToken(), $token);
    }

    public function formStamp(string $purpose): string
    {
        $timestamp = (string) time();
        $signature = hash_hmac('sha256', "form:{$purpose}:{$timestamp}:" . $this->csrfToken(), $this->config->appKey);
        return $timestamp . '.' . $signature;
    }

    public function verifyFormStamp(string $stamp, string $purpose, int $minimumAge = 1): bool
    {
        [$timestamp, $signature] = array_pad(explode('.', $stamp, 2), 2, '');
        if (!ctype_digit($timestamp)) {
            return false;
        }
        $age = time() - (int) $timestamp;
        if ($age < $minimumAge || $age > 7200) {
            return false;
        }
        $expected = hash_hmac('sha256', "form:{$purpose}:{$timestamp}:" . $this->csrfToken(), $this->config->appKey);
        return hash_equals($expected, $signature);
    }

    public function flash(string $type, string $message): void
    {
        $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
    }

    /** @return list<array{type: string, message: string}> */
    public function consumeFlash(): array
    {
        $messages = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return is_array($messages) ? $messages : [];
    }

    public function loginAdmin(int $id): void
    {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $id;
        $_SESSION['admin_seen_at'] = time();
        $_SESSION['admin_logged_at'] = time();
        unset($_SESSION['csrf']);
    }

    public function logoutAdmin(): void
    {
        unset($_SESSION['admin_id'], $_SESSION['admin_seen_at'], $_SESSION['admin_logged_at']);
        unset($_SESSION['csrf']);
        session_regenerate_id(true);
    }

    public function adminId(): ?int
    {
        $id = $_SESSION['admin_id'] ?? null;
        $seen = $_SESSION['admin_seen_at'] ?? 0;
        $logged = $_SESSION['admin_logged_at'] ?? 0;
        if (!is_int($id)) {
            return null;
        }
        if (!is_int($seen) || !is_int($logged) || time() - $seen > 3600 || time() - $logged > 43_200) {
            $this->logoutAdmin();
            return null;
        }
        $_SESSION['admin_seen_at'] = time();
        return $id;
    }

    private function isHttps(): bool
    {
        return isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== '' && $_SERVER['HTTPS'] !== 'off';
    }
}
