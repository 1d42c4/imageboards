<?php

declare(strict_types=1);

namespace Chessboard;

use PDO;

final class Settings
{
    /** @var array<string, string>|null */
    private ?array $values = null;

    public function __construct(private readonly PDO $pdo)
    {
    }

    /** @return array<string, string> */
    public function all(): array
    {
        if ($this->values === null) {
            $this->values = [];
            $statement = $this->pdo->query('SELECT key, value FROM settings ORDER BY key');
            foreach ($statement->fetchAll() as $row) {
                $this->values[(string) $row['key']] = (string) $row['value'];
            }
        }
        return $this->values;
    }

    public function get(string $key, string $default = ''): string
    {
        return $this->all()[$key] ?? $default;
    }

    public function int(string $key, int $default): int
    {
        $value = filter_var($this->get($key), FILTER_VALIDATE_INT);
        return $value === false ? $default : (int) $value;
    }

    /** @param array<string, string> $values */
    public function update(array $values): void
    {
        $statement = $this->pdo->prepare(
            'INSERT INTO settings (key, value, updated_at) VALUES (:key, :value, :updated_at) ' .
            'ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at'
        );
        foreach ($values as $key => $value) {
            $statement->execute([
                'key' => $key,
                'value' => $value,
                'updated_at' => gmdate('Y-m-d H:i:s'),
            ]);
        }
        $this->values = null;
    }
}

