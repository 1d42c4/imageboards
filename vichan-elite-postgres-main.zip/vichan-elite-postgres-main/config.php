<?php

declare(strict_types=1);

return [
    'app_name' => 'Vichan Elite',
    'db_host' => '127.0.0.1',
    'db_port' => 5432,
    'db_name' => 'vichan_elite',
    'db_user' => 'vichan_elite',
    'db_password' => '',
    'db_sslmode' => 'prefer',
    'site_key' => '64c2176bf25eaaf9e370c27edbd8d484670f8e476287d05cdfd3b7cb760b5682',
    'base_url' => 'http://127.0.0.1:8080',
    'threads_per_page' => 10,
    'replies_preview' => 5,
    'max_body' => 20000,
    'max_upload_bytes' => 8 * 1024 * 1024,
    'force_image_for_threads' => false,
];
