<?php

declare(strict_types=1);

use VichanNative\Application;
use VichanNative\Config\AppConfig;

if (PHP_VERSION_ID < 80508 || PHP_VERSION_ID >= 80600) {
    http_response_code(500);
    exit('This application requires PHP 8.5.8 or a newer PHP 8.5 patch release.');
}

const VICHAN_NATIVE_ROOT = __DIR__;

spl_autoload_register(static function (string $class): void {
    $prefix = 'VichanNative\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $path = VICHAN_NATIVE_ROOT . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR
        . str_replace('\\', DIRECTORY_SEPARATOR, $relative) . '.php';
    if (is_file($path)) {
        require $path;
    }
});

set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

date_default_timezone_set('UTC');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Strict');

$config = AppConfig::load(VICHAN_NATIVE_ROOT);
session_name('vichan_elite_public');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => !$config->allowInsecureLocal,
    'httponly' => true,
    'samesite' => 'Strict',
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

return new Application($config);
