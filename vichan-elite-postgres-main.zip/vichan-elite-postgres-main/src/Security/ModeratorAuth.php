<?php

declare(strict_types=1);

namespace VichanNative\Security;

use VichanNative\Config\AppConfig;
use VichanNative\Domain\Moderator;
use VichanNative\Http\Request;
use VichanNative\Repository\ModeratorRepository;

final readonly class ModeratorAuth
{
    private const COOKIE = 'vichan_elite_mod';

    public function __construct(
        private ModeratorRepository $moderators,
        private RateLimiter $rateLimiter,
        private Csrf $csrf,
        private AppConfig $config,
    ) {
    }

    public function current(Request $request): ?Moderator
    {
        $token = (string) ($request->cookies[self::COOKIE] ?? '');
        if (!preg_match('/^[a-f0-9]{64}$/D', $token)) {
            return null;
        }
        return $this->moderators->moderatorForSession(hash('sha256', $token, true));
    }

    public function login(Request $request, string $username, #[\SensitiveParameter] string $password): ?Moderator
    {
        $this->ensureSecureConnection($request);
        $this->rateLimiter->consume($this->rateLimiter->sessionBucket('mod-login'), 8, 900);
        $row = $this->moderators->credentials($username);
        if ($row === null || !password_verify($password, (string) $row['password_hash'])) {
            password_verify($password, '$argon2id$v=19$m=65536,t=4,p=1$VmljaGFuTmF0aXZlU2FsdA$hVyp6XvhzKFIgPUCJNZWJ4rYH5HDrh8v0K1iS2vVqTM');
            return null;
        }
        if (password_needs_rehash((string) $row['password_hash'], PASSWORD_ARGON2ID)) {
            $this->moderators->changePassword((int) $row['id'], $password);
        }
        session_regenerate_id(true);
        $this->csrf->rotate();
        $token = bin2hex(random_bytes(32));
        $this->moderators->createSession((int) $row['id'], hash('sha256', $token, true), time() + 43200);
        setcookie(self::COOKIE, $token, [
            'expires' => time() + 43200,
            'path' => '/',
            'secure' => !$this->config->allowInsecureLocal,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        return $this->moderators->find((int) $row['id']);
    }

    public function logout(Request $request): void
    {
        $token = (string) ($request->cookies[self::COOKIE] ?? '');
        if (preg_match('/^[a-f0-9]{64}$/D', $token)) {
            $this->moderators->deleteSession(hash('sha256', $token, true));
        }
        setcookie(self::COOKIE, '', [
            'expires' => 1,
            'path' => '/',
            'secure' => !$this->config->allowInsecureLocal,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_regenerate_id(true);
        $this->csrf->rotate();
    }

    private function ensureSecureConnection(Request $request): void
    {
        if ($this->config->allowInsecureLocal) {
            $host = strtolower((string) ($request->server['HTTP_HOST'] ?? ''));
            if (preg_match('/^(?:127\.0\.0\.1|localhost)(?::\d+)?$/D', $host)) {
                return;
            }
        }
        if (($request->server['HTTPS'] ?? '') !== 'on') {
            throw new \DomainException('Moderator login requires HTTPS.');
        }
    }
}
