<?php

declare(strict_types=1);

namespace VichanNative\Security;

final class Csrf
{
    public function token(): string
    {
        if (!isset($_SESSION['csrf']) || !is_string($_SESSION['csrf']) || strlen($_SESSION['csrf']) !== 64) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf'];
    }

    public function verify(string $submitted): bool
    {
        return $submitted !== '' && hash_equals($this->token(), $submitted);
    }

    public function rotate(): void
    {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
}
