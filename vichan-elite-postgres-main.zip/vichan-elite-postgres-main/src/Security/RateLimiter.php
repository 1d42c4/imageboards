<?php

declare(strict_types=1);

namespace VichanNative\Security;

use PDO;
use VichanNative\Config\AppConfig;
use VichanNative\Database;

final readonly class RateLimiter
{
    public function __construct(
        private Database $database,
        private AppConfig $config,
    ) {
    }

    public function consume(string $bucket, int $limit, int $windowSeconds): void
    {
        $key = hash_hmac('sha256', $bucket, $this->config->siteKey, true);
        (void) $this->database->transaction(function (PDO $pdo) use ($key, $limit, $windowSeconds): bool {
            $now = time();
            $query = $pdo->prepare(
                'INSERT INTO rate_limits (bucket_key, attempts, window_started_at, expires_at)
                 VALUES (:key, 1, :started, :expires)
                 ON CONFLICT (bucket_key) DO UPDATE SET
                    attempts = CASE
                        WHEN rate_limits.expires_at <= EXCLUDED.window_started_at THEN 1
                        ELSE rate_limits.attempts + 1
                    END,
                    window_started_at = CASE
                        WHEN rate_limits.expires_at <= EXCLUDED.window_started_at
                            THEN EXCLUDED.window_started_at
                        ELSE rate_limits.window_started_at
                    END,
                    expires_at = CASE
                        WHEN rate_limits.expires_at <= EXCLUDED.window_started_at THEN EXCLUDED.expires_at
                        ELSE rate_limits.expires_at
                    END
                 RETURNING attempts'
            );
            $query->bindValue('key', $key, PDO::PARAM_LOB);
            $query->bindValue('started', $now, PDO::PARAM_INT);
            $query->bindValue('expires', $now + $windowSeconds, PDO::PARAM_INT);
            $query->execute();
            if ((int) $query->fetchColumn() > $limit) {
                throw new \DomainException('Please wait before trying that again.');
            }
            return true;
        });
        if (random_int(1, 100) === 1) {
            $cleanup = $this->database->pdo()->prepare('DELETE FROM rate_limits WHERE expires_at < :now');
            $cleanup->execute(['now' => time()]);
        }
    }

    public function sessionBucket(string $purpose): string
    {
        $sessionKey = hash_hmac('sha256', session_id(), $this->config->siteKey);
        return "session:{$purpose}:{$sessionKey}";
    }

    public function contentBucket(string $purpose, string $content): string
    {
        return "content:{$purpose}:" . hash_hmac('sha256', $content, $this->config->siteKey);
    }
}
