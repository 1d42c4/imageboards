<?php

declare(strict_types=1);

namespace VichanNative\Security;

use VichanNative\Config\AppConfig;
use VichanNative\Domain\Board;

final readonly class PublicFormToken
{
    public function __construct(private AppConfig $config)
    {
    }

    public function token(Board $board, ?int $threadId): string
    {
        return hash_hmac('sha256', $this->scope($board, $threadId), $this->config->siteKey);
    }

    public function verify(string $submitted, Board $board, ?int $threadId): bool
    {
        return strlen($submitted) === 64
            && hash_equals($this->token($board, $threadId), $submitted);
    }

    private function scope(Board $board, ?int $threadId): string
    {
        return "public-post-form\0" . $board->uri . "\0" . ($threadId ?? 0);
    }
}
