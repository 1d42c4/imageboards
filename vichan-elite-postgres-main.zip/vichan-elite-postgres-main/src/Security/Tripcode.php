<?php

declare(strict_types=1);

namespace VichanNative\Security;

use Normalizer;
use VichanNative\Config\AppConfig;
use VichanNative\Domain\PostingIdentity;

final readonly class Tripcode
{
    public function __construct(private AppConfig $config)
    {
    }

    public function derive(#[\SensitiveParameter] string $submittedName): PostingIdentity
    {
        $submittedName = $submittedName
            |> trim(...)
            |> $this->normalizeName(...);

        if (!preg_match('/^([^#]+)?(##|#)(.+)$/s', $submittedName, $match)) {
            return new PostingIdentity($this->publicName($submittedName), '');
        }
        $name = $this->publicName((string) ($match[1] ?? ''));
        $secret = (string) $match[3];
        $secure = $match[2] === '##';
        $minimum = $secure ? 16 : 8;
        if (mb_strlen($secret) < $minimum || mb_strlen($secret) > 160) {
            throw new \DomainException(sprintf(
                'A %s trip secret must contain between %d and 160 characters.',
                $secure ? 'secure' : 'standard',
                $minimum,
            ));
        }
        return $secure
            ? new PostingIdentity($name, $this->digest($secret, 'secure', '!!', 13))
            : new PostingIdentity($name, $this->digest($secret, 'standard', '!', 13));
    }

    private function normalizeName(string $name): string
    {
        return Normalizer::normalize($name, Normalizer::FORM_KC) ?: $name;
    }

    private function publicName(string $name): string
    {
        $name = $name === '' ? 'Anonymous' : $name;
        if (mb_strlen($name) > 35) {
            throw new \DomainException('The display name is too long.');
        }
        return $name;
    }

    private function digest(#[\SensitiveParameter] string $secret, string $domain, string $prefix, int $length): string
    {
        $binary = hash_hmac('sha256', "vichan-elite-trip\0{$domain}\0{$secret}", $this->config->siteKey, true);
        return $prefix . substr(rtrim(strtr(base64_encode($binary), '+/', '-_'), '='), 0, $length);
    }
}
