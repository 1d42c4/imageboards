<?php

declare(strict_types=1);

namespace VichanNative\Http;

use Uri\Rfc3986\Uri;

final readonly class Request
{
    public function __construct(
        public string $method,
        public Uri $uri,
        public string $path,
        public array $query,
        public array $post,
        public array $files,
        public array $cookies,
        public array $server,
    ) {
    }

    public static function fromGlobals(): self
    {
        $requestTarget = (string) ($_SERVER['REQUEST_URI'] ?? '/');
        $uri = new Uri($requestTarget, new Uri('http://localhost/'));
        $path = $uri->getPath()
            |> rawurldecode(...)
            |> self::normalizePath(...);
        $server = array_intersect_key($_SERVER, array_fill_keys([
            'REQUEST_URI',
            'REQUEST_METHOD',
            'QUERY_STRING',
            'HTTP_ACCEPT',
            'HTTP_X_REQUESTED_WITH',
            'HTTP_HOST',
            'HTTPS',
        ], true));

        return new self(
            method: strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')),
            uri: $uri,
            path: $path,
            query: $_GET,
            post: $_POST,
            files: $_FILES,
            cookies: $_COOKIE,
            server: $server,
        );
    }

    public function input(string $name, string $default = ''): string
    {
        $value = $this->post[$name] ?? $this->query[$name] ?? $default;
        return is_scalar($value) ? (string) $value : $default;
    }

    public function integer(string $name, int $default = 0): int
    {
        $value = $this->input($name, (string) $default);
        return filter_var($value, FILTER_VALIDATE_INT) !== false ? (int) $value : $default;
    }

    public function expectsJson(): bool
    {
        return str_contains(strtolower((string) ($this->server['HTTP_ACCEPT'] ?? '')), 'application/json')
            || strtolower((string) ($this->server['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
    }

    private static function normalizePath(string $path): string
    {
        $path = '/' . ltrim(str_replace('\\', '/', $path), '/');
        return $path !== '/' ? rtrim($path, '/') : '/';
    }
}
