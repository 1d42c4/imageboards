<?php

declare(strict_types=1);

namespace VichanNative\Controller;

use VichanNative\Config\AppConfig;
use VichanNative\Domain\Moderator;
use VichanNative\Domain\Role;
use VichanNative\Http\Request;
use VichanNative\Http\Response;
use VichanNative\Repository\BoardRepository;
use VichanNative\Repository\ModeratorRepository;
use VichanNative\Repository\PostRepository;
use VichanNative\Security\Csrf;
use VichanNative\Security\ModeratorAuth;
use VichanNative\Service\PublicPath;
use VichanNative\Service\Markup;
use VichanNative\Service\StaticPageBuilder;
use VichanNative\Service\UploadService;
use VichanNative\View\View;

final readonly class ModeratorController
{
    public function __construct(
        private ModeratorAuth $auth,
        private ModeratorRepository $moderators,
        private BoardRepository $boards,
        private PostRepository $posts,
        private UploadService $uploads,
        private StaticPageBuilder $staticPages,
        private Markup $markup,
        private AppConfig $config,
        private Csrf $csrf,
        private View $view,
    ) {
    }

    public function handle(Request $request, string $route): Response
    {
        $moderator = $this->auth->current($request);
        if ($moderator === null) {
            return $this->login($request);
        }
        $route = '/' . trim($route, '/');
        if ($route === '//') {
            $route = '/';
        }
        if ($request->method === 'POST' && !$this->csrf->verify($request->input('csrf'))) {
            throw new \DomainException('The moderator form expired. Reload it and try again.');
        }
        if ($route === '/logout' && $request->method === 'POST') {
            $this->auth->logout($request);
            return Response::redirect('/mod.php');
        }
        return match (true) {
            $route === '/' => $this->dashboard($moderator),
            $route === '/boards' => $this->boards($request, $moderator),
            $route === '/boards/new' => $this->newBoard($request, $moderator),
            preg_match('#^/boards/([a-z0-9_]{1,58})$#D', $route, $match) === 1
                => $this->editBoard($request, $moderator, $match[1]),
            $route === '/pending' => $this->pending($request, $moderator),
            $route === '/posts' => $this->posts($request, $moderator),
            $route === '/users' => $this->users($request, $moderator),
            $route === '/log' => $this->log($moderator),
            $route === '/post-action' => $this->postAction($request, $moderator),
            preg_match('#^/([a-z0-9_]{1,58})/edit/([1-9][0-9]*)$#D', $route, $match) === 1
                => $this->editPost($request, $moderator, $match[1], (int) $match[2]),
            preg_match('#^/([a-z0-9_]{1,58})/res/([1-9][0-9]*)\.html$#D', $route, $match) === 1
                => $this->threadView($moderator, $match[1], (int) $match[2]),
            preg_match('#^/([a-z0-9_]{1,58})/([1-9][0-9]*)\.html$#D', $route, $match) === 1
                => $this->boardView($moderator, $match[1], (int) $match[2] + 1),
            preg_match('#^/([a-z0-9_]{1,58})$#D', $route, $match) === 1
                => $this->boardView($moderator, $match[1], 1),
            default => Response::html($this->view->render('message.php', [
                'title' => 'Not found',
                'heading' => 'Not found',
                'message' => 'That moderator page does not exist.',
            ]), 404),
        };
    }

    private function login(Request $request): Response
    {
        $error = '';
        $username = '';
        if ($request->method === 'POST') {
            if (!$this->csrf->verify($request->input('csrf'))) {
                $error = 'The login form expired. Reload it and try again.';
            } else {
                $username = trim($request->input('username'));
                $moderator = $this->auth->login($request, $username, $request->input('password'));
                if ($moderator !== null) {
                    $this->moderators->log($moderator->id, 'login');
                    return Response::redirect('/mod.php?/');
                }
                $error = 'Invalid username or password.';
            }
        }
        return Response::html($this->view->render('mod/login.php', [
            'title' => 'Moderator login',
            'error' => $error,
            'username' => $username,
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function dashboard(Moderator $moderator): Response
    {
        return Response::html($this->view->render('mod/dashboard.php', [
            'title' => 'Dashboard',
            'moderator' => $moderator,
            'boards' => $this->boards->all(),
            'pendingCount' => $this->posts->countPending(),
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function boards(Request $request, Moderator $moderator): Response
    {
        $this->requireAdministrator($moderator);
        return Response::html($this->view->render('mod/boards.php', [
            'title' => 'Boards',
            'moderator' => $moderator,
            'boards' => $this->boards->all(),
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function newBoard(Request $request, Moderator $moderator): Response
    {
        $this->requireAdministrator($moderator);
        $error = '';
        if ($request->method === 'POST') {
            $uri = strtolower(trim($request->input('uri')));
            $title = trim($request->input('title'));
            $subtitle = trim($request->input('subtitle'));
            if (!preg_match('/^[a-z0-9_]{1,58}$/D', $uri) || PublicPath::isReservedBoardUri($uri)) {
                $error = 'Board URI must use 1-58 lowercase letters, numbers, or underscores and cannot be a reserved application path.';
            } elseif ($title === '' || mb_strlen($title) > 255 || mb_strlen($subtitle) > 500) {
                $error = 'The title or subtitle length is invalid.';
            } elseif ($this->boards->findByUri($uri) !== null) {
                $error = 'That board already exists.';
            } else {
                $board = $this->boards->create($uri, $title, $subtitle);
                $this->moderators->log($moderator->id, 'board.create', $board->uri);
                $this->staticPages->rebuildBoard($board, rebuildAllThreads: true);
                $this->staticPages->rebuildShared();
                return Response::redirect('/mod.php?/boards/' . $board->uri);
            }
        }
        return Response::html($this->view->render('mod/board_edit.php', [
            'title' => 'Create board',
            'moderator' => $moderator,
            'board' => null,
            'error' => $error,
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function editBoard(Request $request, Moderator $moderator, string $uri): Response
    {
        $this->requireAdministrator($moderator);
        $board = $this->boards->findByUri($uri);
        if ($board === null) {
            throw new \DomainException('Board not found.');
        }
        $error = '';
        if ($request->method === 'POST') {
            $title = trim($request->input('title'));
            $subtitle = trim($request->input('subtitle'));
            if ($title === '' || mb_strlen($title) > 255 || mb_strlen($subtitle) > 500) {
                $error = 'The title or subtitle length is invalid.';
            } else {
                $passwordHash = $board->postPasswordHash;
                $passwordAction = $request->input('password_action', 'keep');
                if ($passwordAction === 'clear') {
                    $passwordHash = null;
                } elseif ($passwordAction === 'replace') {
                    $password = $request->input('board_password');
                    if (mb_strlen($password) < 12 || mb_strlen($password) > 200) {
                        $error = 'A board password must contain between 12 and 200 characters.';
                    } else {
                        $passwordHash = password_hash($password, PASSWORD_ARGON2ID);
                    }
                } elseif ($passwordAction !== 'keep') {
                    $error = 'Invalid password action.';
                }
                if ($error === '') {
                    $board = $this->boards->update(
                        $board,
                        $title,
                        $subtitle,
                        $request->input('require_approval') === '1',
                        $passwordHash,
                    );
                    $this->moderators->log($moderator->id, 'board.update', $board->uri);
                    $this->staticPages->rebuildBoard($board, rebuildAllThreads: true);
                    $this->staticPages->rebuildShared();
                    return Response::redirect('/mod.php?/boards/' . $board->uri);
                }
            }
        }
        return Response::html($this->view->render('mod/board_edit.php', [
            'title' => 'Edit /' . $board->uri . '/',
            'moderator' => $moderator,
            'board' => $board,
            'error' => $error,
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function pending(Request $request, Moderator $moderator): Response
    {
        if ($request->method === 'POST') {
            $postId = $request->integer('post_id');
            $action = $request->input('action');
            $pending = array_first(array_filter(
                $this->posts->pending(),
                static fn ($post): bool => $post->id === $postId,
            ));
            if ($pending === null) {
                throw new \DomainException('Pending post not found.');
            }
            $board = $this->boards->findByUri($pending->boardUri)
                ?? throw new \DomainException('Board not found.');
            if ($action === 'approve') {
                $this->posts->publish($postId);
                $this->staticPages->rebuildBoard($board, $pending->threadId ?? $pending->id);
                $this->moderators->log($moderator->id, 'post.approve', $board->uri, $postId);
            } elseif ($action === 'reject') {
                foreach ($this->posts->delete($postId) as $file) {
                    $this->uploads->delete($board, $file);
                }
                $this->moderators->log($moderator->id, 'post.reject', $board->uri, $postId);
            } else {
                throw new \DomainException('Unknown moderation action.');
            }
            return Response::redirect('/mod.php?/pending');
        }
        return Response::html($this->view->render('mod/pending.php', [
            'title' => 'Post approval queue',
            'moderator' => $moderator,
            'posts' => $this->posts->pending(),
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function posts(Request $request, Moderator $moderator): Response
    {
        if ($request->method === 'POST') {
            $postId = $request->integer('post_id');
            $target = array_first(array_filter(
                $this->posts->recent(500),
                static fn ($post): bool => $post->id === $postId,
            ));
            if ($target === null) {
                throw new \DomainException('Post not found.');
            }
            $board = $this->boards->findByUri($target->boardUri)
                ?? throw new \DomainException('Board not found.');
            $threadId = $target->threadId ?? $target->id;
            if ($request->input('action') === 'delete') {
                foreach ($this->posts->delete($postId) as $file) {
                    $this->uploads->delete($board, $file);
                }
                $this->moderators->log($moderator->id, 'post.delete', $board->uri, $postId);
            } elseif ($request->input('action') === 'flags' && $target->isThread()) {
                $this->posts->setThreadFlags(
                    $postId,
                    $request->input('sticky') === '1',
                    $request->input('locked') === '1',
                );
                $this->moderators->log($moderator->id, 'thread.flags', $board->uri, $postId);
            } else {
                throw new \DomainException('Unknown post action.');
            }
            $this->staticPages->rebuildBoard($board, $threadId);
            return Response::redirect('/mod.php?/posts');
        }
        return Response::html($this->view->render('mod/posts.php', [
            'title' => 'Recent posts',
            'moderator' => $moderator,
            'posts' => $this->posts->recent(100),
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function boardView(Moderator $moderator, string $uri, int $page): Response
    {
        $board = $this->boards->findByUri($uri);
        if ($board === null) {
            throw new \DomainException('Board not found.');
        }
        $pageCount = $this->posts->pageCount($board, $this->config->threadsPerPage);
        if ($page < 1 || $page > $pageCount) {
            throw new \DomainException('Board page not found.');
        }
        $returnRoute = '/' . $board->uri . ($page === 1 ? '' : '/' . ($page - 1) . '.html');
        return Response::html($this->view->render('mod/board_view.php', [
            'title' => 'Moderator view /' . $board->uri . '/',
            'moderator' => $moderator,
            'board' => $board,
            'threads' => $this->posts->threads(
                $board,
                $page,
                $this->config->threadsPerPage,
                $this->config->repliesPreview,
            ),
            'page' => $page,
            'pageCount' => $pageCount,
            'returnRoute' => $returnRoute,
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function threadView(Moderator $moderator, string $uri, int $threadId): Response
    {
        $board = $this->boards->findByUri($uri);
        if ($board === null || ($thread = $this->posts->thread($board, $threadId)) === null) {
            throw new \DomainException('Thread not found.');
        }
        $returnRoute = '/' . $board->uri . '/res/' . $thread->id . '.html';
        return Response::html($this->view->render('mod/thread_view.php', [
            'title' => 'Moderator thread /' . $board->uri . '/ No.' . $thread->id,
            'moderator' => $moderator,
            'board' => $board,
            'thread' => $thread,
            'returnRoute' => $returnRoute,
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function editPost(
        Request $request,
        Moderator $moderator,
        string $uri,
        int $postId,
    ): Response {
        $board = $this->boards->findByUri($uri);
        if ($board === null || ($post = $this->posts->findPublishedPost($board, $postId)) === null) {
            throw new \DomainException('Post not found.');
        }
        $defaultReturn = '/' . $board->uri . '/res/' . ($post->threadId ?? $post->id) . '.html';
        $returnRoute = $this->validatedReturnRoute($request, $board->uri, $defaultReturn);
        $error = '';
        $name = $post->name;
        $email = $post->email;
        $subject = $post->subject;
        $body = $post->bodySource;
        $fileAction = 'keep';

        if ($request->method === 'POST') {
            $name = trim($request->input('name'));
            $name = $name === '' ? 'Anonymous' : $name;
            $email = strtolower(trim($request->input('email')));
            $subject = trim($request->input('subject'));
            $body = str_replace(["\r\n", "\r"], "\n", trim($request->input('body')));
            $fileAction = $request->input('file_action', 'keep');

            if (mb_strlen($name) > 35) {
                $error = 'The name is too long.';
            } elseif (!in_array($email, ['', 'sage', 'noko'], true)) {
                $error = 'Options must be blank, sage, or noko.';
            } elseif (mb_strlen($subject) > 100) {
                $error = 'The subject is too long.';
            } elseif (mb_strlen($body) > $this->config->maxBody) {
                $error = 'The comment is too long.';
            } elseif (!in_array($fileAction, ['keep', 'remove', 'replace'], true)) {
                $error = 'Invalid image action.';
            }

            $replacement = null;
            if ($error === '') {
                try {
                    if ($fileAction === 'replace') {
                        $replacement = $this->uploads->store($request->files['file'] ?? [], $board);
                        if ($replacement === null) {
                            throw new \DomainException('Choose an image to replace or add.');
                        }
                    }
                    $willHaveFile = $fileAction === 'replace'
                        || ($fileAction === 'keep' && $post->files !== []);
                    if ($body === '' && !$willHaveFile) {
                        throw new \DomainException('A comment or image is required.');
                    }
                    if ($post->isThread() && $this->config->forceImageForThreads && !$willHaveFile) {
                        throw new \DomainException('A file is required for this thread.');
                    }

                    $replaced = $this->posts->updatePublishedPost(
                        $post,
                        [
                            'name' => $name,
                            'email' => $email,
                            'subject' => $subject,
                            'body_source' => $body,
                            'body_html' => $this->markup->render($body, $board->uri),
                        ],
                        $fileAction !== 'keep',
                        $replacement,
                    );
                    foreach ($replaced as $oldFile) {
                        $this->uploads->delete($board, $oldFile);
                    }
                    $details = match ($fileAction) {
                        'replace' => 'content and image updated',
                        'remove' => 'content updated; image removed',
                        default => 'content updated',
                    };
                    $this->moderators->log($moderator->id, 'post.edit', $board->uri, $post->id, $details);
                    $this->staticPages->rebuildBoard($board, $post->threadId ?? $post->id);
                    return Response::redirect('/mod.php?' . $returnRoute . '#' . $post->id);
                } catch (\DomainException $validationError) {
                    if ($replacement !== null) {
                        $this->uploads->delete($board, $replacement);
                    }
                    $error = $validationError->getMessage();
                } catch (\Throwable $unexpected) {
                    if ($replacement !== null) {
                        $this->uploads->delete($board, $replacement);
                    }
                    throw $unexpected;
                }
            }
        }

        return Response::html($this->view->render('mod/post_edit.php', [
            'title' => 'Edit /' . $board->uri . '/ No.' . $post->id,
            'moderator' => $moderator,
            'board' => $board,
            'post' => $post,
            'error' => $error,
            'name' => $name,
            'email' => $email,
            'subject' => $subject,
            'body' => $body,
            'fileAction' => $fileAction,
            'returnRoute' => $returnRoute,
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function postAction(Request $request, Moderator $moderator): Response
    {
        if ($request->method !== 'POST') {
            throw new \DomainException('Moderator post actions require POST.');
        }
        $board = $this->boards->findByUri(strtolower($request->input('board')));
        if ($board === null) {
            throw new \DomainException('Board not found.');
        }
        $postId = $request->integer('post_id');
        $post = $this->posts->findPublishedPost($board, $postId);
        if ($post === null) {
            throw new \DomainException('Post not found.');
        }
        $threadId = $post->threadId ?? $post->id;
        $returnRoute = $this->validatedReturnRoute(
            $request,
            $board->uri,
            '/' . $board->uri,
        );
        $action = $request->input('action');

        if ($action === 'delete') {
            foreach ($this->posts->delete($post->id) as $file) {
                $this->uploads->delete($board, $file);
            }
            $this->moderators->log($moderator->id, 'post.delete', $board->uri, $post->id);
            if ($post->isThread()) {
                $returnRoute = '/' . $board->uri;
            }
        } elseif ($action === 'toggle_sticky' && $post->isThread()) {
            $this->posts->setThreadFlags($post->id, !$post->sticky, $post->locked);
            $this->moderators->log(
                $moderator->id,
                $post->sticky ? 'thread.unsticky' : 'thread.sticky',
                $board->uri,
                $post->id,
            );
        } elseif ($action === 'toggle_lock' && $post->isThread()) {
            $this->posts->setThreadFlags($post->id, $post->sticky, !$post->locked);
            $this->moderators->log(
                $moderator->id,
                $post->locked ? 'thread.unlock' : 'thread.lock',
                $board->uri,
                $post->id,
            );
        } elseif ($action === 'remove_image') {
            if ($post->files === []) {
                throw new \DomainException('That post has no image.');
            }
            if ($post->isThread() && $this->config->forceImageForThreads) {
                throw new \DomainException('A file is required for this thread; use [Image] to replace it.');
            }
            $removed = $this->posts->updatePublishedPost(
                $post,
                [
                    'name' => $post->name,
                    'email' => $post->email,
                    'subject' => $post->subject,
                    'body_source' => $post->bodySource,
                    'body_html' => $post->bodyHtml,
                ],
                true,
                null,
            );
            foreach ($removed as $file) {
                $this->uploads->delete($board, $file);
            }
            $this->moderators->log($moderator->id, 'post.image.remove', $board->uri, $post->id);
        } else {
            throw new \DomainException('Unknown moderator post action.');
        }

        $this->staticPages->rebuildBoard($board, $threadId);
        $anchor = $action === 'delete' ? '' : '#' . $post->id;
        return Response::redirect('/mod.php?' . $returnRoute . $anchor);
    }

    private function validatedReturnRoute(Request $request, string $boardUri, string $fallback): string
    {
        $route = $request->input('return_route');
        $board = preg_quote($boardUri, '#');
        return preg_match(
            '#^/' . $board . '(?:|/[1-9][0-9]*\.html|/res/[1-9][0-9]*\.html)$#D',
            $route,
        ) === 1 ? $route : $fallback;
    }

    private function users(Request $request, Moderator $moderator): Response
    {
        $this->requireAdministrator($moderator);
        $error = '';
        if ($request->method === 'POST') {
            $action = $request->input('action');
            $username = trim($request->input('username'));
            $password = $request->input('password');
            if (mb_strlen($password) < 14 || mb_strlen($password) > 200) {
                $error = 'Passwords must contain between 14 and 200 characters.';
            } elseif ($action === 'create') {
                if (!preg_match('/^[A-Za-z0-9_.-]{3,60}$/D', $username)) {
                    $error = 'The username format is invalid.';
                } else {
                    $role = Role::tryFrom($request->input('role'));
                    if ($role === null) {
                        $error = 'Invalid moderator role.';
                    } else {
                        $created = $this->moderators->create($username, $password, $role);
                        $this->moderators->log($moderator->id, 'user.create', details: $created->username);
                        return Response::redirect('/mod.php?/users');
                    }
                }
            } elseif ($action === 'password') {
                $targetId = $request->integer('user_id');
                if ($this->moderators->find($targetId) === null) {
                    $error = 'Moderator not found.';
                } else {
                    $this->moderators->changePassword($targetId, $password);
                    $this->moderators->log($moderator->id, 'user.password', details: 'user ' . $targetId);
                    return Response::redirect('/mod.php?/users');
                }
            } else {
                $error = 'Unknown user action.';
            }
            $password = '';
        }
        return Response::html($this->view->render('mod/users.php', [
            'title' => 'Manage users',
            'moderator' => $moderator,
            'users' => $this->moderators->all(),
            'error' => $error,
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function log(Moderator $moderator): Response
    {
        return Response::html($this->view->render('mod/log.php', [
            'title' => 'Moderation log',
            'moderator' => $moderator,
            'entries' => $this->moderators->logEntries(),
            'csrf' => $this->csrf->token(),
        ]));
    }

    private function requireAdministrator(Moderator $moderator): void
    {
        if (!$moderator->role->canManageConfiguration()) {
            throw new \DomainException('Administrator permission is required.');
        }
    }
}
