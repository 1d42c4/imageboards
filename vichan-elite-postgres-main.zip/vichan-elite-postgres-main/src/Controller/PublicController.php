<?php

declare(strict_types=1);

namespace VichanNative\Controller;

use VichanNative\Config\AppConfig;
use VichanNative\Domain\Moderator;
use VichanNative\Http\Response;
use VichanNative\Repository\BoardRepository;
use VichanNative\Repository\PostRepository;
use VichanNative\Security\PublicFormToken;
use VichanNative\Service\UploadService;
use VichanNative\View\View;

final readonly class PublicController
{
    public function __construct(
        private BoardRepository $boards,
        private PostRepository $posts,
        private UploadService $uploads,
        private PublicFormToken $formToken,
        private View $view,
        private AppConfig $config,
    ) {
    }

    public function home(?Moderator $moderator): Response
    {
        return Response::html($this->view->render('home.php', [
            'title' => $this->config->appName,
            'boards' => $this->boards->all(),
            'moderator' => $moderator,
        ]));
    }

    public function framesSidebar(?Moderator $moderator): Response
    {
        return Response::html($this->view->render('frames_sidebar.php', [
            'title' => $this->config->appName . ' - Boards',
            'boards' => $this->boards->all(),
            'moderator' => $moderator,
        ]));
    }

    public function framesNews(?Moderator $moderator): Response
    {
        return Response::html($this->view->render('frames_news.php', [
            'title' => $this->config->appName,
            'boards' => $this->boards->all(),
            'moderator' => $moderator,
        ]));
    }

    public function board(string $uri, int $page, ?Moderator $moderator): Response
    {
        $board = $this->boards->findByUri($uri);
        if ($board === null) {
            return $this->notFound();
        }
        $pageCount = $this->posts->pageCount($board, $this->config->threadsPerPage);
        if ($page < 1 || $page > $pageCount) {
            return $this->notFound();
        }
        return Response::html($this->view->render('board.php', [
            'title' => '/' . $board->uri . '/ - ' . $board->title,
            'board' => $board,
            'threads' => $this->posts->threads(
                $board,
                $page,
                $this->config->threadsPerPage,
                $this->config->repliesPreview,
            ),
            'page' => $page,
            'pageCount' => $pageCount,
            'csrf' => $this->formToken->token($board, null),
            'moderator' => $moderator,
        ]));
    }

    public function thread(string $uri, int $threadId, ?Moderator $moderator): Response
    {
        $board = $this->boards->findByUri($uri);
        if ($board === null || ($thread = $this->posts->thread($board, $threadId)) === null) {
            return $this->notFound();
        }
        return Response::html($this->view->render('thread.php', [
            'title' => '/' . $board->uri . '/ - ' . ($thread->subject !== '' ? $thread->subject : 'Thread ' . $thread->id),
            'board' => $board,
            'thread' => $thread,
            'csrf' => $this->formToken->token($board, $thread->id),
            'moderator' => $moderator,
        ]));
    }

    public function catalog(string $uri, ?Moderator $moderator): Response
    {
        $board = $this->boards->findByUri($uri);
        if ($board === null) {
            return $this->notFound();
        }
        return Response::html($this->view->render('catalog.php', [
            'title' => '/' . $board->uri . '/ - Catalog',
            'board' => $board,
            'threads' => $this->posts->threads($board, 1, 100, 0),
            'moderator' => $moderator,
        ]));
    }

    public function uploadedFile(string $uri, string $name, bool $thumbnail): Response
    {
        $board = $this->boards->findByUri($uri);
        if ($board === null) {
            return $this->notFound();
        }
        try {
            $path = $this->uploads->path($board, $name, $thumbnail);
        } catch (\DomainException) {
            return $this->notFound();
        }
        if (!is_file($path)) {
            return $this->notFound();
        }
        $body = file_get_contents($path);
        if ($body === false) {
            return $this->notFound();
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($path) ?: 'application/octet-stream';
        return new Response(200, [
            'Content-Type' => $mime,
            'Content-Length' => (string) strlen($body),
            'Cache-Control' => 'public, max-age=31536000, immutable',
            'X-Content-Type-Options' => 'nosniff',
        ], $body);
    }

    public function pendingNotice(): Response
    {
        return Response::html($this->view->render('message.php', [
            'title' => 'Awaiting approval',
            'heading' => 'Awaiting approval',
            'message' => 'Your post was submitted for moderator approval.',
        ]), 202);
    }

    public function notFound(): Response
    {
        return Response::html($this->view->render('message.php', [
            'title' => 'Not found',
            'heading' => 'Not found',
            'message' => 'The requested board or thread does not exist.',
        ]), 404);
    }
}
