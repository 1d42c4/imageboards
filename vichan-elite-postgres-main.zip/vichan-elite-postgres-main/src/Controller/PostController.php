<?php

declare(strict_types=1);

namespace VichanNative\Controller;

use VichanNative\Config\AppConfig;
use VichanNative\Domain\PostStatus;
use VichanNative\Http\Request;
use VichanNative\Http\Response;
use VichanNative\Repository\BoardRepository;
use VichanNative\Repository\PostRepository;
use VichanNative\Security\PublicFormToken;
use VichanNative\Security\RateLimiter;
use VichanNative\Security\Tripcode;
use VichanNative\Service\Markup;
use VichanNative\Service\StaticPageBuilder;
use VichanNative\Service\UploadService;

final readonly class PostController
{
    public function __construct(
        private BoardRepository $boards,
        private PostRepository $posts,
        private Tripcode $tripcode,
        private RateLimiter $rateLimiter,
        private PublicFormToken $formToken,
        private Markup $markup,
        private UploadService $uploads,
        private StaticPageBuilder $staticPages,
        private AppConfig $config,
    ) {
    }

    public function create(Request $request): Response
    {
        if ($request->method !== 'POST') {
            throw new \DomainException('The posting form expired. Reload the page and try again.');
        }
        $board = $this->boards->findByUri(strtolower($request->input('board')));
        if ($board === null) {
            throw new \DomainException('Unknown board.');
        }
        $threadId = $request->integer('thread');
        if (!$this->formToken->verify(
            $request->input('csrf'),
            $board,
            $threadId > 0 ? $threadId : null,
        )) {
            throw new \DomainException('The posting form expired. Reload the page and try again.');
        }
        if ($board->requiresPassword() && !password_verify($request->input('board_password'), $board->postPasswordHash ?? '')) {
            $this->rateLimiter->consume($this->rateLimiter->sessionBucket('board-password:' . $board->uri), 8, 900);
            throw new \DomainException('The board password was incorrect.');
        }

        $this->rateLimiter->consume($this->rateLimiter->sessionBucket('post:' . $board->uri), 8, 60);
        $body = str_replace(["\r\n", "\r"], "\n", trim($request->input('body')));
        if (mb_strlen($body) > $this->config->maxBody) {
            throw new \DomainException('The comment is too long.');
        }
        if (substr_count(strtolower($body), 'http://') + substr_count(strtolower($body), 'https://') > 20) {
            throw new \DomainException('The comment contains too many links.');
        }
        if ($body !== '') {
            $this->rateLimiter->consume(
                $this->rateLimiter->contentBucket('body:' . $board->uri, $body),
                2,
                3600,
            );
        }

        $thread = $threadId > 0 ? $this->posts->thread($board, $threadId) : null;
        if ($threadId > 0 && $thread === null) {
            throw new \DomainException('That thread no longer exists.');
        }
        if ($thread?->locked) {
            throw new \DomainException('That thread is locked.');
        }

        $identity = $this->tripcode->derive($request->input('name'));
        $subject = trim($request->input('subject'));
        if (mb_strlen($subject) > 100) {
            throw new \DomainException('The subject is too long.');
        }
        $email = strtolower(trim($request->input('email')));
        if (!in_array($email, ['', 'sage', 'noko'], true)) {
            throw new \DomainException('The email/options value is not allowed.');
        }

        $stored = null;
        try {
            $stored = $this->uploads->store($request->files['file'] ?? [], $board);
            if ($thread === null && $this->config->forceImageForThreads && $stored === null) {
                throw new \DomainException('A file is required to start a new thread.');
            }
            if ($body === '' && $stored === null) {
                throw new \DomainException('A comment or file is required.');
            }
            $status = $board->requireApproval ? PostStatus::Pending : PostStatus::Published;
            $postId = $this->posts->create($board, $thread, [
                'subject' => $subject,
                'name' => $identity->name,
                'trip' => $identity->trip,
                'email' => $email,
                'body_source' => $body,
                'body_html' => $this->markup->render($body, $board->uri),
            ], $status, $stored !== null ? [$stored] : []);
        } catch (\Throwable $error) {
            if ($stored !== null) {
                $this->uploads->delete($board, $stored);
            }
            throw $error;
        }

        if ($status === PostStatus::Pending) {
            return $request->expectsJson()
                ? Response::json([
                    'success' => true,
                    'pending' => true,
                    'id' => $postId,
                    'redirect' => '/post-pending?posted=1',
                ], 202)
                : Response::redirect('/post-pending?posted=1');
        }
        $this->staticPages->rebuildBoard($board, $thread?->id ?? $postId);
        $noko = $email === 'noko';
        $location = $noko
            ? '/' . $board->uri . '/res/' . ($thread?->id ?? $postId) . '.html?posted=1'
                . ($thread !== null ? '#' . $postId : '')
            : '/' . $board->uri . '/?posted=1';
        return $request->expectsJson()
            ? Response::json([
                'success' => true,
                'id' => $postId,
                'redirect' => $location,
                'noko' => $noko,
            ])
            : Response::redirect($location);
    }
}
