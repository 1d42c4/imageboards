<?php

declare(strict_types=1);

namespace VichanNative\View;

use VichanNative\Config\AppConfig;

final readonly class View
{
    public function __construct(private AppConfig $config)
    {
    }

    public function render(string $template, array $data = []): string
    {
        if (!preg_match('/^[a-z0-9_\/-]+\.php$/D', $template) || str_contains($template, '..')) {
            throw new \RuntimeException('Unsafe view name.');
        }
        $root = $this->config->root . DIRECTORY_SEPARATOR . 'views';
        $realRoot = realpath($root) ?: throw new \RuntimeException('View directory is missing.');
        $path = realpath($root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $template));
        if ($path === false || !str_starts_with($path, $realRoot . DIRECTORY_SEPARATOR)) {
            throw new \RuntimeException('View not found: ' . $template);
        }
        $e = static fn (mixed $value): string =>
            htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
        $config = $this->config;
        extract($data, EXTR_SKIP);
        ob_start();
        try {
            require $path;
            return (string) ob_get_clean();
        } catch (\Throwable $error) {
            ob_end_clean();
            throw $error;
        }
    }

    public function partial(string $template, array $data = []): void
    {
        echo $this->render($template, $data);
    }
}
