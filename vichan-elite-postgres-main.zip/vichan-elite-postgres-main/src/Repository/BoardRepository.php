<?php

declare(strict_types=1);

namespace VichanNative\Repository;

use PDO;
use VichanNative\Database;
use VichanNative\Domain\Board;

final readonly class BoardRepository
{
    public function __construct(private Database $database)
    {
    }

    /** @return list<Board> */
    public function all(): array
    {
        $rows = $this->database->pdo()->query('SELECT * FROM boards ORDER BY uri')->fetchAll();
        return array_map($this->hydrate(...), $rows);
    }

    public function findByUri(string $uri): ?Board
    {
        $query = $this->database->pdo()->prepare('SELECT * FROM boards WHERE uri = :uri LIMIT 1');
        $query->execute(['uri' => $uri]);
        $row = $query->fetch();
        return $row === false ? null : $this->hydrate($row);
    }

    public function findById(int $id): ?Board
    {
        $query = $this->database->pdo()->prepare('SELECT * FROM boards WHERE id = :id LIMIT 1');
        $query->execute(['id' => $id]);
        $row = $query->fetch();
        return $row === false ? null : $this->hydrate($row);
    }

    #[\NoDiscard('The created board must be used.')]
    public function create(string $uri, string $title, string $subtitle): Board
    {
        $now = time();
        $query = $this->database->pdo()->prepare(
            'INSERT INTO boards (uri, title, subtitle, require_approval, post_password_hash, created_at, updated_at)
             VALUES (:uri, :title, :subtitle, false, NULL, :created, :updated)
             RETURNING *'
        );
        $query->execute([
            'uri' => $uri,
            'title' => $title,
            'subtitle' => $subtitle,
            'created' => $now,
            'updated' => $now,
        ]);
        $row = $query->fetch();
        return $row !== false
            ? $this->hydrate($row)
            : throw new \RuntimeException('Created board could not be loaded.');
    }

    public function update(
        Board $board,
        string $title,
        string $subtitle,
        bool $requireApproval,
        ?string $postPasswordHash,
    ): Board {
        $query = $this->database->pdo()->prepare(
            'UPDATE boards
             SET title = :title, subtitle = :subtitle, require_approval = :approval,
                 post_password_hash = :password, updated_at = :updated
             WHERE id = :id'
        );
        $query->bindValue('title', $title);
        $query->bindValue('subtitle', $subtitle);
        $query->bindValue('approval', $requireApproval, PDO::PARAM_BOOL);
        $query->bindValue('password', $postPasswordHash);
        $query->bindValue('updated', time(), PDO::PARAM_INT);
        $query->bindValue('id', $board->id, PDO::PARAM_INT);
        $query->execute();
        return $this->findById($board->id)
            ?? throw new \RuntimeException('Updated board could not be loaded.');
    }

    private function hydrate(array $row): Board
    {
        return new Board(
            id: (int) $row['id'],
            uri: (string) $row['uri'],
            title: (string) $row['title'],
            subtitle: (string) $row['subtitle'],
            requireApproval: Database::boolean($row['require_approval']),
            postPasswordHash: $row['post_password_hash'] !== null ? (string) $row['post_password_hash'] : null,
            createdAt: (int) $row['created_at'],
            updatedAt: (int) $row['updated_at'],
        );
    }
}
