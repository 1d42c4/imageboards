<?php

declare(strict_types=1);

namespace VichanNative\Repository;

use PDO;
use VichanNative\Database;
use VichanNative\Domain\Board;
use VichanNative\Domain\Post;
use VichanNative\Domain\PostFile;
use VichanNative\Domain\PostStatus;

final readonly class PostRepository
{
    public function __construct(private Database $database)
    {
    }

    /** @return list<Post> */
    public function threads(Board $board, int $page, int $perPage, int $previewReplies): array
    {
        $query = $this->database->pdo()->prepare(
            "SELECT p.*, b.uri AS board_uri
             FROM posts p JOIN boards b ON b.id = p.board_id
             WHERE p.board_id = :board AND p.thread_id IS NULL AND p.status = 'published'
             ORDER BY p.sticky DESC, p.bumped_at DESC
             LIMIT :limit OFFSET :offset"
        );
        $query->bindValue('board', $board->id, PDO::PARAM_INT);
        $query->bindValue('limit', $perPage, PDO::PARAM_INT);
        $query->bindValue('offset', max(0, $page - 1) * $perPage, PDO::PARAM_INT);
        $query->execute();
        $threads = array_map($this->hydrate(...), $query->fetchAll());
        if ($threads === []) {
            return [];
        }

        $threadIds = array_map(static fn (Post $post): int => $post->id, $threads);
        $replyGroups = $this->previewReplies($threadIds, $previewReplies);
        $counts = $this->replyCounts($threadIds);
        $allPosts = $threads;
        foreach ($replyGroups as $replies) {
            array_push($allPosts, ...$replies);
        }
        $files = $this->filesForPosts(array_map(static fn (Post $post): int => $post->id, $allPosts));

        $result = [];
        foreach ($threads as $thread) {
            $thread = $thread->withFiles($files[$thread->id] ?? []);
            $replies = array_map(
                static fn (Post $reply): Post => $reply->withFiles($files[$reply->id] ?? []),
                $replyGroups[$thread->id] ?? [],
            );
            $omitted = max(0, ($counts[$thread->id] ?? 0) - count($replies));
            $result[] = $thread->withReplies($replies, $omitted);
        }
        return $result;
    }

    public function pageCount(Board $board, int $perPage): int
    {
        $query = $this->database->pdo()->prepare(
            "SELECT COUNT(*) FROM posts
             WHERE board_id = :board AND thread_id IS NULL AND status = 'published'"
        );
        $query->execute(['board' => $board->id]);
        return max(1, (int) ceil(((int) $query->fetchColumn()) / $perPage));
    }

    /** @return list<int> */
    public function publishedThreadIds(Board $board): array
    {
        $query = $this->database->pdo()->prepare(
            "SELECT id FROM posts
             WHERE board_id = :board AND thread_id IS NULL AND status = 'published'
             ORDER BY id"
        );
        $query->execute(['board' => $board->id]);
        return array_map('intval', $query->fetchAll(PDO::FETCH_COLUMN));
    }

    public function thread(Board $board, int $threadId): ?Post
    {
        $query = $this->database->pdo()->prepare(
            "SELECT p.*, b.uri AS board_uri
             FROM posts p JOIN boards b ON b.id = p.board_id
             WHERE p.id = :id AND p.board_id = :board AND p.thread_id IS NULL
               AND p.status = 'published' LIMIT 1"
        );
        $query->execute(['id' => $threadId, 'board' => $board->id]);
        $row = $query->fetch();
        if ($row === false) {
            return null;
        }
        $thread = $this->hydrate($row);
        $replyQuery = $this->database->pdo()->prepare(
            "SELECT p.*, b.uri AS board_uri
             FROM posts p JOIN boards b ON b.id = p.board_id
             WHERE p.thread_id = :thread AND p.status = 'published' ORDER BY p.id"
        );
        $replyQuery->execute(['thread' => $threadId]);
        $replies = array_map($this->hydrate(...), $replyQuery->fetchAll());
        $ids = [$threadId, ...array_map(static fn (Post $post): int => $post->id, $replies)];
        $files = $this->filesForPosts($ids);
        $replies = array_map(
            static fn (Post $post): Post => $post->withFiles($files[$post->id] ?? []),
            $replies,
        );
        return $thread->withFiles($files[$threadId] ?? [])->withReplies($replies);
    }

    public function findPublishedPost(Board $board, int $postId): ?Post
    {
        $query = $this->database->pdo()->prepare(
            "SELECT p.*, b.uri AS board_uri
             FROM posts p JOIN boards b ON b.id = p.board_id
             WHERE p.id = :id AND p.board_id = :board AND p.status = 'published' LIMIT 1"
        );
        $query->execute(['id' => $postId, 'board' => $board->id]);
        $row = $query->fetch();
        if ($row === false) {
            return null;
        }
        $post = $this->hydrate($row);
        $files = $this->filesForPosts([$postId]);
        return $post->withFiles($files[$postId] ?? []);
    }

    /**
     * @param array{name:string,email:string,subject:string,body_source:string,body_html:string} $data
     * @return list<PostFile> files replaced by this update
     */
    public function updatePublishedPost(
        Post $post,
        array $data,
        bool $changeFile,
        ?PostFile $replacement,
    ): array {
        return $this->database->transaction(
            function (PDO $pdo) use ($post, $data, $changeFile, $replacement): array {
                $lock = $pdo->prepare(
                    "SELECT id FROM posts
                     WHERE id = :id AND board_id = :board AND status = 'published'
                     FOR UPDATE"
                );
                $lock->execute(['id' => $post->id, 'board' => $post->boardId]);
                if ($lock->fetchColumn() === false) {
                    throw new \DomainException('Post not found.');
                }

                $update = $pdo->prepare(
                    'UPDATE posts
                     SET name = :name, email = :email, subject = :subject,
                         body_source = :source, body_html = :html
                     WHERE id = :id'
                );
                $update->execute([
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'subject' => $data['subject'],
                    'source' => $data['body_source'],
                    'html' => $data['body_html'],
                    'id' => $post->id,
                ]);

                if (!$changeFile) {
                    return [];
                }
                $files = $this->filesForPosts([$post->id])[$post->id] ?? [];
                $deleteFiles = $pdo->prepare('DELETE FROM post_files WHERE post_id = :post');
                $deleteFiles->execute(['post' => $post->id]);
                if ($replacement !== null) {
                    $insert = $pdo->prepare(
                        'INSERT INTO post_files
                         (post_id, stored_name, thumbnail_name, original_name, mime, size, width, height,
                          thumbnail_width, thumbnail_height)
                         VALUES
                         (:post, :stored, :thumb, :original, :mime, :size, :width, :height,
                          :thumb_width, :thumb_height)'
                    );
                    $insert->execute([
                        'post' => $post->id,
                        'stored' => $replacement->storedName,
                        'thumb' => $replacement->thumbnailName,
                        'original' => $replacement->originalName,
                        'mime' => $replacement->mime,
                        'size' => $replacement->size,
                        'width' => $replacement->width,
                        'height' => $replacement->height,
                        'thumb_width' => $replacement->thumbnailWidth,
                        'thumb_height' => $replacement->thumbnailHeight,
                    ]);
                }
                return $files;
            },
        );
    }

    /**
     * @param array{subject:string,name:string,trip:string,email:string,body_source:string,body_html:string} $data
     * @param list<PostFile> $files
     */
    public function create(
        Board $board,
        ?Post $thread,
        array $data,
        PostStatus $status,
        array $files,
    ): int {
        return $this->database->transaction(function (PDO $pdo) use ($board, $thread, $data, $status, $files): int {
            $now = time();
            if ($thread !== null) {
                $lock = $pdo->prepare(
                    "SELECT locked FROM posts
                     WHERE id = :id AND board_id = :board AND thread_id IS NULL
                       AND status = 'published' FOR UPDATE"
                );
                $lock->execute(['id' => $thread->id, 'board' => $board->id]);
                $locked = $lock->fetch();
                if ($locked === false || Database::boolean($locked['locked'])) {
                    throw new \DomainException('That thread is locked or no longer exists.');
                }
            }
            $query = $pdo->prepare(
                'INSERT INTO posts
                 (board_id, thread_id, subject, name, trip, email, body_source, body_html,
                  status, created_at, bumped_at, sticky, locked)
                 VALUES
                 (:board, :thread, :subject, :name, :trip, :email, :source, :html,
                  :status, :created, :bumped, false, false)
                 RETURNING id'
            );
            $query->execute([
                'board' => $board->id,
                'thread' => $thread?->id,
                'subject' => $data['subject'],
                'name' => $data['name'],
                'trip' => $data['trip'],
                'email' => $data['email'],
                'source' => $data['body_source'],
                'html' => $data['body_html'],
                'status' => $status->value,
                'created' => $now,
                'bumped' => $now,
            ]);
            $postId = (int) $query->fetchColumn();
            if ($postId < 1) {
                throw new \RuntimeException('Created post did not return an identifier.');
            }
            if ($files !== []) {
                $fileQuery = $pdo->prepare(
                    'INSERT INTO post_files
                     (post_id, stored_name, thumbnail_name, original_name, mime, size, width, height,
                      thumbnail_width, thumbnail_height)
                     VALUES
                     (:post, :stored, :thumb, :original, :mime, :size, :width, :height, :thumb_width, :thumb_height)'
                );
                foreach ($files as $file) {
                    $fileQuery->execute([
                        'post' => $postId,
                        'stored' => $file->storedName,
                        'thumb' => $file->thumbnailName,
                        'original' => $file->originalName,
                        'mime' => $file->mime,
                        'size' => $file->size,
                        'width' => $file->width,
                        'height' => $file->height,
                        'thumb_width' => $file->thumbnailWidth,
                        'thumb_height' => $file->thumbnailHeight,
                    ]);
                }
            }
            if ($thread !== null && $status === PostStatus::Published && strtolower($data['email']) !== 'sage') {
                $bump = $pdo->prepare('UPDATE posts SET bumped_at = :time WHERE id = :id');
                $bump->execute(['time' => $now, 'id' => $thread->id]);
            }
            return $postId;
        });
    }

    public function countPending(): int
    {
        return (int) $this->database->pdo()
            ->query("SELECT COUNT(*) FROM posts WHERE status = 'pending'")
            ->fetchColumn();
    }

    /** @return list<Post> */
    public function pending(): array
    {
        $rows = $this->database->pdo()->query(
            "SELECT p.*, b.uri AS board_uri
             FROM posts p JOIN boards b ON b.id = p.board_id
             WHERE p.status = 'pending' ORDER BY p.created_at"
        )->fetchAll();
        $posts = array_map($this->hydrate(...), $rows);
        $files = $this->filesForPosts(array_map(static fn (Post $post): int => $post->id, $posts));
        return array_map(
            static fn (Post $post): Post => $post->withFiles($files[$post->id] ?? []),
            $posts,
        );
    }

    public function publish(int $postId): void
    {
        (void) $this->database->transaction(function (PDO $pdo) use ($postId): bool {
            $query = $pdo->prepare("SELECT thread_id FROM posts WHERE id = :id AND status = 'pending' FOR UPDATE");
            $query->execute(['id' => $postId]);
            $row = $query->fetch();
            if ($row === false) {
                throw new \DomainException('Pending post not found.');
            }
            $update = $pdo->prepare("UPDATE posts SET status = 'published' WHERE id = :id");
            $update->execute(['id' => $postId]);
            if ($row['thread_id'] !== null) {
                $bump = $pdo->prepare('UPDATE posts SET bumped_at = :time WHERE id = :id');
                $bump->execute(['time' => time(), 'id' => (int) $row['thread_id']]);
            }
            return true;
        });
    }

    /** @return list<PostFile> */
    public function delete(int $postId): array
    {
        return $this->database->transaction(function (PDO $pdo) use ($postId): array {
            $idsQuery = $pdo->prepare('SELECT id FROM posts WHERE id = :post OR thread_id = :thread');
            $idsQuery->execute(['post' => $postId, 'thread' => $postId]);
            $postIds = array_map('intval', $idsQuery->fetchAll(PDO::FETCH_COLUMN));
            if ($postIds === []) {
                throw new \DomainException('Post not found.');
            }
            $filesByPost = $this->filesForPosts($postIds);
            $files = [];
            foreach ($filesByPost as $postFiles) {
                array_push($files, ...$postFiles);
            }
            $query = $pdo->prepare('DELETE FROM posts WHERE id = :id');
            $query->execute(['id' => $postId]);
            if ($query->rowCount() !== 1) {
                throw new \DomainException('Post not found.');
            }
            return $files;
        });
    }

    /** @return list<Post> */
    public function recent(int $limit = 100): array
    {
        $query = $this->database->pdo()->prepare(
            "SELECT p.*, b.uri AS board_uri
             FROM posts p JOIN boards b ON b.id = p.board_id
             WHERE p.status = 'published' ORDER BY p.id DESC LIMIT :limit"
        );
        $query->bindValue('limit', $limit, PDO::PARAM_INT);
        $query->execute();
        return array_map($this->hydrate(...), $query->fetchAll());
    }

    public function setThreadFlags(int $postId, bool $sticky, bool $locked): void
    {
        $query = $this->database->pdo()->prepare(
            'UPDATE posts SET sticky = :sticky, locked = :locked WHERE id = :id AND thread_id IS NULL'
        );
        $query->bindValue('sticky', $sticky, PDO::PARAM_BOOL);
        $query->bindValue('locked', $locked, PDO::PARAM_BOOL);
        $query->bindValue('id', $postId, PDO::PARAM_INT);
        $query->execute();
        if ($query->rowCount() !== 1) {
            throw new \DomainException('Thread not found.');
        }
    }

    /** @return array<int,list<Post>> */
    private function previewReplies(array $threadIds, int $limit): array
    {
        if ($limit < 1) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($threadIds), '?'));
        $sql = "SELECT ranked.* FROM (
                    SELECT p.*, b.uri AS board_uri,
                           ROW_NUMBER() OVER (PARTITION BY p.thread_id ORDER BY p.id DESC) AS row_num
                    FROM posts p JOIN boards b ON b.id = p.board_id
                    WHERE p.thread_id IN ($placeholders) AND p.status = 'published'
                ) ranked
                WHERE ranked.row_num <= ? ORDER BY ranked.thread_id, ranked.id";
        $query = $this->database->pdo()->prepare($sql);
        $index = 1;
        foreach ($threadIds as $id) {
            $query->bindValue($index++, $id, PDO::PARAM_INT);
        }
        $query->bindValue($index, $limit, PDO::PARAM_INT);
        $query->execute();
        $groups = [];
        foreach ($query->fetchAll() as $row) {
            $post = $this->hydrate($row);
            $groups[$post->threadId][] = $post;
        }
        return $groups;
    }

    /** @return array<int,int> */
    private function replyCounts(array $threadIds): array
    {
        $placeholders = implode(',', array_fill(0, count($threadIds), '?'));
        $query = $this->database->pdo()->prepare(
            "SELECT thread_id, COUNT(*) AS total FROM posts
             WHERE thread_id IN ($placeholders) AND status = 'published' GROUP BY thread_id"
        );
        $query->execute($threadIds);
        $counts = [];
        foreach ($query->fetchAll() as $row) {
            $counts[(int) $row['thread_id']] = (int) $row['total'];
        }
        return $counts;
    }

    /** @return array<int,list<PostFile>> */
    private function filesForPosts(array $postIds): array
    {
        if ($postIds === []) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($postIds), '?'));
        $query = $this->database->pdo()->prepare(
            "SELECT * FROM post_files WHERE post_id IN ($placeholders) ORDER BY id"
        );
        $query->execute($postIds);
        $files = [];
        foreach ($query->fetchAll() as $row) {
            $file = new PostFile(
                id: (int) $row['id'],
                postId: (int) $row['post_id'],
                storedName: (string) $row['stored_name'],
                thumbnailName: (string) $row['thumbnail_name'],
                originalName: (string) $row['original_name'],
                mime: (string) $row['mime'],
                size: (int) $row['size'],
                width: (int) $row['width'],
                height: (int) $row['height'],
                thumbnailWidth: (int) $row['thumbnail_width'],
                thumbnailHeight: (int) $row['thumbnail_height'],
            );
            $files[$file->postId][] = $file;
        }
        return $files;
    }

    private function hydrate(array $row): Post
    {
        return new Post(
            id: (int) $row['id'],
            boardId: (int) $row['board_id'],
            boardUri: (string) $row['board_uri'],
            threadId: $row['thread_id'] !== null ? (int) $row['thread_id'] : null,
            subject: (string) $row['subject'],
            name: (string) $row['name'],
            trip: (string) $row['trip'],
            email: (string) $row['email'],
            bodySource: (string) $row['body_source'],
            bodyHtml: (string) $row['body_html'],
            status: PostStatus::from((string) $row['status']),
            createdAt: (int) $row['created_at'],
            bumpedAt: (int) $row['bumped_at'],
            sticky: Database::boolean($row['sticky']),
            locked: Database::boolean($row['locked']),
        );
    }
}
