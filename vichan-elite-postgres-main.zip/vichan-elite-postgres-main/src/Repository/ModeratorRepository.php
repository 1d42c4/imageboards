<?php

declare(strict_types=1);

namespace VichanNative\Repository;

use PDO;
use VichanNative\Database;
use VichanNative\Domain\Moderator;
use VichanNative\Domain\Role;

final readonly class ModeratorRepository
{
    public function __construct(private Database $database)
    {
    }

    public function credentials(string $username): ?array
    {
        $query = $this->database->pdo()->prepare(
            'SELECT * FROM moderators WHERE lower(username) = lower(:username) LIMIT 1'
        );
        $query->execute(['username' => $username]);
        $row = $query->fetch();
        return $row === false ? null : $row;
    }

    public function find(int $id): ?Moderator
    {
        $query = $this->database->pdo()->prepare('SELECT * FROM moderators WHERE id = :id LIMIT 1');
        $query->execute(['id' => $id]);
        $row = $query->fetch();
        return $row === false ? null : $this->hydrate($row);
    }

    /** @return list<Moderator> */
    public function all(): array
    {
        return array_map(
            $this->hydrate(...),
            $this->database->pdo()->query('SELECT * FROM moderators ORDER BY username')->fetchAll(),
        );
    }

    public function create(string $username, #[\SensitiveParameter] string $password, Role $role): Moderator
    {
        $now = time();
        $query = $this->database->pdo()->prepare(
            'INSERT INTO moderators (username, password_hash, role, force_password_change, created_at, updated_at)
             VALUES (:username, :password, :role, false, :created, :updated)
             RETURNING id, username, role, force_password_change'
        );
        $query->execute([
            'username' => $username,
            'password' => password_hash($password, PASSWORD_ARGON2ID),
            'role' => $role->value,
            'created' => $now,
            'updated' => $now,
        ]);
        $row = $query->fetch();
        return $row !== false
            ? $this->hydrate($row)
            : throw new \RuntimeException('Created moderator could not be loaded.');
    }

    public function changePassword(int $id, #[\SensitiveParameter] string $password): void
    {
        $query = $this->database->pdo()->prepare(
            'UPDATE moderators SET password_hash = :password, force_password_change = 0, updated_at = :updated
             WHERE id = :id'
        );
        $query->execute([
            'password' => password_hash($password, PASSWORD_ARGON2ID),
            'updated' => time(),
            'id' => $id,
        ]);
    }

    public function createSession(int $moderatorId, string $tokenHash, int $expiresAt): void
    {
        $now = time();
        $query = $this->database->pdo()->prepare(
            'INSERT INTO moderator_sessions
             (token_hash, moderator_id, created_at, last_seen_at, expires_at)
             VALUES (:token, :moderator, :created, :seen, :expires)'
        );
        $query->bindValue('token', $tokenHash, PDO::PARAM_LOB);
        $query->bindValue('moderator', $moderatorId, PDO::PARAM_INT);
        $query->bindValue('created', $now, PDO::PARAM_INT);
        $query->bindValue('seen', $now, PDO::PARAM_INT);
        $query->bindValue('expires', $expiresAt, PDO::PARAM_INT);
        $query->execute();
    }

    public function moderatorForSession(string $tokenHash): ?Moderator
    {
        $query = $this->database->pdo()->prepare(
            'SELECT m.* FROM moderator_sessions s
             JOIN moderators m ON m.id = s.moderator_id
             WHERE s.token_hash = :token AND s.expires_at >= :now LIMIT 1'
        );
        $query->bindValue('token', $tokenHash, PDO::PARAM_LOB);
        $query->bindValue('now', time(), PDO::PARAM_INT);
        $query->execute();
        $row = $query->fetch();
        if ($row === false) {
            return null;
        }
        $touch = $this->database->pdo()->prepare(
            'UPDATE moderator_sessions SET last_seen_at = :seen WHERE token_hash = :token'
        );
        $touch->bindValue('seen', time(), PDO::PARAM_INT);
        $touch->bindValue('token', $tokenHash, PDO::PARAM_LOB);
        $touch->execute();
        return $this->hydrate($row);
    }

    public function deleteSession(string $tokenHash): void
    {
        $query = $this->database->pdo()->prepare('DELETE FROM moderator_sessions WHERE token_hash = :token');
        $query->bindValue('token', $tokenHash, PDO::PARAM_LOB);
        $query->execute();
    }

    public function deleteExpiredSessions(): void
    {
        $query = $this->database->pdo()->prepare('DELETE FROM moderator_sessions WHERE expires_at < :now');
        $query->execute(['now' => time()]);
    }

    public function log(?int $moderatorId, string $action, ?string $boardUri = null, ?int $postId = null, string $details = ''): void
    {
        $query = $this->database->pdo()->prepare(
            'INSERT INTO moderation_log
             (moderator_id, action, board_uri, post_id, details, created_at)
             VALUES (:moderator, :action, :board, :post, :details, :created)'
        );
        $query->execute([
            'moderator' => $moderatorId,
            'action' => $action,
            'board' => $boardUri,
            'post' => $postId,
            'details' => mb_substr($details, 0, 1000),
            'created' => time(),
        ]);
    }

    /** @return list<array<string,mixed>> */
    public function logEntries(int $limit = 200): array
    {
        $query = $this->database->pdo()->prepare(
            'SELECT l.*, m.username FROM moderation_log l
             LEFT JOIN moderators m ON m.id = l.moderator_id
             ORDER BY l.id DESC LIMIT :limit'
        );
        $query->bindValue('limit', $limit, PDO::PARAM_INT);
        $query->execute();
        return $query->fetchAll();
    }

    private function hydrate(array $row): Moderator
    {
        return new Moderator(
            id: (int) $row['id'],
            username: (string) $row['username'],
            role: Role::from((string) $row['role']),
            forcePasswordChange: Database::boolean($row['force_password_change']),
        );
    }
}
