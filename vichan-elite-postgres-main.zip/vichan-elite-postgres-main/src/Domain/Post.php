<?php

declare(strict_types=1);

namespace VichanNative\Domain;

final readonly class Post
{
    /** @param list<PostFile> $files */
    public function __construct(
        public int $id,
        public int $boardId,
        public string $boardUri,
        public ?int $threadId,
        public string $subject,
        public string $name,
        public string $trip,
        public string $email,
        public string $bodySource,
        public string $bodyHtml,
        public PostStatus $status,
        public int $createdAt,
        public int $bumpedAt,
        public bool $sticky,
        public bool $locked,
        public array $files = [],
        public array $replies = [],
        public int $omittedReplies = 0,
    ) {
    }

    public function isThread(): bool
    {
        return $this->threadId === null;
    }

    /** @param list<PostFile> $files */
    public function withFiles(array $files): self
    {
        return clone($this, ['files' => $files]);
    }

    /** @param list<Post> $replies */
    public function withReplies(array $replies, int $omittedReplies = 0): self
    {
        return clone($this, ['replies' => $replies, 'omittedReplies' => $omittedReplies]);
    }
}
