<?php

declare(strict_types=1);

namespace VichanNative\Domain;

enum PostStatus: string
{
    case Pending = 'pending';
    case Published = 'published';
}
