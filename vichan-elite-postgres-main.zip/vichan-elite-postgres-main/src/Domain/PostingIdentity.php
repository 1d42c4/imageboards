<?php

declare(strict_types=1);

namespace VichanNative\Domain;

final readonly class PostingIdentity
{
    public function __construct(
        public string $name,
        public string $trip,
    ) {
    }
}
