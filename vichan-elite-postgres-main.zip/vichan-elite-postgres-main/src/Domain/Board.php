<?php

declare(strict_types=1);

namespace VichanNative\Domain;

final readonly class Board
{
    public function __construct(
        public int $id,
        public string $uri,
        public string $title,
        public string $subtitle,
        public bool $requireApproval,
        #[\SensitiveParameter]
        public ?string $postPasswordHash,
        public int $createdAt,
        public int $updatedAt,
    ) {
    }

    public function path(): string
    {
        return '/' . $this->uri . '/';
    }

    public function requiresPassword(): bool
    {
        return $this->postPasswordHash !== null && $this->postPasswordHash !== '';
    }
}
