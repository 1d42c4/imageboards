<?php

declare(strict_types=1);

namespace VichanNative\Domain;

final readonly class Moderator
{
    public function __construct(
        public int $id,
        public string $username,
        public Role $role,
        public bool $forcePasswordChange,
    ) {
    }
}
