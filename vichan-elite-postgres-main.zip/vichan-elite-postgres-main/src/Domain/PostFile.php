<?php

declare(strict_types=1);

namespace VichanNative\Domain;

final readonly class PostFile
{
    public function __construct(
        public int $id,
        public int $postId,
        public string $storedName,
        public string $thumbnailName,
        public string $originalName,
        public string $mime,
        public int $size,
        public int $width,
        public int $height,
        public int $thumbnailWidth,
        public int $thumbnailHeight,
    ) {
    }
}
