<?php

declare(strict_types=1);

namespace VichanNative\Domain;

enum Role: string
{
    case Moderator = 'moderator';
    case Administrator = 'administrator';

    public function canManageConfiguration(): bool
    {
        return $this === self::Administrator;
    }
}
