<?php

declare(strict_types=1);

namespace VichanNative\Service;

use VichanNative\Config\AppConfig;

final class PublicPath
{
    private const RESERVED_BOARD_URIS = [
        'assets',
        'bin',
        'database',
        'frames',
        'js',
        'public',
        'src',
        'static',
        'storage',
        'stylesheets',
        'vendor',
        'views',
    ];

    public static function boardDirectory(AppConfig $config, string $uri): string
    {
        if (!preg_match('/^[a-z0-9_]{1,58}$/D', $uri) || self::isReservedBoardUri($uri)) {
            throw new \DomainException('The board URI conflicts with a public application path.');
        }
        return $config->root . DIRECTORY_SEPARATOR . $uri;
    }

    public static function isReservedBoardUri(string $uri): bool
    {
        return in_array(strtolower($uri), self::RESERVED_BOARD_URIS, true);
    }

    private function __construct()
    {
    }
}
