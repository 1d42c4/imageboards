<?php

declare(strict_types=1);

namespace VichanNative\Service;

use VichanNative\Config\AppConfig;
use VichanNative\Controller\PublicController;
use VichanNative\Domain\Board;
use VichanNative\Http\Response;
use VichanNative\Repository\BoardRepository;
use VichanNative\Repository\PostRepository;

final readonly class StaticPageBuilder
{
    public function __construct(
        private AppConfig $config,
        private BoardRepository $boards,
        private PostRepository $posts,
        private PublicController $public,
        private UploadService $uploads,
    ) {
    }

    public function rebuildAll(): void
    {
        $this->rebuildShared();
        foreach ($this->boards->all() as $board) {
            $this->rebuildBoard($board, rebuildAllThreads: true);
        }
    }

    public function rebuildShared(): void
    {
        $this->withLock('shared', function (): void {
            $this->write(
                $this->config->root . DIRECTORY_SEPARATOR . 'index.html',
                $this->body($this->public->home(null)),
            );
            $frames = $this->config->root . DIRECTORY_SEPARATOR . 'frames';
            $this->write(
                $frames . DIRECTORY_SEPARATOR . 'sidebar.html',
                $this->body($this->public->framesSidebar(null)),
            );
            $this->write(
                $frames . DIRECTORY_SEPARATOR . 'news.html',
                $this->body($this->public->framesNews(null)),
            );
        });
    }

    public function rebuildBoard(
        Board $board,
        ?int $threadId = null,
        bool $rebuildAllThreads = false,
    ): void {
        $this->withLock('board-' . $board->uri, function () use ($board, $threadId, $rebuildAllThreads): void {
            $directory = PublicPath::boardDirectory($this->config, $board->uri);
            $this->ensureDirectory($directory);
            $this->uploads->publishExisting($board);

            $pageCount = $this->posts->pageCount($board, $this->config->threadsPerPage);
            for ($page = 1; $page <= $pageCount; $page++) {
                $filename = $page === 1 ? 'index.html' : ($page - 1) . '.html';
                $this->write(
                    $directory . DIRECTORY_SEPARATOR . $filename,
                    $this->body($this->public->board($board->uri, $page, null)),
                );
            }
            $this->removeStaleBoardPages($directory, $pageCount);
            $this->write(
                $directory . DIRECTORY_SEPARATOR . 'catalog.html',
                $this->body($this->public->catalog($board->uri, null)),
            );

            if ($rebuildAllThreads) {
                $threadIds = $this->posts->publishedThreadIds($board);
                foreach ($threadIds as $publishedThreadId) {
                    $this->writeThread($board, $publishedThreadId, $directory);
                }
                $this->removeStaleThreads($directory, $threadIds);
            } elseif ($threadId !== null) {
                $this->writeThread($board, $threadId, $directory);
            }
        });
    }

    private function writeThread(Board $board, int $threadId, string $boardDirectory): void
    {
        $path = $boardDirectory . DIRECTORY_SEPARATOR . 'res' . DIRECTORY_SEPARATOR . $threadId . '.html';
        $response = $this->public->thread($board->uri, $threadId, null);
        if ($response->status === 404) {
            $this->remove($path);
            return;
        }
        $this->write($path, $this->body($response));
    }

    private function body(Response $response): string
    {
        if ($response->status !== 200) {
            throw new \RuntimeException('Static page rendering returned HTTP ' . $response->status . '.');
        }
        return $response->body;
    }

    private function removeStaleBoardPages(string $directory, int $pageCount): void
    {
        foreach (new \DirectoryIterator($directory) as $file) {
            if (!$file->isFile() || preg_match('/^([1-9][0-9]*)\.html$/D', $file->getFilename(), $match) !== 1) {
                continue;
            }
            if ((int) $match[1] >= $pageCount) {
                $this->remove($file->getPathname());
            }
        }
    }

    /** @param list<int> $threadIds */
    private function removeStaleThreads(string $boardDirectory, array $threadIds): void
    {
        $directory = $boardDirectory . DIRECTORY_SEPARATOR . 'res';
        if (!is_dir($directory)) {
            return;
        }
        $published = array_fill_keys($threadIds, true);
        foreach (new \DirectoryIterator($directory) as $file) {
            if (!$file->isFile() || preg_match('/^([1-9][0-9]*)\.html$/D', $file->getFilename(), $match) !== 1) {
                continue;
            }
            if (!isset($published[(int) $match[1]])) {
                $this->remove($file->getPathname());
            }
        }
    }

    private function write(string $path, string $contents): void
    {
        $this->ensureDirectory(dirname($path));
        $temporary = $path . '.' . bin2hex(random_bytes(8)) . '.tmp';
        try {
            $written = file_put_contents($temporary, $contents, LOCK_EX);
            if ($written !== strlen($contents)) {
                throw new \RuntimeException('Could not completely write static page: ' . $path);
            }
            if (!rename($temporary, $path)) {
                throw new \RuntimeException('Could not publish static page: ' . $path);
            }
        } finally {
            if (is_file($temporary)) {
                @unlink($temporary);
            }
        }
    }

    private function remove(string $path): void
    {
        if (is_file($path) && !unlink($path)) {
            throw new \RuntimeException('Could not remove stale static page: ' . $path);
        }
    }

    private function ensureDirectory(string $directory): void
    {
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Could not create static output directory: ' . $directory);
        }
    }

    private function withLock(string $name, callable $build): void
    {
        $directory = $this->config->root . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'locks';
        $this->ensureDirectory($directory);
        $handle = fopen($directory . DIRECTORY_SEPARATOR . $name . '.lock', 'c+b');
        if ($handle === false) {
            throw new \RuntimeException('Could not open the static build lock.');
        }
        try {
            if (!flock($handle, LOCK_EX)) {
                throw new \RuntimeException('Could not acquire the static build lock.');
            }
            $build();
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }
}
