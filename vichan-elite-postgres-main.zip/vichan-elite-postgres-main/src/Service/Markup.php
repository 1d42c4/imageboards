<?php

declare(strict_types=1);

namespace VichanNative\Service;

final class Markup
{
    public function render(string $source, string $boardUri): string
    {
        if (!mb_check_encoding($source, 'UTF-8')) {
            throw new \DomainException('The comment is not valid UTF-8.');
        }
        $escaped = htmlspecialchars($source, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
        $quoted = preg_replace_callback(
            '/&gt;&gt;(\d+)/',
            static fn (array $match): string =>
                '<a class="post_no" href="/' . rawurlencode($boardUri) . '/res/' . $match[1] . '.html#' . $match[1] . '">&gt;&gt;' . $match[1] . '</a>',
            $escaped,
        );
        return '<p>' . nl2br($quoted ?? $escaped, false) . '</p>';
    }
}
