<?php

declare(strict_types=1);

namespace VichanNative\Service;

use GdImage;
use VichanNative\Config\AppConfig;
use VichanNative\Domain\Board;
use VichanNative\Domain\PostFile;

final readonly class UploadService
{
    private const MIME_EXTENSIONS = [
        'image/png' => 'png',
        'image/jpeg' => 'jpg',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
    ];

    public function __construct(private AppConfig $config)
    {
    }

    public function store(array $upload, Board $board): ?PostFile
    {
        $error = (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw new \DomainException('The upload failed with code ' . $error . '.');
        }
        $tmp = (string) ($upload['tmp_name'] ?? '');
        $size = (int) ($upload['size'] ?? 0);
        if (!is_uploaded_file($tmp) || $size < 1 || $size > $this->config->maxUploadBytes) {
            throw new \DomainException('The uploaded file is invalid or too large.');
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($tmp);
        if (!is_string($mime) || !isset(self::MIME_EXTENSIONS[$mime])) {
            throw new \DomainException('Only PNG, JPEG, GIF, and WebP images are accepted.');
        }
        $imageData = file_get_contents($tmp);
        $source = $imageData !== false ? @imagecreatefromstring($imageData) : false;
        if (!$source instanceof GdImage) {
            throw new \DomainException('The uploaded image could not be decoded.');
        }
        $width = imagesx($source);
        $height = imagesy($source);
        if ($width < 1 || $height < 1 || $width > 6000 || $height > 6000) {
            throw new \DomainException('The image dimensions are not allowed.');
        }
        $extension = self::MIME_EXTENSIONS[$mime];
        $storedName = bin2hex(random_bytes(16)) . '.' . $extension;
        $thumbnailName = bin2hex(random_bytes(16)) . '.' . $extension;
        [$sourceDirectory, $thumbnailDirectory] = $this->ensureDirectories($board);
        $sourcePath = $sourceDirectory . DIRECTORY_SEPARATOR . $storedName;
        $thumbnailPath = $thumbnailDirectory . DIRECTORY_SEPARATOR . $thumbnailName;
        try {
            $this->writeImageAtomic($source, $sourcePath, $mime);
            [$thumbWidth, $thumbHeight] = $this->thumbnailDimensions($width, $height, 250, 250);
            $thumbnail = imagecreatetruecolor($thumbWidth, $thumbHeight);
            if (!$thumbnail instanceof GdImage) {
                throw new \RuntimeException('Could not allocate thumbnail image.');
            }
            $this->prepareTransparency($thumbnail, $mime);
            imagecopyresampled($thumbnail, $source, 0, 0, 0, 0, $thumbWidth, $thumbHeight, $width, $height);
            $this->writeImageAtomic($thumbnail, $thumbnailPath, $mime);
            unset($thumbnail);
        } catch (\Throwable $error) {
            @unlink($sourcePath);
            @unlink($thumbnailPath);
            throw $error;
        } finally {
            unset($source, $imageData);
        }
        $original = basename(str_replace('\\', '/', (string) ($upload['name'] ?? 'image.' . $extension)));
        $original = mb_substr($original, 0, 255);
        $file = new PostFile(
            id: 0,
            postId: 0,
            storedName: $storedName,
            thumbnailName: $thumbnailName,
            originalName: $original,
            mime: $mime,
            size: (int) filesize($sourcePath),
            width: $width,
            height: $height,
            thumbnailWidth: $thumbWidth,
            thumbnailHeight: $thumbHeight,
        );
        try {
            $this->publish($board, $file);
        } catch (\Throwable $error) {
            $this->delete($board, $file);
            throw $error;
        }
        return $file;
    }

    public function importLegacy(string $legacyPath, string $originalName, Board $board): PostFile
    {
        $size = is_file($legacyPath) ? (int) filesize($legacyPath) : 0;
        if ($size < 1 || $size > $this->config->maxUploadBytes) {
            throw new \DomainException('A legacy image is missing or too large.');
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($legacyPath);
        if (!is_string($mime) || !isset(self::MIME_EXTENSIONS[$mime])) {
            throw new \DomainException('A legacy file is not a supported image.');
        }
        $imageData = file_get_contents($legacyPath);
        $source = $imageData !== false ? @imagecreatefromstring($imageData) : false;
        if (!$source instanceof GdImage) {
            throw new \DomainException('A legacy image could not be decoded.');
        }
        $width = imagesx($source);
        $height = imagesy($source);
        if ($width < 1 || $height < 1 || $width > 6000 || $height > 6000) {
            throw new \DomainException('A legacy image has disallowed dimensions.');
        }
        $extension = self::MIME_EXTENSIONS[$mime];
        $storedName = bin2hex(random_bytes(16)) . '.' . $extension;
        $thumbnailName = bin2hex(random_bytes(16)) . '.' . $extension;
        [$sourceDirectory, $thumbnailDirectory] = $this->ensureDirectories($board);
        $sourcePath = $sourceDirectory . DIRECTORY_SEPARATOR . $storedName;
        $thumbnailPath = $thumbnailDirectory . DIRECTORY_SEPARATOR . $thumbnailName;
        try {
            $this->writeImageAtomic($source, $sourcePath, $mime);
            [$thumbWidth, $thumbHeight] = $this->thumbnailDimensions($width, $height, 250, 250);
            $thumbnail = imagecreatetruecolor($thumbWidth, $thumbHeight);
            if (!$thumbnail instanceof GdImage) {
                throw new \RuntimeException('Could not allocate imported thumbnail.');
            }
            $this->prepareTransparency($thumbnail, $mime);
            imagecopyresampled($thumbnail, $source, 0, 0, 0, 0, $thumbWidth, $thumbHeight, $width, $height);
            $this->writeImageAtomic($thumbnail, $thumbnailPath, $mime);
            unset($thumbnail);
        } catch (\Throwable $error) {
            @unlink($sourcePath);
            @unlink($thumbnailPath);
            throw $error;
        } finally {
            unset($source, $imageData);
        }
        $file = new PostFile(
            id: 0,
            postId: 0,
            storedName: $storedName,
            thumbnailName: $thumbnailName,
            originalName: mb_substr(basename(str_replace('\\', '/', $originalName)), 0, 255),
            mime: $mime,
            size: (int) filesize($sourcePath),
            width: $width,
            height: $height,
            thumbnailWidth: $thumbWidth,
            thumbnailHeight: $thumbHeight,
        );
        try {
            $this->publish($board, $file);
        } catch (\Throwable $error) {
            $this->delete($board, $file);
            throw $error;
        }
        return $file;
    }

    public function publish(Board $board, PostFile $file): void
    {
        foreach ([false, true] as $thumbnail) {
            $name = $thumbnail ? $file->thumbnailName : $file->storedName;
            $this->publishPath(
                $this->path($board, $name, $thumbnail),
                $this->publicPath($board, $name, $thumbnail),
            );
        }
    }

    public function publishExisting(Board $board): void
    {
        foreach ([false, true] as $thumbnail) {
            $directory = dirname($this->path($board, str_repeat('0', 32) . '.png', $thumbnail));
            if (!is_dir($directory)) {
                continue;
            }
            foreach (new \DirectoryIterator($directory) as $file) {
                if (!$file->isFile()
                    || preg_match('/^[a-f0-9]{32}\.(?:png|jpg|gif|webp)$/D', $file->getFilename()) !== 1) {
                    continue;
                }
                $this->publishPath(
                    $file->getPathname(),
                    $this->publicPath($board, $file->getFilename(), $thumbnail),
                );
            }
        }
    }

    public function delete(Board $board, PostFile $file): void
    {
        foreach ([false, true] as $thumbnail) {
            $name = $thumbnail ? $file->thumbnailName : $file->storedName;
            foreach ([$this->path($board, $name, $thumbnail), $this->publicPath($board, $name, $thumbnail)] as $path) {
                if (is_file($path)) {
                    @unlink($path);
                }
            }
        }
    }

    public function path(Board $board, string $name, bool $thumbnail): string
    {
        if (!preg_match('/^[a-f0-9]{32}\.(?:png|jpg|gif|webp)$/D', $name)) {
            throw new \DomainException('Invalid stored file name.');
        }
        $directory = $this->config->root . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'uploads'
            . DIRECTORY_SEPARATOR . $board->uri . DIRECTORY_SEPARATOR . ($thumbnail ? 'thumb' : 'src');
        return $directory . DIRECTORY_SEPARATOR . $name;
    }

    private function publicPath(Board $board, string $name, bool $thumbnail): string
    {
        if (!preg_match('/^[a-f0-9]{32}\.(?:png|jpg|gif|webp)$/D', $name)) {
            throw new \DomainException('Invalid stored file name.');
        }
        return PublicPath::boardDirectory($this->config, $board->uri)
            . DIRECTORY_SEPARATOR . ($thumbnail ? 'thumb' : 'src')
            . DIRECTORY_SEPARATOR . $name;
    }

    private function publishPath(string $source, string $destination): void
    {
        if (!is_file($source)) {
            throw new \RuntimeException('A stored upload is missing.');
        }
        $directory = dirname($destination);
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new \RuntimeException('Could not create the public upload directory.');
        }
        if (is_file($destination)) {
            return;
        }
        if (@link($source, $destination)) {
            return;
        }
        $temporary = $destination . '.' . bin2hex(random_bytes(6)) . '.tmp';
        try {
            if (!copy($source, $temporary) || !rename($temporary, $destination)) {
                throw new \RuntimeException('Could not publish an uploaded image.');
            }
        } finally {
            if (is_file($temporary)) {
                @unlink($temporary);
            }
        }
    }

    /** @return array{string,string} */
    private function ensureDirectories(Board $board): array
    {
        $root = $this->config->root . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'uploads'
            . DIRECTORY_SEPARATOR . $board->uri;
        $source = $root . DIRECTORY_SEPARATOR . 'src';
        $thumb = $root . DIRECTORY_SEPARATOR . 'thumb';
        foreach ([$source, $thumb] as $directory) {
            if (!is_dir($directory) && !mkdir($directory, 0770, true) && !is_dir($directory)) {
                throw new \RuntimeException('Could not create upload storage.');
            }
        }
        return [$source, $thumb];
    }

    /** @return array{int,int} */
    private function thumbnailDimensions(int $width, int $height, int $maxWidth, int $maxHeight): array
    {
        $scale = min(1, $maxWidth / $width, $maxHeight / $height);
        return [max(1, (int) round($width * $scale)), max(1, (int) round($height * $scale))];
    }

    private function prepareTransparency(GdImage $image, string $mime): void
    {
        if (in_array($mime, ['image/png', 'image/webp', 'image/gif'], true)) {
            imagealphablending($image, false);
            imagesavealpha($image, true);
            $transparent = imagecolorallocatealpha($image, 0, 0, 0, 127);
            imagefilledrectangle($image, 0, 0, imagesx($image), imagesy($image), $transparent);
        }
    }

    private function writeImageAtomic(GdImage $image, string $destination, string $mime): void
    {
        $temporary = $destination . '.' . bin2hex(random_bytes(6)) . '.tmp';
        $ok = match ($mime) {
            'image/png' => imagepng($image, $temporary, 7),
            'image/jpeg' => imagejpeg($image, $temporary, 88),
            'image/gif' => imagegif($image, $temporary),
            'image/webp' => imagewebp($image, $temporary, 88),
            default => false,
        };
        if (!$ok || !rename($temporary, $destination)) {
            @unlink($temporary);
            throw new \RuntimeException('Could not safely write the uploaded image.');
        }
    }
}
