<?php

declare(strict_types=1);

namespace VichanNative;

use PDO;
use Pdo\Pgsql;
use Throwable;
use VichanNative\Config\AppConfig;

final class Database
{
    private ?Pgsql $pdo = null;

    public function __construct(private readonly AppConfig $config)
    {
    }

    public function pdo(): Pgsql
    {
        if ($this->pdo !== null) {
            return $this->pdo;
        }
        if ($this->config->dbPassword === '') {
            throw new \RuntimeException('VICHAN_DB_PASSWORD must be provided through the environment.');
        }

        $this->pdo = Pgsql::connect(
            $this->config->dsn(),
            $this->config->dbUser,
            $this->config->dbPassword,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_STRINGIFY_FETCHES => false,
                PDO::ATTR_PERSISTENT => PHP_SAPI !== 'cli',
            ],
        );
        $this->pdo->exec(<<<'SQL'
            SET SESSION TIME ZONE 'UTC';
            SET SESSION search_path TO pg_catalog, public;
            SET SESSION statement_timeout = '15s';
            SET SESSION lock_timeout = '5s';
            SET SESSION idle_in_transaction_session_timeout = '15s'
            SQL);
        return $this->pdo;
    }

    public static function boolean(mixed $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE)
            ?? throw new \UnexpectedValueException('PostgreSQL returned an invalid boolean value.');
    }

    #[\NoDiscard('The transaction result must be used.')]
    public function transaction(callable $operation): mixed
    {
        $pdo = $this->pdo();
        $pdo->beginTransaction();
        try {
            $result = $operation($pdo);
            $pdo->commit();
            return $result;
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $error;
        }
    }
}
