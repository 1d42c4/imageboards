<?php

declare(strict_types=1);

namespace VichanNative;

use Throwable;
use VichanNative\Config\AppConfig;
use VichanNative\Controller\ModeratorController;
use VichanNative\Controller\PostController;
use VichanNative\Controller\PublicController;
use VichanNative\Http\Request;
use VichanNative\Http\Response;
use VichanNative\Repository\BoardRepository;
use VichanNative\Repository\ModeratorRepository;
use VichanNative\Repository\PostRepository;
use VichanNative\Security\Csrf;
use VichanNative\Security\ModeratorAuth;
use VichanNative\Security\PublicFormToken;
use VichanNative\Security\RateLimiter;
use VichanNative\Security\Tripcode;
use VichanNative\Service\Markup;
use VichanNative\Service\StaticPageBuilder;
use VichanNative\Service\UploadService;
use VichanNative\View\View;

final readonly class Application
{
    private PublicController $public;
    private PostController $posting;
    private ModeratorController $moderation;
    private ModeratorAuth $auth;
    private StaticPageBuilder $staticPages;
    private View $view;

    public function __construct(private AppConfig $config)
    {
        $database = new Database($config);
        $boards = new BoardRepository($database);
        $posts = new PostRepository($database);
        $moderators = new ModeratorRepository($database);
        $csrf = new Csrf();
        $rateLimiter = new RateLimiter($database, $config);
        $uploads = new UploadService($config);
        $view = new View($config);
        $auth = new ModeratorAuth($moderators, $rateLimiter, $csrf, $config);
        $formToken = new PublicFormToken($config);
        $markup = new Markup();
        $public = new PublicController($boards, $posts, $uploads, $formToken, $view, $config);
        $staticPages = new StaticPageBuilder($config, $boards, $posts, $public, $uploads);

        $this->view = $view;
        $this->auth = $auth;
        $this->public = $public;
        $this->staticPages = $staticPages;
        $this->posting = new PostController(
            $boards,
            $posts,
            new Tripcode($config),
            $rateLimiter,
            $formToken,
            $markup,
            $uploads,
            $staticPages,
            $config,
        );
        $this->moderation = new ModeratorController(
            $auth,
            $moderators,
            $boards,
            $posts,
            $uploads,
            $staticPages,
            $markup,
            $config,
            $csrf,
            $view,
        );
    }

    public function rebuildStaticPages(): void
    {
        $this->staticPages->rebuildAll();
    }

    public function handle(Request $request): Response
    {
        try {
            $response = $this->dispatch($request);
        } catch (\DomainException $error) {
            $response = Response::html($this->view->render('message.php', [
                'title' => 'Error',
                'heading' => 'Error',
                'message' => $error->getMessage(),
            ]), 400);
        } catch (Throwable $error) {
            error_log(sprintf(
                '%s error %s in %s:%d',
                $this->config->appName,
                $error->getMessage(),
                $error->getFile(),
                $error->getLine(),
            ));
            $response = Response::html($this->view->render('message.php', [
                'title' => 'Server error',
                'heading' => 'Server error',
                'message' => 'The request could not be completed.',
            ]), 500);
        }
        return $response->withSecurityHeaders();
    }

    private function dispatch(Request $request): Response
    {
        if ($request->path === '/post.php') {
            return $this->posting->create($request);
        }
        if ($request->path === '/post-pending') {
            return $this->public->pendingNotice();
        }
        if ($request->path === '/mod.php') {
            $route = (string) ($request->server['QUERY_STRING'] ?? '/');
            return $this->moderation->handle($request, $route === '' ? '/' : $route);
        }
        if (preg_match('#^/([a-z0-9_]{1,58})/(src|thumb)/([a-f0-9]{32}\.(?:png|jpg|gif|webp))$#D', $request->path, $match)) {
            return $this->public->uploadedFile($match[1], $match[3], $match[2] === 'thumb');
        }
        $moderator = $this->auth->current($request);
        if ($request->path === '/' || $request->path === '/index.php' || $request->path === '/index.html') {
            return $this->public->home($moderator);
        }
        if ($request->path === '/frames/sidebar' || $request->path === '/frames/sidebar.html') {
            return $this->public->framesSidebar($moderator);
        }
        if ($request->path === '/frames/news' || $request->path === '/frames/news.html') {
            return $this->public->framesNews($moderator);
        }
        if (preg_match('#^/([a-z0-9_]{1,58})/(?:catalog(?:\.html)?)$#D', $request->path, $match)) {
            return $this->public->catalog($match[1], $moderator);
        }
        if (preg_match('#^/([a-z0-9_]{1,58})/res/(\d+)\.html$#D', $request->path, $match)) {
            return $this->public->thread($match[1], (int) $match[2], $moderator);
        }
        if (preg_match('#^/([a-z0-9_]{1,58})(?:/index\.html)?$#D', $request->path, $match)) {
            return $this->public->board($match[1], 1, $moderator);
        }
        if (preg_match('#^/([a-z0-9_]{1,58})/(\d+)\.html$#D', $request->path, $match)) {
            return $this->public->board($match[1], (int) $match[2] + 1, $moderator);
        }
        return $this->public->notFound();
    }
}
