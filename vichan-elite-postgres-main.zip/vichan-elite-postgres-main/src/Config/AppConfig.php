<?php

declare(strict_types=1);

namespace VichanNative\Config;

use RuntimeException;

final readonly class AppConfig
{
    private const string DEVELOPMENT_SITE_KEY = '64c2176bf25eaaf9e370c27edbd8d484670f8e476287d05cdfd3b7cb760b5682';

    public function __construct(
        public string $root,
        public string $appName,
        public string $dbHost,
        public int $dbPort,
        public string $dbName,
        public string $dbUser,
        #[\SensitiveParameter]
        public string $dbPassword,
        public string $dbSslMode,
        #[\SensitiveParameter]
        public string $siteKey,
        public string $baseUrl,
        public int $threadsPerPage,
        public int $repliesPreview,
        public int $maxBody,
        public int $maxUploadBytes,
        public bool $forceImageForThreads,
        public bool $allowInsecureLocal,
    ) {
        if (PHP_VERSION_ID < 80508 || PHP_VERSION_ID >= 80600) {
            throw new RuntimeException('Vichan Elite requires PHP 8.5.8 or a newer PHP 8.5 patch release.');
        }
        if (trim($this->appName) === '') {
            throw new RuntimeException('The application name cannot be empty.');
        }
        if (strlen($this->siteKey) < 64) {
            throw new RuntimeException('The application site key must contain at least 64 characters.');
        }
        if (!$this->allowInsecureLocal && hash_equals(self::DEVELOPMENT_SITE_KEY, $this->siteKey)) {
            throw new RuntimeException('VICHAN_SITE_KEY must replace the committed localhost-only development key.');
        }
        if (!$this->allowInsecureLocal && !str_starts_with($this->baseUrl, 'https://')) {
            throw new RuntimeException('VICHAN_BASE_URL must use HTTPS outside explicit localhost mode.');
        }
        if (!preg_match('/^[A-Za-z0-9_]+$/D', $this->dbName)) {
            throw new RuntimeException('Unsafe database name.');
        }
        if (strlen($this->dbName) > 63) {
            throw new RuntimeException('The PostgreSQL database name is too long.');
        }
        if (!preg_match('/^[A-Za-z0-9_.:-]+$/D', $this->dbHost)) {
            throw new RuntimeException('Unsafe database host.');
        }
        if ($this->dbPort < 1 || $this->dbPort > 65535) {
            throw new RuntimeException('The database port is outside the valid range.');
        }
        if (!in_array($this->dbSslMode, ['disable', 'allow', 'prefer', 'require', 'verify-ca', 'verify-full'], true)) {
            throw new RuntimeException('Unsupported PostgreSQL sslmode.');
        }
    }

    public static function load(string $root): self
    {
        $local = require $root . DIRECTORY_SEPARATOR . 'config.php';
        $env = static fn (string $name, mixed $fallback): mixed =>
            (($value = getenv($name)) === false || $value === '') ? $fallback : $value;

        return new self(
            root: $root,
            appName: trim((string) $env('VICHAN_APP_NAME', $local['app_name'])),
            dbHost: (string) $env('VICHAN_DB_HOST', $local['db_host']),
            dbPort: (int) $env('VICHAN_DB_PORT', $local['db_port']),
            dbName: (string) $env('VICHAN_DB_NAME', $local['db_name']),
            dbUser: (string) $env('VICHAN_DB_USER', $local['db_user']),
            dbPassword: (string) $env('VICHAN_DB_PASSWORD', $local['db_password']),
            dbSslMode: strtolower((string) $env('VICHAN_DB_SSLMODE', $local['db_sslmode'])),
            siteKey: (string) $env('VICHAN_SITE_KEY', $local['site_key']),
            baseUrl: rtrim((string) $env('VICHAN_BASE_URL', $local['base_url']), '/'),
            threadsPerPage: max(1, (int) $local['threads_per_page']),
            repliesPreview: max(0, (int) $local['replies_preview']),
            maxBody: max(100, (int) $local['max_body']),
            maxUploadBytes: max(1024, (int) $local['max_upload_bytes']),
            forceImageForThreads: (bool) $local['force_image_for_threads'],
            allowInsecureLocal: $env('VICHAN_ALLOW_INSECURE_LOCAL', '0') === '1',
        );
    }

    public function dsn(): string
    {
        return sprintf(
            'pgsql:host=%s;port=%d;dbname=%s;sslmode=%s;connect_timeout=5;application_name=vichan_elite',
            $this->dbHost,
            $this->dbPort,
            $this->dbName,
            $this->dbSslMode,
        );
    }
}
