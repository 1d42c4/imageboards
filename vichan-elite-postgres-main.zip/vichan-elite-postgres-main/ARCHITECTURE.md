# Architecture

The application is a small front-controller system with no package manager or runtime framework.

## Request flow

1. The web server serves generated home, board, pagination, catalog, thread and immutable media files directly.
2. For the PHP development server, `router.php` uses PHP 8.5's RFC 3986 URI implementation and returns existing public files without bootstrapping the application.
3. Dynamic posting, pending notices, moderator routes and missing-page fallbacks enter `bootstrap.php`, which enforces PHP 8.5.8+, registers the namespace autoloader and configures strict sessions.
4. `Application` composes repositories, security services, the static builder and controllers.
5. Controllers return immutable `Response` objects with the common dynamic-response security headers.

Public routes preserve the recognizable paths:

- `/` and `/b/`
- `/b/1.html` for subsequent board pages
- `/b/res/123.html`
- `/b/catalog.html`
- `/post.php`
- `/mod.php?/` and its moderator subroutes

## Data model

The normalized native schema replaces legacy per-board post tables:

- `boards` stores board policy, including optional approval and an optional Argon2id posting-password hash.
- `posts` stores threads and replies, with an explicit pending/published state.
- `post_files` stores only generated file names and verified image metadata.
- `moderators` and `moderator_sessions` provide modern credential and session storage.
- `rate_limits` stores keyed anonymous content/session buckets, never addresses.
- `moderation_log` is an action audit trail without address data.
- `legacy_import_map` makes one-way imports resumable and idempotent.

All tables use PostgreSQL 18 identity columns, foreign keys, check constraints, native booleans and query-oriented partial indexes. A database trigger rejects replies whose parent is not a thread on the same board. Thread previews use a window function rather than one query per thread.

## Source layout

- `src/Config`: validated immutable configuration
- `src/Domain`: readonly objects and enums
- `src/Http`: request and immutable response types
- `src/Repository`: prepared database operations
- `src/Security`: CSRF, authentication, tripcodes and anonymous throttling
- `src/Service`: safe markup, image processing and atomic static generation
- `src/Controller`: public, posting and moderator workflows
- `views`: escaped native PHP templates
- `database`: transactionally applied PostgreSQL-native schema
- `bin`: migrations, preflight, tests, admin creation and safe legacy import

## Static public output

`StaticPageBuilder` writes pages atomically under the familiar Vichan paths: `/index.html`, `/frames/*.html`, `/<board>/index.html`, numbered board pages, `catalog.html` and `res/<thread>.html`. Per-board locks serialize concurrent rebuilds. Full rebuilds remove stale numbered pages and deleted thread files.

Published changes synchronously rebuild the affected thread, every board index page and the catalog. Board configuration changes also rebuild all of that board's threads and the shared home/frames pages. Pending posts do not enter generated HTML until approval. `bin/rebuild-static.php` provides an idempotent full rebuild for startup, deployment and recovery.

Authenticated board and thread routes render the same posts dynamically with compact Vichan-style controls. Moderator edits and image replacement/removal are committed transactionally, audited, and passed through the same targeted static rebuild path as posting and deletion.

Canonical uploads stay in `storage/uploads`. Randomly named public files under `/<board>/src` and `/<board>/thumb` are hard links when the filesystem supports them, with an atomic copy fallback. This keeps media reads out of PHP without duplicating file data on the normal Windows setup.

## Performance choices

- Persistent PDO connections for web requests
- PHP 8.5's dedicated `Pdo\Pgsql` class with native prepared statements and emulation disabled
- Per-connection statement, lock, and idle-transaction timeouts
- Advisory-locked, transactional migrations
- Indexed normalized queries
- Window-function reply previews
- Batched post-file loading
- Long-cache static assets
- Database-free and PHP-free public page/media reads
- Atomic, lock-serialized rebuilds only after writes
- OPcache enabled by the Windows launcher
- Image work performed only during upload/import

For internet-scale traffic, place a real HTTP server or CDN in front, prefer `index.html` for directory requests, give generated HTML appropriate cache/revalidation headers, and route only dynamic endpoints and missing public paths to PHP.
