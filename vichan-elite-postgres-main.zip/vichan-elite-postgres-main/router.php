<?php

declare(strict_types=1);

use Uri\Rfc3986\Uri;
use VichanNative\Http\Request;

$root = __DIR__;
$target = (string) ($_SERVER['REQUEST_URI'] ?? '/');
$uri = new Uri($target, new Uri('http://localhost/'));
$path = rawurldecode($uri->getPath());
$assetExtensions = ['css', 'js', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'woff', 'woff2', 'ttf', 'eot', 'ico', 'map'];
$extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
$assetPrefix = str_starts_with($path, '/stylesheets/')
    || str_starts_with($path, '/js/')
    || str_starts_with($path, '/static/')
    || $path === '/main.js';

if ($path === '/'
    && in_array((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'), ['GET', 'HEAD'], true)
    && is_file($root . DIRECTORY_SEPARATOR . 'index.html')) {
    header('Location: /index.html', true, 302);
    exit;
}

if (in_array((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'), ['GET', 'HEAD'], true)
    && $assetPrefix && in_array($extension, $assetExtensions, true)) {
    $candidate = realpath($root . str_replace('/', DIRECTORY_SEPARATOR, $path));
    if ($candidate !== false && str_starts_with($candidate, realpath($root) . DIRECTORY_SEPARATOR) && is_file($candidate)) {
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: public, max-age=3600');
        return false;
    }
}

$staticRelative = match (true) {
    $path === '/index.html' => 'index.html',
    preg_match('#^/frames/(?:sidebar|news)\.html$#D', $path) === 1 => ltrim($path, '/'),
    preg_match('#^/[a-z0-9_]{1,58}/$#D', $path) === 1 => trim($path, '/') . '/index.html',
    preg_match('#^/[a-z0-9_]{1,58}/(?:index|catalog|[1-9][0-9]*)\.html$#D', $path) === 1
        => ltrim($path, '/'),
    preg_match('#^/[a-z0-9_]{1,58}/res/[1-9][0-9]*\.html$#D', $path) === 1
        => ltrim($path, '/'),
    preg_match('#^/[a-z0-9_]{1,58}/(?:src|thumb)/[a-f0-9]{32}\.(?:png|jpg|gif|webp)$#D', $path) === 1
        => ltrim($path, '/'),
    default => null,
};
if ($staticRelative !== null
    && in_array((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'), ['GET', 'HEAD'], true)) {
    $candidate = realpath($root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $staticRelative));
    if ($candidate !== false
        && str_starts_with($candidate, realpath($root) . DIRECTORY_SEPARATOR)
        && is_file($candidate)) {
        return false;
    }
}

/** @var \VichanNative\Application $application */
$application = require $root . DIRECTORY_SEPARATOR . 'bootstrap.php';
$application->handle(Request::fromGlobals())->send();
