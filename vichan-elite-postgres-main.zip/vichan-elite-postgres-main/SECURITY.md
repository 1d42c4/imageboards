# Security model

This rewrite removes legacy trust assumptions instead of attempting to preserve them.

## Privacy boundary

Application code never reads `REMOTE_ADDR`, `HTTP_CF_CONNECTING_IP`, `X-Forwarded-For`, `Forwarded` or similar client-address headers. The native schema contains no IP/address columns and no ban, mute, IP-note or IP-flood tables. A preflight query rejects the schema if common legacy address columns or tables appear.

The web server, operating system, reverse proxy, Cloudflare and PostgreSQL can keep their own logs independently. Configure those systems separately if the policy is that no client address should be retained anywhere.

Rate limiting uses keyed HMACs over the anonymous browser session and submitted content shape. It does not infer identity and cannot mistake two users on one VPN for a moderator. Moderator authority comes only from a server-generated opaque session token tied to an authenticated moderator record.

## Authentication and secrets

- Moderator passwords use PHP's Argon2id implementation.
- Per-board posting passwords are optional and use Argon2id.
- Moderator cookies are HttpOnly, SameSite=Strict and Secure outside the explicit localhost development mode.
- Moderator session tokens contain 256 random bits; only their SHA-256 hashes are stored.
- Login has anonymous rate limiting and a dummy Argon2id verification path.
- Session CSRF tokens protect every state-changing moderator form.
- Inline moderator controls submit POST forms, validate board-scoped return paths, and record actions in the moderation log.
- Static public posting forms carry a site-key signature scoped to their exact board/thread, so moderator session tokens are never frozen into shared HTML.
- Trip secrets use the compact traditional `Name##secret` syntax, are removed from the public name in memory, and are transformed with a site-keyed HMAC-SHA-256. They are not stored in posts, sessions, cookies, URLs or logs.
- The local JavaScript strips inline trip secrets before remembering the public name in browser storage.

Use a unique, random production site key. Changing it changes future trip outputs. Database backups and deployment environment secrets must be protected. Database passwords are intentionally absent from committed configuration and the Windows helpers read them through masked prompts.

Startup rejects the committed development site key and non-HTTPS base URLs unless `VICHAN_ALLOW_INSECURE_LOCAL=1` is explicitly set. That escape hatch is intended only for the loopback-only Windows development launcher.

## Content and uploads

- Output templates escape all ordinary values.
- Comment markup starts by escaping HTML and adds only local numeric quote links.
- Upload acceptance is based on fileinfo MIME detection, not the submitted extension.
- Only PNG, JPEG, GIF and WebP are accepted.
- GD must decode the image, dimensions and byte size are bounded, and images are fully re-encoded.
- Metadata and original container quirks are discarded.
- Server-side source and thumbnail names are independent random values.
- Canonical files are stored under `storage`; randomly named public hard links (or atomic copies) are served from each board's `src` and `thumb` directories without PHP.
- Public media names contain 128 random bits. Rejected or deleted public links and canonical files are removed together.
- Atomic temporary-file writes prevent partially written images.
- Legacy imports repeat the same decode/re-encode pipeline and reject path traversal.

Animated GIF frames may be flattened by safe re-encoding. This is an intentional security/performance tradeoff.

## Browser defenses

Dynamic application responses receive:

- a restrictive Content-Security-Policy that permits frames only from the same origin
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: no-referrer`
- `X-Frame-Options: SAMEORIGIN`, allowing only the local removable Frameset landing page
- `Permissions-Policy` disabling unused powerful features
- `Cross-Origin-Opener-Policy: same-origin`
- `Cross-Origin-Resource-Policy: same-origin`
- no-store caching on dynamic/private responses where appropriate

Configure equivalent security headers at the production web-server layer for generated HTML. Static HTML should use deliberate cache/revalidation policy rather than the dynamic `no-store` policy; immutable randomly named media can use a long cache lifetime.

The original asset collection is served locally. User-supplied remote JavaScript is not executed by the server. The Options feature can apply a user's own browser-local CSS/JS, which affects only that browser profile.

## Operations

The included PHP development server binds to localhost only. Before internet deployment:

1. Use a maintained production web server and HTTPS.
2. Keep `VICHAN_ALLOW_INSECURE_LOCAL` disabled.
3. Supply `VICHAN_DB_PASSWORD` through the service environment or a secret manager; never run the app as the `postgres` superuser.
4. Make `storage`, `src`, `views`, `database`, `bin`, configuration files and other application source non-public at the web-server layer.
5. Set restrictive filesystem permissions on service environment files, configuration and backups.
6. Configure short, privacy-conscious proxy/server logs if desired.
7. Serve generated HTML and board media directly with suitable cache/revalidation headers; route only dynamic endpoints and misses to PHP.
8. Enable OPcache and establish tested database, canonical-upload and generated-page rebuild procedures.
9. Add request/body limits at the proxy as a second boundary.
10. Keep PHP 8.5 and PostgreSQL 18 patched.

## Deliberately excluded legacy behavior

There is no public post-deletion password, IP-based ban/control system, legacy moderator credential import, raw HTML posting, arbitrary embed HTML, dynamic PHP plugin loader, remote-file ingestion or direct legacy-session compatibility. This reduces the attack surface and avoids importing security state whose meaning depended on client addresses.

This design substantially hardens the core but does not promise that any software is invulnerable. Review and test the actual production web-server, proxy, TLS, database, ACL and backup configuration as part of the same security boundary.
