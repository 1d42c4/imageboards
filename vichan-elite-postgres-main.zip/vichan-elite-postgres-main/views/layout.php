<?php

declare(strict_types=1);

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
    <title><?= $e($title ?? $config->appName) ?></title>
    <link rel="stylesheet" media="screen" href="/stylesheets/style.css?v=86">
    <link rel="stylesheet" href="/stylesheets/font-awesome/css/font-awesome.min.css?v=86">
    <link rel="stylesheet" href="/static/flags/flags.css?v=86">
    <style>
        .boardlist.top { padding-right:78px; box-sizing:border-box; }
        .options-link-wrap {
            position:fixed; top:2px; right:5px; z-index:1000;
            padding:1px 3px; white-space:nowrap;
        }
        .mod-controls { margin-left:4px; white-space:nowrap; }
        .mod-action-form { display:none; }
        .mod-control-link {
            appearance:none; border:0; padding:0; margin:0 2px 0 0;
            background:transparent; color:inherit; font:inherit;
            text-decoration:underline; cursor:pointer;
        }
    </style>
    <script>
        var active_page = <?= json_encode($activePage ?? 'index') ?>;
        var board_name = <?= json_encode($boardName ?? '') ?>;
        var thread_id = <?= json_encode($threadId ?? '') ?>;
        var configRoot = "/";
        var inMod = <?= !empty($moderator) ? 'true' : 'false' ?>;
        var modRoot = "/mod.php?/";
    </script>
    <script src="/main.js?v=87" data-resource-version="87"></script>
    <script src="/js/jquery.min.js?v=86"></script>
    <script src="/js/inline-expanding.js?v=88"></script>
    <script src="/js/options.js?v=86"></script>
    <script src="/js/style-select.js?v=86"></script>
    <script src="/js/options/general.js?v=86"></script>
    <script src="/js/options/user-css.js?v=86"></script>
    <script src="/js/options/user-js.js?v=86"></script>
</head>
<body class="8chan vichan <?= !empty($moderator) ? 'is-moderator' : 'is-not-moderator' ?> active-<?= $e($activePage ?? 'index') ?>" data-stylesheet="default">
    <div class="boardlist top">
        [<a href="/index.html">Home</a>]
        <?php if (!empty($boardName)): ?> [<a href="<?= !empty($moderator) ? '/mod.php?/' : '/' ?><?= $e($boardName) ?><?= !empty($moderator) ? '' : '/' ?>">/<?= $e($boardName) ?>/</a>]<?php endif; ?>
        <span class="options-link-wrap">[<a href="#" class="options-link">Options</a>]</span>
        [<a href="/mod.php?/"><?= !empty($moderator) ? 'Dashboard' : 'Mod' ?></a>]
    </div>
    <?= $content ?>
    <div class="boardlist bottom">
        [<a href="/index.html">Home</a>]
        <?php if (!empty($boardName)): ?> [<a href="<?= !empty($moderator) ? '/mod.php?/' : '/' ?><?= $e($boardName) ?><?= !empty($moderator) ? '' : '/' ?>">/<?= $e($boardName) ?>/</a>]<?php endif; ?>
        [<a href="/mod.php?/"><?= !empty($moderator) ? 'Dashboard' : 'Mod' ?></a>]
    </div>
    <footer>
        <p class="unimportant" style="margin-top:20px;text-align:center;">
            - <?= $e($config->appName) ?> / PHP 8.5 -<br>
            Original Vichan-compatible interface; independently rewritten application core.
        </p>
        <p class="unimportant" style="text-align:center;">
            All comments and images are owned by and are the responsibility of their respective parties.
        </p>
    </footer>
    <script>if (typeof ready === "function") ready();</script>
</body>
</html>
