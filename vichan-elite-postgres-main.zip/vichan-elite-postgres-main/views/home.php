<?php

declare(strict_types=1);

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $e($title) ?></title>
    <link rel="stylesheet" media="screen" href="/stylesheets/style.css?v=85">
    <style>
        html, body { width:100%; height:100%; margin:0; padding:0; overflow:hidden; }
        iframe { border:0; margin:0; padding:0; height:100%; position:absolute; top:0; }
        iframe#sidebar { left:0; width:15%; }
        iframe#main { border-left:1px solid #000; left:15%; width:85%; }
        #frameset-toggle {
            position:fixed; z-index:10; top:50%; left:calc(15% - 14px);
            width:28px; height:28px; padding:0; cursor:pointer;
            border:1px solid #000; border-radius:3px;
            font-weight:bold; line-height:24px; transform:translateY(-50%);
        }
        body.sidebar-hidden iframe#sidebar { display:none; }
        body.sidebar-hidden iframe#main { left:0; width:100%; border-left:0; }
        body.sidebar-hidden #frameset-toggle { left:0; }
        @media (max-width:700px) {
            iframe#sidebar { width:42%; }
            iframe#main { left:42%; width:58%; }
            #frameset-toggle { left:calc(42% - 14px); }
        }
    </style>
</head>
<body class="frameset-home">
    <button id="frameset-toggle" type="button" aria-controls="sidebar" aria-expanded="true"
            title="Remove sidebar">&laquo;</button>
    <iframe src="/frames/sidebar.html" id="sidebar" name="sidebar" title="Board navigation"></iframe>
    <iframe src="/frames/news.html" id="main" name="main" title="Site content"></iframe>
    <script>
        (() => {
            const body = document.body;
            const button = document.getElementById('frameset-toggle');
            const storageKey = 'vichan-elite-frameset-sidebar';
            const update = hidden => {
                body.classList.toggle('sidebar-hidden', hidden);
                button.setAttribute('aria-expanded', hidden ? 'false' : 'true');
                button.title = hidden ? 'Restore sidebar' : 'Remove sidebar';
                button.innerHTML = hidden ? '&#9776;' : '&laquo;';
                localStorage.setItem(storageKey, hidden ? 'hidden' : 'visible');
            };
            update(localStorage.getItem(storageKey) === 'hidden');
            button.addEventListener('click', () => update(!body.classList.contains('sidebar-hidden')));
        })();
    </script>
</body>
</html>
