<?php

declare(strict_types=1);

ob_start();
?>
<h2 style="text-align:center">Post approval queue</h2>
<?php if ($posts === []): ?>
    <p style="text-align:center">There are no posts awaiting approval.</p>
<?php endif; ?>
<?php foreach ($posts as $post): ?>
    <fieldset>
        <legend>/<?= $e($post->boardUri) ?>/ · No.<?= $post->id ?> · <?= gmdate('Y-m-d H:i:s', $post->createdAt) ?> UTC</legend>
        <p>
            <strong><?= $e($post->subject) ?></strong>
            <span class="name"><?= $e($post->name) ?></span>
            <span class="trip"><?= $e($post->trip) ?></span>
        </p>
        <?php foreach ($post->files as $file): ?>
            <a href="/<?= $e($post->boardUri) ?>/src/<?= $e($file->storedName) ?>" target="_blank">
                <img src="/<?= $e($post->boardUri) ?>/thumb/<?= $e($file->thumbnailName) ?>" style="max-width:250px;max-height:250px" alt="">
            </a>
        <?php endforeach; ?>
        <div class="body"><?= $post->bodyHtml ?></div>
        <form action="/mod.php?/pending" method="post">
            <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
            <input type="hidden" name="post_id" value="<?= $post->id ?>">
            <button name="action" value="approve">Approve</button>
            <button name="action" value="reject" onclick="return confirm('Reject and permanently remove this pending post?')">Reject</button>
        </form>
    </fieldset>
<?php endforeach; ?>
<?php
$modContent = (string) ob_get_clean();
$this->partial('mod/layout.php', compact('title', 'modContent', 'moderator', 'csrf'));
?>
