<?php

declare(strict_types=1);

ob_start();
$creating = $board === null;
?>
<?php if ($error !== ''): ?><h2 style="text-align:center"><?= $e($error) ?></h2><?php endif; ?>
<?php if (!$creating): ?>
    <p style="text-align:center">
        <a href="/mod.php?/<?= $e($board->uri) ?>"><strong>[Moderate posts]</strong></a>
        <a href="/<?= $e($board->uri) ?>/">[Public board]</a>
    </p>
<?php endif; ?>
<form action="<?= $creating ? '/mod.php?/boards/new' : '/mod.php?/boards/' . $e($board->uri) ?>" method="post">
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
    <table>
        <?php if ($creating): ?>
            <tr><th>URI</th><td><input name="uri" maxlength="58" required> <span class="unimportant">lowercase letters, numbers, underscore</span></td></tr>
        <?php else: ?>
            <tr><th>URI</th><td>/<?= $e($board->uri) ?>/</td></tr>
        <?php endif; ?>
        <tr><th>Title</th><td><input name="title" maxlength="255" size="40" value="<?= $e($board?->title ?? '') ?>" required></td></tr>
        <tr><th>Subtitle</th><td><input name="subtitle" maxlength="500" size="60" value="<?= $e($board?->subtitle ?? '') ?>"></td></tr>
        <?php if (!$creating): ?>
            <tr>
                <th>Post approval</th>
                <td><label><input type="checkbox" name="require_approval" value="1" <?= $board->requireApproval ? 'checked' : '' ?>> Require moderator approval before publication</label></td>
            </tr>
            <tr>
                <th>Posting password</th>
                <td>
                    <label><input type="radio" name="password_action" value="keep" checked> Keep current</label>
                    <label><input type="radio" name="password_action" value="clear"> Remove</label>
                    <label><input type="radio" name="password_action" value="replace"> Set/replace</label><br>
                    <input type="password" name="board_password" minlength="12" maxlength="200" autocomplete="new-password">
                    <span class="unimportant">Stored only as an Argon2id hash.</span>
                </td>
            </tr>
        <?php endif; ?>
        <tr><td></td><td><button type="submit"><?= $creating ? 'Create board' : 'Save board' ?></button></td></tr>
    </table>
</form>
<?php
$modContent = (string) ob_get_clean();
$this->partial('mod/layout.php', compact('title', 'modContent', 'moderator', 'csrf'));
?>
