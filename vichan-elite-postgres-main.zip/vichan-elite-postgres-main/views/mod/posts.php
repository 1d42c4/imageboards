<?php

declare(strict_types=1);

ob_start();
?>
<h2 style="text-align:center">Recent posts</h2>
<table style="width:95%">
    <tr><th>Post</th><th>Identity</th><th>Comment</th><th>Actions</th></tr>
    <?php foreach ($posts as $post): ?>
        <tr>
            <td>
                <a href="/mod.php?/<?= $e($post->boardUri) ?>/res/<?= $post->threadId ?? $post->id ?>.html#<?= $post->id ?>">
                    /<?= $e($post->boardUri) ?>/ No.<?= $post->id ?>
                </a><br>
                <small><?= gmdate('Y-m-d H:i:s', $post->createdAt) ?> UTC</small>
            </td>
            <td><?= $e($post->name) ?> <span class="trip"><?= $e($post->trip) ?></span></td>
            <td><?= $e(mb_strimwidth($post->bodySource, 0, 220, '…')) ?></td>
            <td>
                <form action="/mod.php?/posts" method="post">
                    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
                    <input type="hidden" name="post_id" value="<?= $post->id ?>">
                    <button name="action" value="delete" onclick="return confirm('Permanently delete this post?')">Delete</button>
                    <?php if ($post->isThread()): ?>
                        <br>
                        <label><input type="checkbox" name="sticky" value="1" <?= $post->sticky ? 'checked' : '' ?>> Sticky</label>
                        <label><input type="checkbox" name="locked" value="1" <?= $post->locked ? 'checked' : '' ?>> Locked</label>
                        <button name="action" value="flags">Save</button>
                    <?php endif; ?>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<?php
$modContent = (string) ob_get_clean();
$this->partial('mod/layout.php', compact('title', 'modContent', 'moderator', 'csrf'));
?>
