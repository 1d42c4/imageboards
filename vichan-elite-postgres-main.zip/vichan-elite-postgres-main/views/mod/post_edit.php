<?php

declare(strict_types=1);

ob_start();
?>
<h2 style="text-align:center">Edit /<?= $e($board->uri) ?>/ No.<?= $post->id ?></h2>
<?php if ($error !== ''): ?><div class="ban"><strong><?= $e($error) ?></strong></div><?php endif; ?>
<form action="/mod.php?/<?= $e($board->uri) ?>/edit/<?= $post->id ?>" method="post" enctype="multipart/form-data">
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
    <input type="hidden" name="return_route" value="<?= $e($returnRoute) ?>">
    <table>
        <tr>
            <th>Name</th>
            <td>
                <input type="text" name="name" size="25" maxlength="35" autocomplete="off" value="<?= $e($name) ?>">
                <?php if ($post->trip !== ''): ?><span class="trip"><?= $e($post->trip) ?></span> <small>(trip preserved)</small><?php endif; ?>
            </td>
        </tr>
        <tr>
            <th>Options</th>
            <td><input type="text" name="email" size="25" maxlength="40" autocomplete="off" value="<?= $e($email) ?>" placeholder="sage or noko"></td>
        </tr>
        <tr>
            <th>Subject</th>
            <td><input type="text" name="subject" size="35" maxlength="100" autocomplete="off" value="<?= $e($subject) ?>"></td>
        </tr>
        <tr>
            <th>Comment</th>
            <td><textarea name="body" id="body" rows="10" cols="50"><?= $e($body) ?></textarea></td>
        </tr>
        <tr id="image-settings">
            <th>Image</th>
            <td>
                <?php if ($post->files !== []): $currentFile = array_first($post->files); ?>
                    <p>
                        <a href="/<?= $e($board->uri) ?>/src/<?= $e($currentFile->storedName) ?>" target="_blank">
                            <img src="/<?= $e($board->uri) ?>/thumb/<?= $e($currentFile->thumbnailName) ?>"
                                 style="max-width:180px;max-height:180px" alt="">
                        </a><br>
                        <?= $e($currentFile->originalName) ?>
                    </p>
                    <label><input type="radio" name="file_action" value="keep" <?= $fileAction === 'keep' ? 'checked' : '' ?>> Keep current image</label><br>
                    <label><input type="radio" name="file_action" value="remove" <?= $fileAction === 'remove' ? 'checked' : '' ?>> Remove image</label><br>
                <?php else: ?>
                    <p class="unimportant">This post has no image.</p>
                <?php endif; ?>
                <label><input type="radio" name="file_action" value="replace" <?= $fileAction === 'replace' ? 'checked' : '' ?>> Replace/add image:</label>
                <input type="file" name="file" accept="image/png,image/jpeg,image/gif,image/webp">
            </td>
        </tr>
        <tr>
            <th></th>
            <td>
                <button type="submit">Update post</button>
                <a href="/mod.php?<?= $e($returnRoute) ?>#<?= $post->id ?>">Cancel</a>
            </td>
        </tr>
    </table>
</form>
<?php
$modContent = (string) ob_get_clean();
$boardName = $board->uri;
$activePage = 'mod';
$this->partial('mod/layout.php', compact(
    'title',
    'modContent',
    'moderator',
    'csrf',
    'boardName',
    'activePage',
));
?>
