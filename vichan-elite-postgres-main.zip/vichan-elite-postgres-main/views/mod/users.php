<?php

declare(strict_types=1);

ob_start();
?>
<?php if ($error !== ''): ?><h2 style="text-align:center"><?= $e($error) ?></h2><?php endif; ?>
<fieldset>
    <legend>Users</legend>
    <table>
        <tr><th>Username</th><th>Role</th><th>Change password</th></tr>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $e($user->username) ?></td>
                <td><?= $e($user->role->value) ?></td>
                <td>
                    <form action="/mod.php?/users" method="post">
                        <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
                        <input type="hidden" name="action" value="password">
                        <input type="hidden" name="user_id" value="<?= $user->id ?>">
                        <input type="password" name="password" minlength="14" maxlength="200" autocomplete="new-password" required>
                        <button type="submit">Change</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</fieldset>
<fieldset>
    <legend>Create user</legend>
    <form action="/mod.php?/users" method="post">
        <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
        <input type="hidden" name="action" value="create">
        <table>
            <tr><th>Username</th><td><input name="username" minlength="3" maxlength="60" required></td></tr>
            <tr>
                <th>Role</th>
                <td>
                    <select name="role">
                        <option value="moderator">Moderator</option>
                        <option value="administrator">Administrator</option>
                    </select>
                </td>
            </tr>
            <tr><th>Password</th><td><input type="password" name="password" minlength="14" maxlength="200" autocomplete="new-password" required></td></tr>
            <tr><td></td><td><button type="submit">Create user</button></td></tr>
        </table>
    </form>
</fieldset>
<?php
$modContent = (string) ob_get_clean();
$this->partial('mod/layout.php', compact('title', 'modContent', 'moderator', 'csrf'));
?>
