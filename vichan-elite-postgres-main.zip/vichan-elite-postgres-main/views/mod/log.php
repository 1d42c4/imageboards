<?php

declare(strict_types=1);

ob_start();
?>
<h2 style="text-align:center">Moderation log</h2>
<table style="width:95%">
    <tr><th>Time</th><th>User</th><th>Action</th><th>Board/Post</th><th>Details</th></tr>
    <?php foreach ($entries as $entry): ?>
        <tr>
            <td><?= gmdate('Y-m-d H:i:s', (int) $entry['created_at']) ?> UTC</td>
            <td><?= $e($entry['username'] ?? 'deleted') ?></td>
            <td><?= $e($entry['action']) ?></td>
            <td><?= $entry['board_uri'] ? '/' . $e($entry['board_uri']) . '/' : '' ?> <?= $entry['post_id'] ? 'No.' . (int) $entry['post_id'] : '' ?></td>
            <td><?= $e($entry['details']) ?></td>
        </tr>
    <?php endforeach; ?>
</table>
<?php
$modContent = (string) ob_get_clean();
$this->partial('mod/layout.php', compact('title', 'modContent', 'moderator', 'csrf'));
?>
