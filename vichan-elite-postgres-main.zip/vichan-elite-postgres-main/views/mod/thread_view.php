<?php

declare(strict_types=1);

ob_start();
?>
<?php if (is_file($config->root . '/static/banners/defaultbanner.png')): ?>
    <img class="board_image" src="/static/banners/defaultbanner.png" style="width:300px;height:100px" alt="">
<?php endif; ?>
<header>
    <h1>/<?= $e($board->uri) ?>/ - <?= $e($board->title) ?></h1>
    <div class="subtitle"><?= $e($board->subtitle) ?></div>
</header>
<div class="banner">
    Moderator thread view
    <a class="unimportant" href="/mod.php?/<?= $e($board->uri) ?>">[Return]</a>
    <a class="unimportant" href="/<?= $e($board->uri) ?>/res/<?= $thread->id ?>.html">[Public thread]</a>
</div>
<hr>
<?php $this->partial('post.php', [
    'post' => $thread,
    'board' => $board,
    'isOp' => true,
    'moderation' => true,
    'csrf' => $csrf,
    'returnRoute' => $returnRoute,
]); ?>
<div id="thread-interactions">
    <span id="thread-links"><a href="/mod.php?/<?= $e($board->uri) ?>">[Return]</a> <a href="#top">[Go to top]</a></span>
</div>
<a id="bottom"></a>
<?php
$modContent = (string) ob_get_clean();
$boardName = $board->uri;
$activePage = 'thread';
$this->partial('mod/layout.php', compact(
    'title',
    'modContent',
    'moderator',
    'csrf',
    'boardName',
    'activePage',
));
?>
