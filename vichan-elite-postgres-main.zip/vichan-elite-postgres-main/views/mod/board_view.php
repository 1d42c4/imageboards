<?php

declare(strict_types=1);

ob_start();
?>
<?php if (is_file($config->root . '/static/banners/defaultbanner.png')): ?>
    <img class="board_image" src="/static/banners/defaultbanner.png" style="width:300px;height:100px" alt="">
<?php endif; ?>
<header>
    <h1>/<?= $e($board->uri) ?>/ - <?= $e($board->title) ?></h1>
    <div class="subtitle"><?= $e($board->subtitle) ?></div>
</header>
<div class="banner">
    Moderator view &mdash; use the small controls beside each post.
    <a class="unimportant" href="/<?= $e($board->uri) ?>/">[Public board]</a>
</div>
<hr>
<?php foreach ($threads as $thread): ?>
    <?php $this->partial('post.php', [
        'post' => $thread,
        'board' => $board,
        'isOp' => true,
        'moderation' => true,
        'csrf' => $csrf,
        'returnRoute' => $returnRoute,
    ]); ?>
<?php endforeach; ?>
<?php if ($threads === []): ?><p style="text-align:center" class="unimportant">No threads yet.</p><hr><?php endif; ?>
<div class="pages">
    <?php if ($page > 1): ?><a href="/mod.php?/<?= $e($board->uri) ?><?= $page === 2 ? '' : '/' . ($page - 2) . '.html' ?>">Previous</a><?php else: ?>Previous<?php endif; ?>
    <?php for ($number = 1; $number <= $pageCount; $number++): ?>
        [<?php if ($number === $page): ?><a class="selected"><?= $number ?></a><?php else: ?><a href="/mod.php?/<?= $e($board->uri) ?><?= $number === 1 ? '' : '/' . ($number - 1) . '.html' ?>"><?= $number ?></a><?php endif; ?>]
    <?php endfor; ?>
    <?php if ($page < $pageCount): ?><a href="/mod.php?/<?= $e($board->uri) ?>/<?= $page ?>.html">Next</a><?php else: ?>Next<?php endif; ?>
    | <a href="/<?= $e($board->uri) ?>/catalog.html">Public catalog</a>
</div>
<?php
$modContent = (string) ob_get_clean();
$boardName = $board->uri;
$activePage = 'index';
$this->partial('mod/layout.php', compact(
    'title',
    'modContent',
    'moderator',
    'csrf',
    'boardName',
    'activePage',
));
?>
