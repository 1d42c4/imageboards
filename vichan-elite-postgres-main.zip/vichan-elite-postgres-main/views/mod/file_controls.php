<?php

declare(strict_types=1);

?>
<span class="mod-controls">
    <a title="Replace or remove image" href="/mod.php?/<?= $e($board->uri) ?>/edit/<?= $post->id ?>#image-settings">[Image]</a>
    <button class="mod-control-link" type="submit" form="mod-post-action-<?= $post->id ?>"
            name="action" value="remove_image" title="Delete image only"
            onclick="return confirm('Permanently delete this image?')">[F]</button>
</span>
