<?php

declare(strict_types=1);

ob_start();
?>
<?php if ($error !== ''): ?><h2 style="text-align:center"><?= $e($error) ?></h2><?php endif; ?>
<form action="/mod.php" method="post">
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
    <table style="margin-top:25px">
        <tr>
            <th>Username</th>
            <td><input type="text" name="username" size="20" maxlength="60" value="<?= $e($username) ?>" autofocus autocomplete="username"></td>
        </tr>
        <tr>
            <th>Password</th>
            <td><input type="password" name="password" size="20" maxlength="200" autocomplete="current-password"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="login" value="Continue"></td>
        </tr>
    </table>
</form>
<?php
$modContent = (string) ob_get_clean();
$this->partial('mod/layout.php', [
    'title' => $title,
    'modContent' => $modContent,
    'moderator' => null,
    'csrf' => $csrf,
]);
?>
