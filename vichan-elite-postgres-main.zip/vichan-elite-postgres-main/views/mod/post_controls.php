<?php

declare(strict_types=1);

?>
<span class="mod-controls">
    <button class="mod-control-link" type="submit" form="mod-post-action-<?= $post->id ?>"
            name="action" value="delete" title="Delete <?= $isOp ? 'thread' : 'post' ?>"
            onclick="return confirm('Permanently delete this <?= $isOp ? 'thread and all replies' : 'post' ?>?')">[D]</button>
    <?php if ($isOp): ?>
        <button class="mod-control-link" type="submit" form="mod-post-action-<?= $post->id ?>"
                name="action" value="toggle_sticky"
                title="<?= $post->sticky ? 'Make thread not sticky' : 'Make thread sticky' ?>"><?= $post->sticky ? '[-Sticky]' : '[Sticky]' ?></button>
        <button class="mod-control-link" type="submit" form="mod-post-action-<?= $post->id ?>"
                name="action" value="toggle_lock"
                title="<?= $post->locked ? 'Unlock thread' : 'Lock thread' ?>"><?= $post->locked ? '[Unlock]' : '[Lock]' ?></button>
    <?php endif; ?>
    <a title="Edit post" href="/mod.php?/<?= $e($board->uri) ?>/edit/<?= $post->id ?>">[Edit]</a>
</span>
