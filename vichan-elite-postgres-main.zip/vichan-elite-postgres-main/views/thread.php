<?php

declare(strict_types=1);

ob_start();
?>
<?php if (is_file($config->root . '/static/banners/defaultbanner.png')): ?>
    <img class="board_image" src="/static/banners/defaultbanner.png" style="width:300px;height:100px" alt="">
<?php endif; ?>
<header>
    <h1>/<?= $e($board->uri) ?>/ - <?= $e($board->title) ?></h1>
    <div class="subtitle"><?= $e($board->subtitle) ?></div>
</header>
<div class="banner">Posting mode: Reply <a class="unimportant" href="/<?= $e($board->uri) ?>/">[Return]</a> <a class="unimportant" href="#bottom">[Go to bottom]</a></div>
<?php $this->partial('post_form.php', ['board' => $board, 'threadId' => $thread->id, 'csrf' => $csrf]); ?>
<hr>
<?php $this->partial('post.php', ['post' => $thread, 'board' => $board, 'isOp' => true]); ?>
<div id="thread-interactions">
    <span id="thread-links"><a href="/<?= $e($board->uri) ?>/">[Return]</a> <a href="#top">[Go to top]</a> <a href="/<?= $e($board->uri) ?>/catalog.html">[Catalog]</a></span>
    <span id="thread-quick-reply"><a href="#body">[Post a Reply]</a></span>
</div>
<a id="bottom"></a>
<?php
$content = (string) ob_get_clean();
$this->partial('layout.php', [
    'title' => $title,
    'content' => $content,
    'activePage' => 'thread',
    'boardName' => $board->uri,
    'threadId' => $thread->id,
    'moderator' => $moderator,
]);
?>
