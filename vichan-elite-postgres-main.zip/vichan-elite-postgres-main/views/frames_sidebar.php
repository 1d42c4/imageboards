<?php

declare(strict_types=1);

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $e($title) ?></title>
    <link rel="stylesheet" media="screen" href="/stylesheets/style.css?v=85">
    <style>
        body { margin:8px; }
        fieldset { margin:10px 0; min-width:0; }
        legend {
            width:100%; margin-left:-15px; padding:5px;
            background:#98e; border:1px solid #fff; color:#fff; font-weight:bold;
        }
        ul { margin:0; padding:0; }
        li { list-style:none; padding:1px 4px; margin:0 4px; overflow-wrap:anywhere; }
        li a.system { font-weight:bold; }
    </style>
    <base target="main">
</head>
<body>
    <fieldset>
        <legend><?= $e($config->appName) ?></legend>
        <ul>
            <li><a class="system" href="/frames/news.html">[Home]</a></li>
            <li><a class="system" href="/mod.php?/"><?= !empty($moderator) ? '[Dashboard]' : '[Mod]' ?></a></li>
        </ul>
    </fieldset>
    <fieldset>
        <legend>Boards</legend>
        <ul>
            <?php foreach ($boards as $board): ?>
                <li>
                    <a href="/<?= $e($board->uri) ?>/">
                        /<?= $e($board->uri) ?>/ - <?= $e($board->title) ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </fieldset>
</body>
</html>
