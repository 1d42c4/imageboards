<?php

declare(strict_types=1);

$postClass = $isOp ? 'post op' : 'post reply';
$threadIdForLink = $isOp ? $post->id : $post->threadId;
$moderationPrefix = !empty($moderation) ? '/mod.php?' : '';
?>
<?php if ($isOp): ?><div class="thread" id="thread_<?= $post->id ?>" data-board="<?= $e($board->uri) ?>"><?php endif; ?>
<div class="<?= $postClass ?>" id="<?= $isOp ? 'op_' : 'reply_' ?><?= $post->id ?>">
    <a id="<?= $post->id ?>" class="post_anchor"></a>
    <?php foreach ($post->files as $file): ?>
        <div class="files">
            <div class="file">
                <p class="fileinfo">
                    <span>File: <a href="/<?= $e($board->uri) ?>/src/<?= $e($file->storedName) ?>"><?= $e($file->storedName) ?></a></span>
                    <span class="unimportant">
                        (<?= number_format($file->size / 1024, 2) ?> KB, <?= $file->width ?>x<?= $file->height ?>,
                        <a href="/<?= $e($board->uri) ?>/src/<?= $e($file->storedName) ?>" download="<?= $e($file->originalName) ?>" title="Save as original filename"><?= $e($file->originalName) ?></a>)
                    </span>
                    <?php if (!empty($moderation)): ?>
                        <?php $this->partial('mod/file_controls.php', compact('post', 'board', 'csrf', 'returnRoute')); ?>
                    <?php endif; ?>
                </p>
                <a class="image-expand" href="/<?= $e($board->uri) ?>/src/<?= $e($file->storedName) ?>"
                   target="_blank" aria-expanded="false" title="Click to expand or collapse">
                    <img class="post-image" src="/<?= $e($board->uri) ?>/thumb/<?= $e($file->thumbnailName) ?>"
                         style="width:<?= $file->thumbnailWidth ?>px;height:<?= $file->thumbnailHeight ?>px"
                         loading="lazy" alt="">
                </a>
            </div>
        </div>
    <?php endforeach; ?>
    <p class="intro">
        <?php if ($post->subject !== ''): ?><span class="subject"><?= $e($post->subject) ?></span> <?php endif; ?>
        <span class="name"><?= $e($post->name) ?></span>
        <?php if ($post->trip !== ''): ?><span class="trip"><?= $e($post->trip) ?></span><?php endif; ?>
        <time datetime="<?= gmdate('c', $post->createdAt) ?>"><?= gmdate('m/d/Y (D) H:i:s', $post->createdAt) ?></time>
        <a class="post_no" id="post_no_<?= $post->id ?>" href="<?= $moderationPrefix ?>/<?= $e($board->uri) ?>/res/<?= $threadIdForLink ?>.html#<?= $post->id ?>">No.</a>
        <a class="post_no" href="javascript:void(0)" onclick="return citeReply(<?= $post->id ?>,true);"><?= $post->id ?></a>
        <?php if ($post->sticky): ?><span class="unimportant">[Sticky]</span><?php endif; ?>
        <?php if ($post->locked): ?><span class="unimportant">[Locked]</span><?php endif; ?>
        <?php if (!empty($moderation)): ?>
            <?php $this->partial('mod/post_controls.php', compact('post', 'board', 'isOp', 'csrf', 'returnRoute')); ?>
        <?php endif; ?>
    </p>
    <div class="body"><?= $post->bodyHtml ?></div>
    <?php if (!empty($moderation)): ?>
        <form id="mod-post-action-<?= $post->id ?>" class="mod-action-form"
              action="/mod.php?/post-action" method="post">
            <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
            <input type="hidden" name="board" value="<?= $e($board->uri) ?>">
            <input type="hidden" name="post_id" value="<?= $post->id ?>">
            <input type="hidden" name="return_route" value="<?= $e($returnRoute) ?>">
        </form>
    <?php endif; ?>
    <?php if ($isOp): ?>
        <p class="omitted">
            <?php if ($post->omittedReplies > 0): ?><?= $post->omittedReplies ?> repl<?= $post->omittedReplies === 1 ? 'y' : 'ies' ?> omitted. <?php endif; ?>
            [<a href="<?= $moderationPrefix ?>/<?= $e($board->uri) ?>/res/<?= $post->id ?>.html">Reply</a>]
        </p>
    <?php endif; ?>
</div>
<?php if ($isOp): ?>
    <?php foreach ($post->replies as $reply): ?>
        <?php $this->partial('post.php', [
            'post' => $reply,
            'board' => $board,
            'isOp' => false,
            'moderation' => $moderation ?? false,
            'csrf' => $csrf ?? '',
            'returnRoute' => $returnRoute ?? '',
        ]); ?>
    <?php endforeach; ?>
</div>
<hr>
<?php endif; ?>
