<?php

declare(strict_types=1);

ob_start();
?>
<?php if (is_file($config->root . '/static/banners/defaultbanner.png')): ?>
    <img class="board_image" src="/static/banners/defaultbanner.png" style="width:300px;height:100px" alt="">
<?php endif; ?>
<header>
    <h1>/<?= $e($board->uri) ?>/ - <?= $e($board->title) ?></h1>
    <div class="subtitle">
        <?= $e($board->subtitle) ?>
        <?php if ($moderator): ?><p><a href="/mod.php?/">Return to dashboard</a></p><?php endif; ?>
    </div>
</header>
<div id="attention_bar"></div>
<?php $this->partial('post_form.php', ['board' => $board, 'threadId' => null, 'csrf' => $csrf]); ?>
<hr>
<?php foreach ($threads as $thread): ?>
    <?php $this->partial('post.php', ['post' => $thread, 'board' => $board, 'isOp' => true]); ?>
<?php endforeach; ?>
<?php if ($threads === []): ?><p style="text-align:center" class="unimportant">No threads yet.</p><hr><?php endif; ?>
<div class="pages">
    <?php if ($page > 1): ?><a href="/<?= $e($board->uri) ?>/<?= $page === 2 ? 'index' : $page - 2 ?>.html">Previous</a><?php else: ?>Previous<?php endif; ?>
    <?php for ($number = 1; $number <= $pageCount; $number++): ?>
        [<?php if ($number === $page): ?><a class="selected"><?= $number ?></a><?php else: ?><a href="/<?= $e($board->uri) ?>/<?= $number === 1 ? 'index' : $number - 1 ?>.html"><?= $number ?></a><?php endif; ?>]
    <?php endfor; ?>
    <?php if ($page < $pageCount): ?><a href="/<?= $e($board->uri) ?>/<?= $page ?>.html">Next</a><?php else: ?>Next<?php endif; ?>
    | <a href="/<?= $e($board->uri) ?>/catalog.html">Catalog</a>
</div>
<?php
$content = (string) ob_get_clean();
$this->partial('layout.php', [
    'title' => $title,
    'content' => $content,
    'activePage' => 'index',
    'boardName' => $board->uri,
    'moderator' => $moderator,
]);
?>
