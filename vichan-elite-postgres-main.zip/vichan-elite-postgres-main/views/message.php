<?php

declare(strict_types=1);

ob_start();
?>
<div style="text-align:center">
    <h2><?= $e($heading) ?></h2>
    <p><?= $e($message) ?></p>
    <p><a href="javascript:history.back()">Go back</a> · <a href="/">Boards</a></p>
</div>
<?php
$content = (string) ob_get_clean();
$this->partial('layout.php', [
    'title' => $title,
    'content' => $content,
    'activePage' => 'error',
    'boardName' => '',
    'moderator' => null,
]);
?>
