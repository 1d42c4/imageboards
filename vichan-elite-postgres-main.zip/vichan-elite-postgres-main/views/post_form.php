<?php

declare(strict_types=1);

?>
<form name="post" onsubmit="return doPost(this);" enctype="multipart/form-data" action="/post.php" method="post">
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
    <input type="hidden" name="board" value="<?= $e($board->uri) ?>">
    <input type="hidden" name="email" value="">
    <?php if (!empty($threadId)): ?><input type="hidden" name="thread" value="<?= (int) $threadId ?>"><?php endif; ?>
    <table>
        <tr>
            <th>Name</th>
            <td>
                <input type="text" name="name" size="25" maxlength="200" autocomplete="off"
                       placeholder="Name##secure trip"
                       title="Optional secure trip: Name##a secret of at least 16 characters">
            </td>
        </tr>
        <tr>
            <th>Subject</th>
            <td>
                <input style="float:left" type="text" name="subject" size="25" maxlength="100" autocomplete="off">
                <input accesskey="s" style="margin-left:2px" type="submit" name="post" value="<?= !empty($threadId) ? 'New Reply' : 'New Topic' ?>">
            </td>
        </tr>
        <tr>
            <th>Comment</th>
            <td><textarea name="body" id="body" rows="5" cols="35"></textarea></td>
        </tr>
        <tr id="upload">
            <th>File</th>
            <td>
                <input type="file" name="file" id="upload_file" accept="image/png,image/jpeg,image/gif,image/webp">
                <script>if (typeof init_file_selector !== "undefined") init_file_selector(1);</script>
            </td>
        </tr>
        <?php if ($board->requiresPassword()): ?>
            <tr>
                <th>Board password</th>
                <td>
                    <input type="password" name="board_password" size="20" maxlength="200" autocomplete="current-password" required>
                    <span class="unimportant">(Required to post on this board.)</span>
                </td>
            </tr>
        <?php endif; ?>
    </table>
</form>
<script>if (typeof rememberStuff === "function") rememberStuff();</script>
