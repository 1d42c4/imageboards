<?php

declare(strict_types=1);

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $e($title) ?></title>
    <link rel="stylesheet" media="screen" href="/stylesheets/style.css?v=85">
    <link rel="stylesheet" href="/stylesheets/font-awesome/css/font-awesome.min.css?v=85">
    <link rel="stylesheet" href="/static/flags/flags.css?v=86">
    <style>
        .boardlist.top { padding-right:78px; box-sizing:border-box; }
        .options-link-wrap {
            position:fixed; top:2px; right:5px; z-index:1000;
            padding:1px 3px; white-space:nowrap;
        }
    </style>
    <script>
        var active_page = "index";
        var board_name = "";
        var thread_id = "";
        var configRoot = "/";
        var inMod = <?= !empty($moderator) ? 'true' : 'false' ?>;
        var modRoot = "/mod.php?/";
    </script>
    <script src="/main.js?v=87" data-resource-version="87"></script>
    <script src="/js/jquery.min.js?v=86"></script>
    <script src="/js/inline-expanding.js?v=88"></script>
    <script src="/js/options.js?v=86"></script>
    <script src="/js/style-select.js?v=86"></script>
    <script src="/js/options/general.js?v=86"></script>
    <script src="/js/options/user-css.js?v=86"></script>
    <script src="/js/options/user-js.js?v=86"></script>
</head>
<body class="8chan vichan active-index" data-stylesheet="default">
    <div class="boardlist top">
        [<a href="/frames/news.html">Home</a>]
        <?php foreach ($boards as $board): ?>
            [<a href="/<?= $e($board->uri) ?>/">/<?= $e($board->uri) ?>/</a>]
        <?php endforeach; ?>
        <span class="options-link-wrap">[<a href="#" class="options-link">Options</a>]</span>
        [<a href="/mod.php?/"><?= !empty($moderator) ? 'Dashboard' : 'Mod' ?></a>]
    </div>
    <?php if (is_file($config->root . '/static/banners/defaultbanner.png')): ?>
        <img class="board_image" src="/static/banners/defaultbanner.png"
             style="width:300px;height:100px" alt="">
    <?php endif; ?>
    <header>
        <h1><?= $e($config->appName) ?></h1>
        <div class="subtitle">PHP 8.5-native imageboards</div>
    </header>
    <div class="ban">
        <h2>Boards</h2>
        <?php if ($boards === []): ?>
            <p class="unimportant">(No boards are available.)</p>
        <?php else: ?>
            <p>Select a board from the sidebar or from this list.</p>
            <ul>
                <?php foreach ($boards as $board): ?>
                    <li>
                        <a href="/<?= $e($board->uri) ?>/"><strong>/<?= $e($board->uri) ?>/</strong></a>
                        - <?= $e($board->title) ?>
                        <?php if ($board->subtitle !== ''): ?>
                            <span class="unimportant">&mdash; <?= $e($board->subtitle) ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    <footer>
        <p class="unimportant" style="margin-top:20px;text-align:center;">
            - <?= $e($config->appName) ?> / PHP 8.5 -
        </p>
    </footer>
    <script>if (typeof ready === "function") ready();</script>
</body>
</html>
