<?php

declare(strict_types=1);

ob_start();
?>
<header>
    <h1>/<?= $e($board->uri) ?>/ - Catalog</h1>
    <div class="subtitle"><?= $e($board->subtitle) ?></div>
</header>
<div class="pages"><a href="/<?= $e($board->uri) ?>/">[Return]</a></div>
<div id="Grid">
    <?php foreach ($threads as $thread): ?>
        <div class="mix" data-replycount="<?= count($thread->replies) + $thread->omittedReplies ?>">
            <?php if ($thread->files !== []): $file = array_first($thread->files); ?>
                <a href="/<?= $e($board->uri) ?>/res/<?= $thread->id ?>.html">
                    <img src="/<?= $e($board->uri) ?>/thumb/<?= $e($file->thumbnailName) ?>" style="max-width:150px;max-height:150px" alt="">
                </a>
            <?php endif; ?>
            <div class="thread">
                <a href="/<?= $e($board->uri) ?>/res/<?= $thread->id ?>.html"><strong><?= $e($thread->subject ?: 'No.' . $thread->id) ?></strong></a>
                <p><?= $e(mb_strimwidth($thread->bodySource, 0, 180, '…')) ?></p>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<?php
$content = (string) ob_get_clean();
$this->partial('layout.php', [
    'title' => $title,
    'content' => $content,
    'activePage' => 'catalog',
    'boardName' => $board->uri,
    'moderator' => $moderator,
]);
?>
