@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "PHP=C:\php\php.exe"
if not exist "%PHP%" (
  echo ERROR: PHP was not found at %PHP%
  pause
  exit /b 1
)

"%PHP%" -r "exit(PHP_VERSION_ID >= 80508 && PHP_VERSION_ID < 80600 ? 0 : 1);"
if errorlevel 1 (
  echo ERROR: This application requires PHP 8.5.8 or a newer PHP 8.5 patch.
  "%PHP%" -v
  pause
  exit /b 1
)

sc query postgresql-x64-18 2>nul | findstr /C:"RUNNING" >nul
if errorlevel 1 (
  echo Starting the PostgreSQL 18 Windows service...
  net start postgresql-x64-18 >nul 2>&1
  if errorlevel 1 (
    echo ERROR: PostgreSQL 18 could not be started.
    echo Run this batch file as administrator or start the service manually.
    pause
    exit /b 1
  )
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File bin\start-local.ps1
if errorlevel 1 pause
exit /b %ERRORLEVEL%
