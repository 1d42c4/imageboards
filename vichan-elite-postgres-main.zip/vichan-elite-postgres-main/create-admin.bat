@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

if not exist "C:\php\php.exe" (
  echo ERROR: PHP was not found at C:\php\php.exe
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File bin\create-admin-local.ps1 "%~1"
exit /b %ERRORLEVEL%
