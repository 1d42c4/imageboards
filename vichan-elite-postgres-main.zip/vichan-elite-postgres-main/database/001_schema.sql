CREATE TABLE boards (
    id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    uri varchar(58) NOT NULL,
    title varchar(255) NOT NULL,
    subtitle varchar(500) NOT NULL DEFAULT '',
    require_approval boolean NOT NULL DEFAULT false,
    post_password_hash varchar(255),
    created_at bigint NOT NULL CHECK (created_at > 0),
    updated_at bigint NOT NULL CHECK (updated_at > 0),
    CONSTRAINT boards_uri_format CHECK (uri ~ '^[a-z0-9_]{1,58}$'),
    CONSTRAINT boards_uri_unique UNIQUE (uri)
);

CREATE TABLE moderators (
    id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    username varchar(60) NOT NULL,
    password_hash varchar(255) NOT NULL,
    role varchar(16) NOT NULL DEFAULT 'moderator',
    force_password_change boolean NOT NULL DEFAULT false,
    created_at bigint NOT NULL CHECK (created_at > 0),
    updated_at bigint NOT NULL CHECK (updated_at > 0),
    CONSTRAINT moderators_username_format CHECK (username ~ '^[A-Za-z0-9_.-]{3,60}$'),
    CONSTRAINT moderators_role_valid CHECK (role IN ('moderator', 'administrator'))
);

CREATE UNIQUE INDEX moderators_username_ci ON moderators (lower(username));

CREATE TABLE moderator_sessions (
    token_hash bytea PRIMARY KEY CHECK (octet_length(token_hash) = 32),
    moderator_id integer NOT NULL REFERENCES moderators (id) ON DELETE CASCADE,
    created_at bigint NOT NULL CHECK (created_at > 0),
    last_seen_at bigint NOT NULL CHECK (last_seen_at > 0),
    expires_at bigint NOT NULL CHECK (expires_at > created_at)
);

CREATE INDEX moderator_sessions_expiry ON moderator_sessions (expires_at);

CREATE TABLE posts (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    board_id integer NOT NULL REFERENCES boards (id) ON DELETE CASCADE,
    thread_id bigint REFERENCES posts (id) ON DELETE CASCADE,
    subject varchar(100) NOT NULL DEFAULT '',
    name varchar(35) NOT NULL,
    trip varchar(32) NOT NULL DEFAULT '',
    email varchar(40) NOT NULL DEFAULT '',
    body_source text NOT NULL,
    body_html text NOT NULL,
    status varchar(16) NOT NULL DEFAULT 'published',
    created_at bigint NOT NULL CHECK (created_at > 0),
    bumped_at bigint NOT NULL CHECK (bumped_at > 0),
    sticky boolean NOT NULL DEFAULT false,
    locked boolean NOT NULL DEFAULT false,
    CONSTRAINT posts_status_valid CHECK (status IN ('pending', 'published')),
    CONSTRAINT posts_threads_only_have_flags CHECK (thread_id IS NULL OR (NOT sticky AND NOT locked))
);

CREATE FUNCTION enforce_post_parent() RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog, public
AS $function$
BEGIN
    IF NEW.thread_id IS NULL THEN
        RETURN NEW;
    END IF;
    IF NOT EXISTS (
        SELECT 1
        FROM public.posts parent
        WHERE parent.id = NEW.thread_id
          AND parent.board_id = NEW.board_id
          AND parent.thread_id IS NULL
    ) THEN
        RAISE EXCEPTION 'reply parent must be a thread on the same board'
            USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END;
$function$;

CREATE TRIGGER posts_enforce_parent
BEFORE INSERT OR UPDATE OF board_id, thread_id ON posts
FOR EACH ROW EXECUTE FUNCTION enforce_post_parent();

CREATE INDEX posts_board_threads
    ON posts (board_id, sticky DESC, bumped_at DESC)
    WHERE thread_id IS NULL AND status = 'published';
CREATE INDEX posts_thread
    ON posts (thread_id, id)
    WHERE status = 'published';
CREATE INDEX posts_pending
    ON posts (created_at)
    WHERE status = 'pending';

CREATE TABLE post_files (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    post_id bigint NOT NULL REFERENCES posts (id) ON DELETE CASCADE,
    stored_name varchar(80) NOT NULL,
    thumbnail_name varchar(80) NOT NULL,
    original_name varchar(255) NOT NULL,
    mime varchar(80) NOT NULL,
    size integer NOT NULL CHECK (size > 0),
    width integer NOT NULL CHECK (width > 0),
    height integer NOT NULL CHECK (height > 0),
    thumbnail_width integer NOT NULL CHECK (thumbnail_width > 0),
    thumbnail_height integer NOT NULL CHECK (thumbnail_height > 0),
    CONSTRAINT post_files_stored_name_format
        CHECK (stored_name ~ '^[a-f0-9]{32}\.(png|jpg|gif|webp)$'),
    CONSTRAINT post_files_thumbnail_name_format
        CHECK (thumbnail_name ~ '^[a-f0-9]{32}\.(png|jpg|gif|webp)$'),
    CONSTRAINT post_files_mime_valid
        CHECK (mime IN ('image/png', 'image/jpeg', 'image/gif', 'image/webp')),
    CONSTRAINT post_files_stored_name_unique UNIQUE (stored_name),
    CONSTRAINT post_files_thumbnail_name_unique UNIQUE (thumbnail_name)
);

CREATE INDEX post_files_post ON post_files (post_id, id);

CREATE TABLE rate_limits (
    bucket_key bytea PRIMARY KEY CHECK (octet_length(bucket_key) = 32),
    attempts integer NOT NULL CHECK (attempts > 0),
    window_started_at bigint NOT NULL CHECK (window_started_at > 0),
    expires_at bigint NOT NULL CHECK (expires_at >= window_started_at)
);

CREATE INDEX rate_limits_expiry ON rate_limits (expires_at);

CREATE TABLE moderation_log (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    moderator_id integer REFERENCES moderators (id) ON DELETE SET NULL,
    action varchar(80) NOT NULL,
    board_uri varchar(58),
    post_id bigint,
    details varchar(1000) NOT NULL DEFAULT '',
    created_at bigint NOT NULL CHECK (created_at > 0),
    CONSTRAINT moderation_log_action_format CHECK (action ~ '^[a-z0-9_.-]{1,80}$'),
    CONSTRAINT moderation_log_board_uri_format
        CHECK (board_uri IS NULL OR board_uri ~ '^[a-z0-9_]{1,58}$')
);

CREATE INDEX moderation_log_time ON moderation_log (created_at DESC);

CREATE TABLE legacy_import_map (
    source_database varchar(64) NOT NULL,
    board_uri varchar(58) NOT NULL,
    legacy_post_id integer NOT NULL CHECK (legacy_post_id > 0),
    native_post_id bigint NOT NULL UNIQUE REFERENCES posts (id) ON DELETE CASCADE,
    imported_at bigint NOT NULL CHECK (imported_at > 0),
    PRIMARY KEY (source_database, board_uri, legacy_post_id),
    CONSTRAINT legacy_import_source_format CHECK (source_database ~ '^[A-Za-z0-9_]{1,64}$'),
    CONSTRAINT legacy_import_board_uri_format CHECK (board_uri ~ '^[a-z0-9_]{1,58}$')
);

INSERT INTO boards (uri, title, subtitle, require_approval, post_password_hash, created_at, updated_at)
VALUES (
    'b',
    'Random',
    '',
    false,
    NULL,
    floor(extract(epoch FROM clock_timestamp()))::bigint,
    floor(extract(epoch FROM clock_timestamp()))::bigint
)
ON CONFLICT (uri) DO NOTHING;
