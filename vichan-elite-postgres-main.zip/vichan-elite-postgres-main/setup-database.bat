@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "PHP=C:\php\php.exe"
set "PSQL=C:\Program Files\PostgreSQL\18\bin\psql.exe"

if not exist "%PHP%" (
  echo ERROR: PHP was not found at %PHP%
  pause
  exit /b 1
)
if not exist "%PSQL%" (
  echo ERROR: PostgreSQL 18 was not found at %PSQL%
  pause
  exit /b 1
)

sc query postgresql-x64-18 2>nul | findstr /C:"RUNNING" >nul
if errorlevel 1 (
  echo Starting the PostgreSQL 18 Windows service...
  net start postgresql-x64-18 >nul 2>&1
  if errorlevel 1 (
    echo ERROR: PostgreSQL 18 could not be started.
    echo Right-click this batch file, choose Run as administrator, and try again.
    pause
    exit /b 1
  )
)

echo.
echo Creating the vichan_elite database and restricted application role.
echo First enter the PostgreSQL postgres-role password, then choose an app-role password.
"%PSQL%" -X -W -h 127.0.0.1 -p 5432 -U postgres -d postgres -v ON_ERROR_STOP=1 -f bin\setup-postgresql.sql
if errorlevel 1 (
  echo.
  echo ERROR: PostgreSQL database creation failed. Check the password and service.
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File bin\setup-local.ps1
if errorlevel 1 (
  echo.
  echo ERROR: Application setup failed.
  pause
  exit /b 1
)

pause
exit /b 0
